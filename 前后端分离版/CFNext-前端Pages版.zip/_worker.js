var de=`<!doctype html><html lang="zh-CN" data-theme="dark"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>\u767B\u5F55</title><style>
:root{--bg:#0d1117;--card:#151d29;--bd:#25303f;--tx:#e9eef7;--dim:#93a3b8;--ac:#7c6cff;--ac2:#22d3ee;--err:#f87171}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--tx);font-family:"PingFang SC","Microsoft YaHei",system-ui,sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;position:relative;overflow:hidden}
body::before,body::after{content:"";position:fixed;border-radius:50%;filter:blur(90px);pointer-events:none}
body::before{width:480px;height:480px;left:-140px;top:-160px;background:rgba(124,108,255,.16)}
body::after{width:420px;height:420px;right:-120px;bottom:-140px;background:rgba(34,211,238,.10)}
.box{position:relative;z-index:1;width:340px;max-width:100%;background:rgba(21,29,41,.72);border:1px solid rgba(255,255,255,.10);border-radius:20px;padding:30px 28px;box-shadow:0 24px 60px rgba(0,0,0,.35)}
.brand{display:flex;align-items:center;gap:10px;margin-bottom:22px}
.mark{width:38px;height:38px;border-radius:12px;background:linear-gradient(135deg,var(--ac),var(--ac2));display:flex;align-items:center;justify-content:center}
.mark svg{width:20px;height:20px}.mark path{stroke:#fff}
.bt b{font-size:16px}.bt span{font-size:11.5px;color:var(--dim)}
h1{font-size:15px;margin-bottom:4px}p{color:var(--dim);font-size:13px;margin-bottom:18px}
input{width:100%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.10);color:var(--tx);border-radius:12px;padding:11px 13px;font-size:14px;outline:none;margin-bottom:12px;font-family:inherit}
input:focus{border-color:var(--ac)}
button{width:100%;background:linear-gradient(135deg,rgba(124,108,255,.85),rgba(34,211,238,.75));border:1px solid rgba(255,255,255,.22);color:#fff;border-radius:12px;padding:11px;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit}
button:active{transform:translateY(1px)}button:disabled{opacity:.6;cursor:not-allowed}
.msg{color:var(--err);font-size:13px;margin-bottom:12px;display:none;background:rgba(248,113,113,.13);padding:8px 12px;border-radius:8px}
</style></head><body>
<div class="box">
  <div class="brand"><div class="mark"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h4l3-7 4 14 3-7h2"/></svg></div><div class="bt"><b>Console</b><span>CFNext \u63A7\u5236\u53F0</span></div></div>
  <h1>__TITLE__</h1><p>__HINT__</p>
  <div class="msg" id="msg"></div>
  <form id="form">
    <input type="password" id="pwd" placeholder="\u7BA1\u7406\u5BC6\u7801" autofocus autocomplete="current-password">
    __PWD2__
    <button type="submit" id="btn">__BTN__</button>
  </form>
</div>
<script>
(function(){
  var form = document.getElementById('form');
  var msg = document.getElementById('msg');
  form.addEventListener('submit', function(e){
    e.preventDefault();
    var p1 = document.getElementById('pwd').value;
    var p2 = document.getElementById('pwd2');
    if (p2) {
      if (p1.length < 4) { msg.textContent = '\u5BC6\u7801\u81F3\u5C11 4 \u4F4D'; msg.style.display='block'; return; }
      if (p1 !== p2.value) { msg.textContent = '\u4E24\u6B21\u8F93\u5165\u4E0D\u4E00\u81F4'; msg.style.display='block'; return; }
    }
    fetch(location.pathname, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ password: p1 }) })
      .then(function(r){ return r.json(); })
      .then(function(r){
        if (r && r.ok) { location.href = r.next || location.pathname; }
        else { msg.textContent = (r && r.msg) || '\u64CD\u4F5C\u5931\u8D25'; msg.style.display='block'; }
      })
      .catch(function(){ msg.textContent = '\u7F51\u7EDC\u9519\u8BEF'; msg.style.display='block'; });
  });
})();
</script></body></html>`,he=de.replace("<title>\u767B\u5F55</title>","<title>\u8BBE\u7F6E\u7BA1\u7406\u5BC6\u7801</title>").replace("__TITLE__","\u8BBE\u7F6E\u7BA1\u7406\u5BC6\u7801").replace("__HINT__","\u9996\u6B21\u4F7F\u7528\uFF0C\u8BF7\u8BBE\u7F6E\u7BA1\u7406\u5BC6\u7801\u4EE5\u4FDD\u62A4\u9762\u677F").replace("__PWD2__",'<input type="password" id="pwd2" placeholder="\u518D\u6B21\u8F93\u5165\u5BC6\u7801" autocomplete="new-password">').replace("__BTN__","\u8BBE\u7F6E\u5E76\u8FDB\u5165"),ve=de.replace("<title>\u767B\u5F55</title>","<title>\u767B\u5F55 \xB7 CFNext \u63A7\u5236\u53F0</title>").replace("__TITLE__","\u767B\u5F55").replace("__HINT__","\u8BF7\u8F93\u5165\u7BA1\u7406\u5BC6\u7801\u4EE5\u7EE7\u7EED").replace("__PWD2__","").replace("__BTN__","\u767B\u5F55"),ge=`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>Console</title>
<style>
:root{--bg:#0d1117;--card:#151d29;--bd:#25303f;--tx:#e9eef7;--dim:#93a3b8;--ac:#7c6cff}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--tx);font-family:"PingFang SC","Microsoft YaHei","Segoe UI",system-ui,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px}
.box{width:520px;max-width:100%;background:var(--card);border:1px solid var(--bd);border-radius:16px;padding:26px 24px}
h1{font-size:15px;font-weight:600;margin-bottom:14px}p{color:var(--dim);font-size:13px;line-height:1.75;margin-bottom:10px}
code{background:rgba(124,108,255,.14);color:#c9c2ff;padding:2px 6px;border-radius:5px;font-size:12.5px;font-family:ui-monospace,Menlo,Consolas,monospace}
b{color:var(--tx);font-weight:600}
</style></head><body><div class="box">
<h1>\u9762\u677F\u5165\u53E3\u5DF2\u5C31\u7EEA</h1>
<p>\u8BBF\u95EE <code>/&lt;L&gt;</code>\uFF08\u4F60\u5728\u73AF\u5883\u53D8\u91CF <code>L</code> \u91CC\u8BBE\u7F6E\u7684\u5165\u53E3\u8DEF\u5F84\uFF09\u8FDB\u5165\u9762\u677F\uFF0C\u767B\u5F55\u540E\u5728\u300C\u9762\u677F\u8BBE\u7F6E \u2192 \u591A\u540E\u7AEF\u7BA1\u7406\u300D\u91CC\u6DFB\u52A0\u540E\u7AEF\u5373\u53EF\u3002</p>
<p>\u6BCF\u884C\u683C\u5F0F\uFF1A<code>\u540D\u79F0:\u5730\u5740,API\u5BC6\u94A5,UUID</code></p>
<p>\u672C\u524D\u7AEF\u53EA\u9700\u4E00\u4E2A\u73AF\u5883\u53D8\u91CF <code>L</code>\uFF0C\u5176\u4F59\u914D\u7F6E\uFF08\u540E\u7AEF\u5730\u5740\u3001\u5404\u540E\u7AEF\u5BC6\u94A5\u3001\u8BA2\u9605 UUID\u3001\u767B\u5F55\u5BC6\u7801\uFF09\u90FD\u5728\u9762\u677F\u91CC\u5B8C\u6210\u3002</p>
</div></body></html>`;function ce(t){let e=2166136261;for(let a=0;a<t.length;a++)e^=t.charCodeAt(a),e=Math.imul(e,16777619);return("00000000"+(e>>>0).toString(16)).slice(-8)}var Z="cfn_auth",ne=new WeakMap,N=new Map;async function pe(t,e){if(typeof caches>"u")return null;try{let a=[t.CF_PAGES_PROJECT_NAME,t.ADMIN,t.API,t.BACKENDS,t.URL,t.U,t.QUOTA_ACCOUNTS,t.BECFG].join(`
`),r=N.get(a);return r||(N.size>4&&N.clear(),r=crypto.subtle.digest("SHA-256",new TextEncoder().encode(a)).then(n=>Array.from(new Uint8Array(n),o=>o.toString(16).padStart(2,"0")).join("")),N.set(a,r)),{cache:await caches.open("cfnext-config-v1"),request:new Request("https://cfnext-cache.invalid/"+await r+"/"+encodeURIComponent(e))}}catch{return null}}async function ue(t,e){try{let a=await pe(t,e),r=a&&await a.cache.match(a.request);if(!r)return{hit:!1};let n=await r.json();return n.expiresAt>Date.now()?{hit:!0,value:n.value}:{hit:!1}}catch{return{hit:!1}}}async function O(t,e,a){try{let r=await pe(t,e);if(!r)return;let n=_(e);await r.cache.put(r.request,new Response(JSON.stringify({value:a,expiresAt:Date.now()+n}),{headers:{"Content-Type":"application/json","Cache-Control":"public, max-age="+Math.floor(n/1e3)}}))}catch{}}async function xe(t,e,a){q(t)?.set(e,{value:a,expiresAt:Date.now()+_(e)}),await O(t,e,a)}function q(t){if(!t.K)return null;let e=ne.get(t.K);return e||ne.set(t.K,e=new Map),e}function _(t){return t==="admin"?6e4:t.startsWith("quota_usage:")?9e5:3e5}async function z(t,e){if(!t.K||typeof t.K.get!="function")return null;let a=q(t),r=a.get(e);if(r?.pending)return r.pending;if(r&&Date.now()<r.expiresAt){if(r.error)throw r.error;return r.value}a.size>=64&&!a.has(e)&&a.delete(a.keys().next().value);let n={};return a.set(e,n),n.pending=Promise.resolve().then(async()=>{let o=await ue(t,e);if(o.hit)return o.value;let i=await t.K.get(e);return a.get(e)===n&&await O(t,e,i),i}).then(o=>(a.get(e)===n&&a.set(e,{value:o,expiresAt:Date.now()+_(e)}),o),o=>{throw a.get(e)===n&&a.set(e,{error:o,expiresAt:Date.now()+3e4}),o}),n.pending}async function D(t,e,a,r){let n=q(t),o=n.get(e);if(!r&&o&&!o.pending&&!o.error&&Date.now()<o.expiresAt&&o.value===a)return;let i={};n.set(e,i),i.pending=Promise.resolve().then(async()=>{await t.K.put(e,a,r),await O(t,e,a)}).then(()=>(n.get(e)===i&&n.set(e,{value:a,expiresAt:Date.now()+_(e)}),a),l=>{throw n.get(e)===i&&n.delete(e),l}),await i.pending}async function ye(t,e){let a=q(t),r={};a.set(e,r),r.pending=Promise.resolve().then(async()=>{await t.K.delete(e),await O(t,e,null)}).then(()=>(a.get(e)===r&&a.set(e,{value:null,expiresAt:Date.now()+_(e)}),null),n=>{throw a.get(e)===r&&a.delete(e),n}),await r.pending}function Q(t){let e=String(t&&t.url||"").trim().replace(/\/+$/,"");return e?{name:String(t&&t.name||"").trim()||e.replace(/^https?:\/\//i,"").split(".")[0],url:e,api:String(t&&(t.api||t.gate)||"").trim(),uuid:String(t&&t.uuid||"").trim().replace(/^\/+|\/+$/g,"")}:null}var j={source:"",value:{}};function ee(t){let e=Object.keys(t).filter(n=>n.startsWith("BACKEND_REPLACE_")).sort().map(n=>t[n]),a=String(t.BACKEND_REPLACEMENTS||"").trim(),r=JSON.stringify([a,e]);if(j.source!==r){let n=a?JSON.parse(a):{};if(!n||Array.isArray(n)||typeof n!="object")throw new Error("Invalid backend replacements");for(let o of e){let{from:i,...l}=JSON.parse(o);if(typeof i!="string"||!/^https:\/\//i.test(i))throw new Error("Invalid retired backend URL");n[i.replace(/\/+$/,"")]=l}j={source:r,value:n}}return j.value}function J(t,e){let a=Q(e);if(!a)return null;let r=ee(t),n=new Set;for(;r[a.url];){if(n.has(a.url))throw new Error("Backend replacement cycle");n.add(a.url);let o=r[a.url];if(typeof o.url!="string"||!/^https:\/\//i.test(o.url))throw new Error("Invalid replacement backend URL");a=Q({...a,...o})}return a}async function oe(t){let e=String(t.API||t.GATE||t.BACKEND_GATE||"").trim(),a=String(t.U||t.UUID||t.BACKEND_UUID||"").trim().replace(/^\/+|\/+$/g,""),r=i=>{let l=[];for(let s of i){let p=J(t,s);p&&(p.api?p.apiExplicit=!0:p.api=e,p.envUuid=a,l.push(p))}return l};try{if(t.K&&typeof t.K.get=="function"){let i=await z(t,"backends");if(i){let l=r(JSON.parse(i));if(l.length)return l}}}catch{}let n=String(t.BACKENDS||"").trim();if(n)try{let i=JSON.parse(n);if(Array.isArray(i)){let l=r(i);if(l.length)return l}}catch{}let o=String(t.URL||t.BACKEND_URL||"").trim().replace(/\/+$/,"");return o?[{...J(t,{url:o,api:e}),envUuid:a}]:[]}async function R(t,e){let a={sel:0,multi:!1,balance:!1},r=n=>{!n||typeof n!="object"||(Number.isInteger(n.sel)&&(a.sel=n.sel),typeof n.multi=="boolean"&&(a.multi=n.multi),typeof n.balance=="boolean"&&(a.balance=n.balance))};try{r(JSON.parse(t.BECFG||"null"))}catch{}try{if(t.K&&typeof t.K.get=="function"){let n=await z(t,"becfg");if(n){let o=JSON.parse(n);r(o)}}}catch{}return(a.sel<0||a.sel>=e)&&(a.sel=0),a}function te(t,e){let a=new Headers;for(let[r,n]of t.headers){let o=r.toLowerCase();o==="host"||o==="content-length"||o==="x-cf-api"||o==="x-cf-gate"||o==="x-cf-host"||o==="x-cf-tunnel-uuid"||o==="x-cfnext-config-backend"||a.set(r,n)}return e&&a.set("x-cf-api",e),a}var we="cf";function I(t){return t.uuid||t.envUuid||we}function H(t,e){let a=String(t||"").toLowerCase();if(["clash","stash","mihomo"].includes(a))return"clash";if(["singbox","sing-box","hiddify"].includes(a))return"singbox";if(a&&a!=="auto")return null;let r=String(e||"").toLowerCase();return/sing-?box|hiddify/.test(r)?"singbox":/clash|mihomo|stash|mozilla|applewebkit/.test(r)?"clash":null}function ke(t,e){if(e==="singbox")try{return(JSON.parse(t).outbounds||[]).filter(i=>i.type&&!["selector","urltest","url-test","direct","block","dns"].includes(i.type)).length}catch{return 0}let a=t.startsWith("proxies:")?0:t.indexOf(`
proxies:`)+1;if(a<0||!t.slice(a).startsWith("proxies:"))return 0;let r=t.slice(a+8),n=r.search(/\n[A-Za-z][\w-]*:/);return((n<0?r:r.slice(0,n)).match(/^  - (?:name\s*:|\{)/gm)||[]).length}async function V(t,e,a,r,n,o){let l=new URL("https://local"+(a||"")).search||"",s=await fe(o),p=await Promise.all(t.map(async b=>{if(s.has(b.url))return{name:b.name,text:"",err:"Account quota threshold reached"};try{let g=I(b),w=new Request("https://local/",{headers:{"User-Agent":"clash.meta",Accept:"*/*"}}),x=te(w,b.api);x.set("x-cf-host",r);let m=await fetch(b.url+"/"+g+"/sub/"+e+l,{headers:x,signal:AbortSignal.timeout(15e3)});if(!m.ok)return{name:b.name,text:"",json:null,err:"HTTP "+m.status};let h=await m.text();return{name:b.name,text:h,json:null,err:""}}catch(g){return{name:b.name,text:"",json:null,err:g&&g.message||String(g)}}})),u=p.filter(b=>b.text);if(!u.length){let b=p.map(g=>`${g.name}:${g.err}`).join("; ");return new Response("all backends failed: "+b,{status:502,headers:{"content-type":"text/plain; charset=utf-8"}})}let c;return e==="singbox"?c=Se(u):c=Ce(u),new Response(c,{status:200,headers:{"content-type":e==="singbox"?"application/json; charset=utf-8":"text/yaml; charset=utf-8","cache-control":"no-store","X-CFNext-Backend-Count":String(u.length),"X-CFNext-Backend-Total":String(t.length),"content-disposition":`attachment; filename="CFNext-aggregate.${e==="singbox"?"json":"yaml"}"`}})}function be(t,e,a){let r=t,n=1;for(;a.has(r);)r=t+"\xB7\u540E\u7AEF"+(e+1)+(n>1?"-"+n:""),n++;return a.add(r),r}function W(t){if(t=t.trim(),t.startsWith('"'))try{return JSON.parse(t)}catch{}return t.startsWith("'")?t.slice(1,-1).replace(/''/g,"'"):t}function Ce(t){let e=t[0].text,a=[],r=[],n=[],o=u=>{let c=u.indexOf(`
proxies:`);if(c<0)return"";let b=u.slice(c+9),g=b.search(/\n[A-Za-z][\w-]*:/);return g<0?b:b.slice(0,g)};o(e).replace(/^  - name:\s*(.+)$/gm,(u,c)=>(n.push(W(c)),u));let i=new Set(n);for(let u=1;u<t.length;u++){let c=o(t[u].text).replace(/^(  - name:\s*)(.+)$/gm,(b,g,w)=>{let x=be(W(w),u,i);return r.push(x),g+JSON.stringify(x)});c&&a.push(c)}let l=e.indexOf(`
proxies:`);if(a.length&&l>=0){let c=e.slice(l+9).search(/\n[A-Za-z][\w-]*:/),b=c<0?e.length:l+9+c;e=e.slice(0,b)+a.join("")+e.slice(b)}let s=e.indexOf(`
proxy-groups:`);if(s>=0&&r.length){let u=e.slice(0,s),c=e.slice(s),b=c.slice(1).search(/\n[A-Za-z][\w-]*:/),g=b<0?c.length:b+1,w=c.slice(0,g).replace(/(^  - name:[\s\S]*?)(?=^  - name:|$(?![\s\S]))/gm,x=>!/^    proxies:\s*$/m.test(x)||![...x.matchAll(/^      - (.+)$/gm)].map(h=>W(h[1])).some(h=>n.includes(h))?x:x.replace(/(^    proxies:\s*\n)((?:^      - .*\n?)*)/m,(h,y,E)=>y+E.replace(/\n?$/,`
`)+r.map(d=>"      - "+JSON.stringify(d)).join(`
`)+`
`));e=u+w+c.slice(g)}let p=e.split(`
`)[0];return p.startsWith("#")&&(e=e.replace(p,p+" \xB7 \u805A\u5408 "+t.length+" \u540E\u7AEF")),e}function Se(t){let e;try{e=JSON.parse(t[0].text)}catch{return t[0].text}if(!Array.isArray(e?.outbounds))return t[0].text;let a=l=>l&&!["selector","urltest","direct","block","dns"].includes(l.type),r=new Set(e.outbounds.filter(a).map(l=>l.tag)),n=new Set(e.outbounds.map(l=>l.tag)),o=new Set(n),i=[];for(let l=1;l<t.length;l++){let s;try{s=JSON.parse(t[l].text)}catch{continue}let p=new Map((s.outbounds||[]).filter(a).map(u=>[u.tag,be(u.tag,l,o)]));for(let u of s.outbounds||[]){if(!a(u))continue;let c=p.get(u.tag);if(!c||n.has(c))continue;let b={...u,tag:c};b.detour&&p.has(b.detour)&&(b.detour=p.get(b.detour)),e.outbounds.push(b),i.push(c),n.add(c)}}for(let l of e.outbounds)["selector","urltest"].includes(l.type)&&l.outbounds?.some(s=>r.has(s))&&(l.outbounds=[...new Set([...l.outbounds,...i])]);return JSON.stringify(e)}async function Ae(t,e){if(!e.K||typeof e.K.put!="function")return new Response(JSON.stringify({ok:!1,msg:"\u524D\u7AEF\u672A\u7ED1\u5B9A KV\uFF08K\uFF09\uFF0C\u65E0\u6CD5\u6301\u4E45\u5316\u540E\u7AEF\u5217\u8868\uFF0C\u8BF7\u7528 env BACKENDS/URL \u914D\u7F6E"}),{status:500,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});let a;try{a=await t.json()}catch{a=null}let r=a&&Array.isArray(a.backends)?a.backends:null;if(!r)return new Response(JSON.stringify({ok:!1,msg:'\u8BF7\u6C42\u4F53\u9700\u4E3A {"backends":[{name,url,api,uuid}]}'}),{status:400,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});let n=[];for(let o of r){let i=Q(o);i&&n.push(i)}if(!n.length)return new Response(JSON.stringify({ok:!1,msg:"\u6CA1\u6709\u6709\u6548\u7684\u540E\u7AEF\uFF08url \u5FC5\u586B\u4E14\u4EE5 http(s):// \u5F00\u5934\uFF09"}),{status:400,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});try{await D(e,"backends",JSON.stringify(n));let o=await R(e,n.length);return await D(e,"becfg",JSON.stringify(o)),new Response(JSON.stringify({ok:!0,msg:"\u5DF2\u4FDD\u5B58 "+n.length+" \u4E2A\u540E\u7AEF"}),{status:200,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}})}catch(o){return new Response(JSON.stringify({ok:!1,msg:"\u4FDD\u5B58\u5931\u8D25: "+(o&&o.message||o)}),{status:500,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}})}}async function Me(t,e,a){if(!e.K||typeof e.K.put!="function")return new Response(JSON.stringify({ok:!1,msg:"\u524D\u7AEF\u672A\u7ED1\u5B9A KV\uFF08K\uFF09\uFF0C\u65E0\u6CD5\u4FDD\u5B58\u5BF9\u63A5\u8BBE\u7F6E"}),{status:500,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});let r;try{r=await t.json()}catch{r=null}if(!r||typeof r!="object")return new Response(JSON.stringify({ok:!1,msg:'\u8BF7\u6C42\u4F53\u9700\u4E3A {"sel":0,"multi":false}'}),{status:400,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});let n=Number.isInteger(r.sel)?r.sel:0;(n<0||n>=a)&&(n=0);let o=!!r.multi,i=await R(e,a),l=typeof r.balance=="boolean"?r.balance:i.balance;try{return await D(e,"becfg",JSON.stringify({sel:n,multi:o,balance:l})),new Response(JSON.stringify({ok:!0,msg:o?"\u5DF2\u5F00\u542F\u591A\u8BA2\u9605\u805A\u5408\uFF08"+a+" \u4E2A\u540E\u7AEF\uFF09":"\u5DF2\u5207\u6362\u5230\u300C\u7B2C "+(n+1)+" \u4E2A\u540E\u7AEF\u300D"}),{status:200,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}})}catch(s){return new Response(JSON.stringify({ok:!1,msg:"\u4FDD\u5B58\u5931\u8D25: "+(s&&s.message||s)}),{status:500,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}})}}var Pe=`
<!DOCTYPE html>
<html lang="zh-CN" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>\u63A7\u5236\u53F0</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Crect x='3' y='3' width='18' height='18' rx='5' fill='%23f6821f'/%3E%3Cpath d='M8 15V9l8 6V9' stroke='%230d131b' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E">
<script src="https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js"></script>
<style>
.mark{width:34px;height:34px;border-radius:9px;background:linear-gradient(135deg,var(--accent),var(--accent2));display:flex;align-items:center;justify-content:center;flex:0 0 34px;box-shadow:0 4px 12px var(--accent-dim)}
.mark svg{width:18px;height:18px}
.mark path{stroke:#0d131b}
.ver-chip.has-update{color:var(--accent);background:var(--accent-dim);border-color:var(--accent)}
.ver-chip.checking{opacity:.7;pointer-events:none}
.ibtn{width:34px;height:34px;border-radius:8px;border:1px solid var(--border);background:var(--card);color:var(--text);cursor:pointer;display:flex;align-items:center;justify-content:center;flex:0 0 34px}
.mbadge{margin-left:auto;padding:3px 10px;border-radius:999px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06);-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);box-shadow:inset 0 1px 0 rgba(255,255,255,.14);font-size:12px;color:var(--accent);white-space:nowrap}
[data-theme="light"] .mbadge{border-color:rgba(30,45,70,.10);background:rgba(255,255,255,.60);box-shadow:inset 0 1px 0 rgba(255,255,255,.90)}
.ibtn:hover{border-color:var(--accent);color:var(--accent)}
.ibtn svg{width:16px;height:16px;stroke:currentColor}
.wdwarn{display:none;background:rgba(59,130,246,.10);border-bottom:1px solid rgba(59,130,246,.35);color:var(--accent2);padding:9px 26px;font-size:12.5px;line-height:1.6;text-align:center}
[data-theme="light"] .wdwarn{color:var(--accent);background:rgba(29,95,168,.06);border-bottom-color:rgba(29,95,168,.35)}
.content{padding:22px 26px 96px;max-width:1180px;width:100%;margin:0 auto}
@keyframes fade{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
.view-head{margin-bottom:16px}
.view-head h2{font-size:20px;font-weight:700}
.view-head p{color:var(--dim);font-size:13px;margin-top:4px}
.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(330px,1fr));gap:16px}
.filter-region{display:flex;align-items:center;gap:14px;padding:2px 0 14px;border-bottom:1px solid var(--border);margin-bottom:14px;flex-wrap:wrap}
.filter-region-label{font-size:13px;font-weight:600;white-space:nowrap}
.filter-row{display:flex;flex-wrap:wrap}
.filter-group{flex:0 1 auto;min-width:180px;padding:0 14px;border-left:1px solid var(--border)}
.filter-group:first-child{border-left:none;padding-left:0}
.filter-group-title{font-size:12px;font-weight:600;color:var(--dim);margin-bottom:9px;letter-spacing:.3px}
.pills.nowrap{flex-wrap:nowrap;white-space:nowrap}
.pills.nowrap .spill span{padding:5px 10px;font-size:12px}
.spill input{position:absolute;opacity:0;pointer-events:none}
.spill span{display:inline-block;padding:5px 14px;border:1px solid rgba(255,255,255,.13);border-radius:999px;font-size:12.5px;color:var(--dim);cursor:pointer;background:rgba(255,255,255,.05);-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);box-shadow:inset 0 1px 0 rgba(255,255,255,.14),0 2px 8px rgba(0,0,0,.20);transition:border-color .15s,color .15s,background .15s,box-shadow .15s;user-select:none;line-height:1.5}
.spill:hover span{border-color:var(--accent);color:var(--accent)}
.spill input:checked + span{background:var(--accent);border-color:var(--accent);color:#fff;font-weight:600;border-radius:999px}
.card h3 .tick{width:3px;height:14px;border-radius:2px;background:var(--accent)}
.checkline{display:flex;align-items:center;gap:20px;padding:5px 0;font-size:13px;cursor:pointer}
.checkline input{margin:0;flex:0 0 auto;vertical-align:middle}
.checkline span{line-height:1.5}
.proto-row{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px dashed var(--border);font-size:13.5px}
.proto-row:last-child{border-bottom:none}
.switch{position:relative;display:inline-block;width:40px;height:22px;flex:0 0 40px}
.switch input{opacity:0;width:0;height:0}
.switch input:checked+.sl{background:var(--accent)}
.switch input:checked+.sl::before{transform:translateX(18px)}
.btn.primary{background:linear-gradient(135deg,var(--accent),var(--accent2));border-color:transparent;color:#201308;font-weight:600}
.btn.primary:hover{filter:brightness(1.06);color:#201308}
.btn.danger{background:var(--err-dim);border-color:transparent;color:var(--err)}
.btn.danger:hover{border-color:var(--err)}
.btn .dirty-dot{display:none;width:6px;height:6px;border-radius:50%;background:var(--warn)}
.btn.dirty .dirty-dot{display:inline-block}
.tbl-wrap{overflow-x:auto}
.badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11.5px}
.badge.g{background:var(--ok-dim);color:var(--ok)}
.badge.r{background:var(--err-dim);color:var(--err)}
.msg.show{display:block}
.fbar{position:fixed;right:22px;bottom:22px;display:flex;gap:10px;z-index:60;align-items:center}
.fbar .btn{box-shadow:var(--shadow)}
.saved-at{font-size:11.5px;color:var(--faint);background:var(--card);border:1px solid var(--border);border-radius:8px;padding:5px 10px;box-shadow:var(--shadow);white-space:nowrap}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
.sec-title{font-size:12px;color:var(--faint);letter-spacing:1px;margin:20px 0 10px;font-weight:600}
.danger-zone{border:1px solid var(--err);border-radius:12px;padding:16px;background:var(--err-dim)}
.qrbox{display:flex;justify-content:center;padding:12px 0 4px}
.qrbox img{width:168px;height:168px;image-rendering:pixelated;border-radius:8px}
.note-box{background:var(--card2);border:1px solid var(--border);border-left:3px solid var(--accent);border-radius:8px;padding:12px 14px;font-size:12.5px;color:var(--dim);line-height:1.7;margin-bottom:12px}
@media (min-width:1100px){
  /* \u53F3\u4FA7\u907F\u8BA9\u53F3\u4E0B\u89D2\u6D6E\u52A8\u4FDD\u5B58\u680F\uFF08\u5C1A\u672A\u4FDD\u5B58/\u91CD\u7F6E/\u4FDD\u5B58\u5168\u90E8\uFF09\uFF0C\u907F\u514D\u906E\u6321\u7B5B\u9009\u52FE\u9009\u9879 */
  .filter-grid{padding-right:200px}
}
.mmode{position:fixed;inset:0;z-index:120;display:none;align-items:center;justify-content:center;padding:18px;background:rgba(4,8,13,.74)}
.mmode.show{display:flex}
.mmodebox{width:100%;max-width:820px;max-height:88vh;overflow-y:auto;background:var(--card);border:1px solid var(--border);border-radius:14px;box-shadow:var(--shadow);padding:22px 22px 16px}
.mmodebox h3{margin:0 0 6px;font-size:17px}
.mmodebox .msub{color:var(--dim);font-size:12.5px;line-height:1.65;margin-bottom:16px}
.mmodegrid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.mmodecard{border:1px solid rgba(255,255,255,.14);border-radius:11px;background:rgba(255,255,255,.055);color:var(--text);padding:15px 14px;cursor:pointer;text-align:left;-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px);box-shadow:inset 0 1px 0 rgba(255,255,255,.16),0 8px 22px rgba(0,0,0,.30);transition:border-color .15s,transform .15s,box-shadow .15s,background .15s}
.mmodecard:hover{border-color:var(--accent);transform:translateY(-2px)}
.mmodecard b{display:block;font-size:14.5px;margin-bottom:7px}
.mmodecard span{display:block;font-size:12.5px;color:var(--dim);line-height:1.6}
.mmodecard em{display:block;font-style:normal;font-size:11.5px;color:var(--faint);margin-top:9px}
.mmodefoot{margin-top:14px;text-align:right}
.mmodefoot a{color:var(--dim);font-size:12.5px;text-decoration:none}
.mmodefoot a:hover{color:var(--accent)}
@media (max-width:760px){
  .mmodegrid{grid-template-columns:1fr}
}
*{box-sizing:border-box;margin:0;padding:0}:root{--bg:#06080d;--bg2:#090d14;--card:#0c1119;--card2:#101724;--border:#1a2331;--text:#e9eef7;--dim:#93a3b8;--faint:#61718a;--line:#131a25;--accent:#7c6cff;--accent2:#22d3ee;--accent-dim:rgba(124,108,255,.14);--ok:#22c55e;--ok-dim:rgba(34,197,94,.13);--err:#f87171;--err-dim:rgba(248,113,113,.13);--warn:#fbbf24;--sb-bg:#080c12;--sb-text:#9fb0c5;--sb-dim:#5f7292;--sb-border:#161d28;--sb-active-bg:rgba(124,108,255,.14);--sb-active-text:#ab9dff;--sb-active-bar:#7c6cff;--glass:rgba(23,32,45,.54);--glass-2:rgba(19,27,39,.62);--glass-line:rgba(255,255,255,.10);--sb-glass:rgba(20,28,41,.50);--sb-rim:rgba(255,255,255,.46);--sb-vol-a:rgba(255,255,255,.11);--sb-vol-b:rgba(0,0,0,.20);--sb-glass-m:rgba(15,21,32,.88);--glass-rim:rgba(255,255,255,.30);--glass-hi:rgba(255,255,255,.12);--glass-field:rgba(255,255,255,.045);--glass-hover:rgba(255,255,255,.07);--glass-btn:rgba(255,255,255,.09);--glass-btn-hi:rgba(255,255,255,.17);--glass-rim-sm:rgba(255,255,255,.55);--glass-field-brd:rgba(255,255,255,.09);--glass-blur:22px;--glass-sh:0 20px 48px rgba(0,0,0,.42);--glass-shx:12px 0 36px rgba(0,0,0,.30);--blob-o:.44;--shadow:0 14px 40px rgba(0,0,0,.4);color-scheme:dark}[data-theme="light"]{--bg:#f4f6fb;--bg2:#eaeef6;--card:#fff;--card2:#f7f9fd;--border:#e1e7f0;--text:#16202e;--dim:#5a6a80;--faint:#93a1b4;--line:#eaeff6;--accent:#6355f5;--accent2:#0ea5b7;--accent-dim:rgba(99,85,245,.10);--ok:#17915a;--ok-dim:rgba(23,145,90,.11);--err:#dc4c4c;--err-dim:rgba(220,76,76,.10);--warn:#b7791f;--sb-bg:#ffffff;--sb-text:#5a6a80;--sb-dim:#9aa8bb;--sb-border:#e5eaf2;--sb-active-bg:rgba(99,85,245,.10);--sb-active-text:#5546e8;--sb-active-bar:#6355f5;--glass:rgba(255,255,255,.50);--glass-2:rgba(255,255,255,.60);--glass-line:rgba(20,40,70,.10);--sb-glass:rgba(255,255,255,.46);--sb-rim:rgba(255,255,255,1);--sb-vol-a:rgba(255,255,255,.68);--sb-vol-b:rgba(20,40,70,.075);--sb-glass-m:rgba(255,255,255,.90);--glass-rim:rgba(255,255,255,.95);--glass-hi:rgba(255,255,255,.70);--glass-field:rgba(255,255,255,.62);--glass-hover:rgba(20,40,70,.055);--glass-btn:rgba(255,255,255,.86);--glass-btn-hi:#ffffff;--glass-rim-sm:rgba(255,255,255,1);--glass-field-brd:rgba(20,40,70,.11);--glass-blur:22px;--glass-sh:0 18px 44px rgba(25,45,80,.13);--glass-shx:10px 0 30px rgba(25,45,80,.09);--blob-o:.42;--shadow:0 12px 34px rgba(25,40,70,.12);color-scheme:light}html,body{min-height:100%}body{background:var(--bg);color:var(--text);font-family:"PingFang SC","Microsoft YaHei","Segoe UI",system-ui,sans-serif;font-size:14px;line-height:1.6;-webkit-font-smoothing:antialiased}a{color:var(--accent);text-decoration:none}a:hover{text-decoration:underline}.app{display:flex;min-height:100vh;gap:12px;padding:12px}.sidebar{width:232px;flex:0 0 232px;background:var(--sb-bg);border-right:1px solid var(--sb-border);display:flex;flex-direction:column;position:sticky;top:12px;height:calc(100vh - 24px);z-index:50}.brand{display:flex;align-items:center;gap:11px;padding:18px 18px 14px}.brand .lg{width:34px;height:34px;flex:0 0 34px;border-radius:10px;background:linear-gradient(135deg,var(--accent),var(--accent2));display:flex;align-items:center;justify-content:center;box-shadow:0 4px 12px var(--accent-dim)}.brand .lg svg{width:18px;height:18px;stroke:#0b0e14;fill:none;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}.brand .bt{display:flex;flex-direction:column;line-height:1.25;min-width:0}.brand .bt b{font-size:15px;font-weight:700;letter-spacing:.3px}.brand .bt span{font-size:11px;color:var(--sb-dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.nav{flex:1;padding:6px 10px 12px;overflow-y:auto}.nav-item{display:flex;align-items:center;gap:10px;width:100%;padding:9px 12px;margin:2px 0;border:none;background:transparent;color:var(--sb-text);font-size:13.5px;font-family:inherit;text-align:left;cursor:pointer;border-radius:8px;position:relative;transition:.15s}.nav-item svg{width:17px;height:17px;flex:0 0 17px;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.nav-item:hover{background:var(--sb-active-bg);color:var(--sb-active-text)}.nav-item.on{background:var(--sb-active-bg);color:var(--sb-active-text);font-weight:600}.nav-item.on::before{content:"";position:absolute;left:-10px;top:8px;bottom:8px;width:3px;border-radius:0 3px 3px 0;background:var(--sb-active-bar)}.side-foot{padding:12px 18px;border-top:1px solid var(--sb-border);display:flex;align-items:center;justify-content:space-between;font-size:11.5px;color:var(--sb-dim)}.ver-chip{font-family:ui-monospace,Consolas,monospace;background:var(--accent-dim);color:var(--sb-active-text);padding:2px 8px;border-radius:6px;font-size:11px;border:1px solid transparent}.main{flex:1;min-width:0;display:flex;flex-direction:column;gap:12px}.topbar{display:flex;align-items:center;gap:14px;padding:12px 20px;border:1px solid var(--border);border-radius:18px;background:var(--bg);position:sticky;top:12px;z-index:40}.topbar h1{font-size:17px;font-weight:600;flex:1;min-width:0}.ibtn.hamb{display:none}.pill{display:inline-flex;align-items:center;gap:6px;font-size:12px;padding:4px 11px;border-radius:20px;background:var(--ok-dim);color:var(--ok);white-space:nowrap}.pill.off{background:var(--err-dim);color:var(--err)}.pill i{width:6px;height:6px;border-radius:50%;background:currentColor;display:block}.ibtn{width:34px;height:34px;border-radius:9px;border:1px solid var(--border);background:var(--card2);color:var(--dim);cursor:pointer;display:flex;align-items:center;justify-content:center}.ibtn:hover{border-color:var(--accent);color:var(--accent)}.ibtn svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}.wrap{width:100%;max-width:1180px;margin:0 auto;padding:0 4px 96px}.view{display:none}.view.on{display:block;animation:up .2s ease}@keyframes up{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}.vh{margin-bottom:16px}.vh h2{font-size:20px;font-weight:700}.vh p{color:var(--dim);font-size:13px;margin-top:3px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(330px,1fr));gap:16px}.grid3{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px}.card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:18px;margin-bottom:16px}.card h3{font-size:14px;font-weight:650;margin-bottom:14px;display:flex;align-items:center;gap:9px}.card h3 .dot{width:4px;height:15px;border-radius:3px;background:linear-gradient(var(--accent),var(--accent2))}.card h3 .sub{font-size:12px;color:var(--dim);font-weight:400;margin-left:auto}.kv{display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-bottom:1px dashed var(--line);font-size:13px}.kv:last-child{border-bottom:none}.kv .k{color:var(--dim);white-space:nowrap}.kv .v{text-align:right;word-break:break-all;font-family:ui-monospace,Consolas,monospace;font-size:12.5px}.kv .v.ok{color:var(--ok)}.kv .v.bad{color:var(--err)}.kv .v.warn{color:var(--warn)}.field{margin-bottom:13px}.field>label{display:block;font-size:12.5px;color:var(--dim);margin-bottom:6px;font-weight:500}input[type=text],input[type=password],input[type=number],select,textarea{width:100%;background:var(--card2);border:1px solid var(--border);color:var(--text);border-radius:9px;padding:9px 11px;font-size:13.5px;outline:none;font-family:inherit;transition:.15s}input:focus,select:focus,textarea:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-dim)}textarea{resize:vertical;line-height:1.55;font-family:ui-monospace,Consolas,monospace;font-size:12.5px}select{cursor:pointer;appearance:none;-webkit-appearance:none;padding-right:30px;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%2393a3b8' stroke-width='1.6' fill='none' stroke-linecap='round'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 11px center}select option,select optgroup{background:var(--bg2);color:var(--text)}input,select,textarea{accent-color:var(--accent)}.hint{font-size:12px;color:var(--dim);margin-top:7px;line-height:1.7}.inrow{display:flex;gap:8px;align-items:flex-start}.inrow>div{flex:1}.sw{position:relative;display:inline-block;width:40px;height:22px;flex:0 0 40px}.sw input{opacity:0;width:0;height:0}.sw .sl{position:absolute;inset:0;background:var(--border);border-radius:22px;cursor:pointer;transition:.18s}.sw .sl::before{content:"";position:absolute;width:16px;height:16px;left:3px;top:3px;background:#fff;border-radius:50%;transition:transform .18s}.sw input:checked+.sl{background:var(--accent)}.sw input:checked+.sl::before{transform:translateX(18px)}.prow{display:flex;align-items:center;gap:11px;padding:9px 0;border-bottom:1px dashed var(--line);font-size:13.5px}.prow:last-child{border-bottom:none}.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:1px solid var(--border);background:var(--card2);color:var(--text);border-radius:9px;padding:9px 15px;font-size:13px;cursor:pointer;font-family:inherit;white-space:nowrap;transition:.15s}.btn:hover{border-color:var(--accent);color:var(--accent)}.btn:active{transform:translateY(1px)}.btn:disabled{opacity:.5;cursor:not-allowed}.btn.pri{background:linear-gradient(135deg,var(--accent),var(--accent2));border-color:transparent;color:#0b0e14;font-weight:600}.btn.pri:hover{filter:brightness(1.07);color:#0b0e14}.btn.dgr{background:var(--err-dim);border-color:transparent;color:var(--err)}.btn.sm{padding:5px 11px;font-size:12px;border-radius:7px}.row{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.row .grow{flex:1;min-width:150px}.pills{display:flex;flex-wrap:wrap;gap:8px}.sp{position:relative}.sp input{position:absolute;opacity:0;pointer-events:none}.sp span{display:inline-block;padding:5px 13px;border:1px solid var(--border);border-radius:999px;font-size:12.5px;color:var(--dim);cursor:pointer;background:var(--card2);transition:.15s;user-select:none}.sp:hover span{border-color:var(--accent);color:var(--accent)}.sp input:checked+span{background:var(--accent);border-color:var(--accent);color:#fff;font-weight:600}.blk{border-top:1px solid var(--line);margin-top:14px;padding-top:14px}.blk-t{font-size:12px;font-weight:600;color:var(--dim);margin-bottom:10px;letter-spacing:.4px}.tbl{overflow-x:auto}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:9px 10px;font-size:13px;border-bottom:1px solid var(--line);white-space:nowrap}th{color:var(--dim);font-weight:500;font-size:12px;background:var(--card2)}td.ip{font-family:ui-monospace,Consolas,monospace;font-size:12.5px}.bdg{display:inline-block;padding:2px 9px;border-radius:10px;font-size:11.5px}.bdg.g{background:var(--ok-dim);color:var(--ok)}.bdg.r{background:var(--err-dim);color:var(--err)}.mono{font-family:ui-monospace,Consolas,monospace;font-size:12.5px}.msg{display:none;margin-top:12px;padding:10px 13px;border-radius:9px;font-size:12.5px;line-height:1.65}.msg.on{display:block}.msg.ok{background:var(--ok-dim);color:var(--ok)}.msg.err{background:var(--err-dim);color:var(--err)}.msg.info{background:var(--accent-dim);color:var(--accent)}pre.code{background:var(--bg2);border:1px solid var(--border);border-radius:9px;padding:12px;font-size:11.5px;line-height:1.55;font-family:ui-monospace,Consolas,monospace;overflow:auto;max-height:280px;white-space:pre-wrap;word-break:break-all;color:var(--dim);margin-top:10px}.bar{position:fixed;right:20px;bottom:20px;display:flex;gap:10px;align-items:center;z-index:60}.bar .btn{box-shadow:var(--shadow)}.stat{font-size:11.5px;color:var(--faint);background:var(--card);border:1px solid var(--border);border-radius:9px;padding:6px 11px;box-shadow:var(--shadow);white-space:nowrap}.toast{position:fixed;left:50%;bottom:26px;transform:translateX(-50%) translateY(90px);background:var(--card);border:1px solid var(--border);padding:11px 20px;border-radius:11px;font-size:13px;opacity:0;transition:.25s;z-index:200;box-shadow:var(--shadow);pointer-events:none;max-width:86vw}.toast.on{opacity:1;transform:translateX(-50%) translateY(0)}.toast.ok{border-color:var(--ok);color:var(--ok)}.toast.err{border-color:var(--err);color:var(--err)}.toast.warn{border-color:var(--warn);color:var(--warn)}.note{background:var(--card2);border:1px solid var(--border);border-left:3px solid var(--accent);border-radius:9px;padding:12px 14px;font-size:12.5px;color:var(--dim);line-height:1.75}.steps{list-style:none;counter-reset:st}.steps li{counter-increment:st;position:relative;padding:0 0 15px 32px;font-size:13px;color:var(--dim)}.steps li::before{content:counter(st);position:absolute;left:0;top:1px;width:22px;height:22px;border-radius:50%;background:var(--accent-dim);color:var(--accent);display:flex;align-items:center;justify-content:center;font-size:11.5px;font-weight:700}.steps li b{color:var(--text)}.prog{height:9px;border-radius:7px;background:var(--card2);overflow:hidden;margin:10px 0}.prog>div{height:100%;width:0;border-radius:7px;background:linear-gradient(90deg,var(--ok),var(--accent));transition:width .5s}.qr{display:flex;justify-content:center;padding:12px 0 2px}.qr img{width:170px;height:170px;image-rendering:pixelated;border-radius:10px;background:#fff;padding:8px}.dz{border:1px solid var(--err);border-radius:14px;padding:16px;background:var(--err-dim);margin-bottom:16px}.dz h3{font-size:14px;color:var(--err);margin-bottom:8px}.fgrp{border:1px solid var(--border);border-radius:11px;padding:12px;margin-bottom:12px}.fgrp-t{font-size:12px;font-weight:600;color:var(--dim);margin-bottom:9px}.bgfx{position:fixed;inset:0;z-index:0;overflow:hidden;pointer-events:none}.bgfx i{position:absolute;display:block;border-radius:50%;filter:blur(74px);opacity:var(--blob-o);will-change:transform}.bgfx i:nth-child(1){width:46vw;height:46vw;left:-12vw;top:-16vh;background:var(--accent);animation:blob 24s ease-in-out infinite}.bgfx i:nth-child(2){width:38vw;height:38vw;right:-14vw;top:2vh;background:var(--accent2);opacity:calc(var(--blob-o) * .72);animation:blob 30s ease-in-out infinite -8s}.bgfx i:nth-child(3){width:34vw;height:34vw;left:20vw;bottom:-22vh;background:#f472b6;opacity:calc(var(--blob-o) * .55);animation:blob 27s ease-in-out infinite -14s}.bgfx i:nth-child(4){width:30vw;height:30vw;right:10vw;bottom:-16vh;background:#38bdf8;opacity:calc(var(--blob-o) * .5);animation:blob 33s ease-in-out infinite -20s}@keyframes blob{0%,100%{transform:translate3d(0,0,0) scale(1)}33%{transform:translate3d(4vw,4vh,0) scale(1.1)}66%{transform:translate3d(-3vw,2vh,0) scale(.94)}}.app{position:relative;z-index:1}.sidebar{background:var(--sb-glass);-webkit-backdrop-filter:blur(30px) saturate(190%);backdrop-filter:blur(30px) saturate(190%);border:1px solid var(--glass-line);border-radius:22px;corner-shape:squircle;isolation:isolate;box-shadow:var(--glass-sh),inset 0 1px 0 var(--glass-hi),0 0 0 1px rgba(255,255,255,.03)}.sidebar::before{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;z-index:0;background:radial-gradient(520px 400px at var(--mx,50%) var(--my,-16%),var(--glass-hi),transparent 62%),linear-gradient(180deg,var(--sb-vol-a) 0,rgba(0,0,0,0) 32%,rgba(0,0,0,0) 60%,var(--sb-vol-b) 100%)}.sidebar::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1px;pointer-events:none;z-index:1;background:linear-gradient(150deg,var(--sb-rim) 0,rgba(255,255,255,0) 34%,rgba(255,255,255,0) 66%,var(--sb-rim) 100%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude}.sidebar>*{position:relative;z-index:2}.side-foot{border-top:1px solid var(--glass-line)}.nav::-webkit-scrollbar{width:8px}.nav::-webkit-scrollbar-thumb{background:var(--glass-field-brd);border-radius:8px}.nav-item{border-radius:12px}.nav-item:hover{background:var(--glass-hover)}.nav-item.on{background:var(--sb-active-bg);box-shadow:inset 0 1px 0 var(--glass-hi),0 6px 18px rgba(0,0,0,.16)}.topbar{background:var(--glass-2);-webkit-backdrop-filter:blur(20px) saturate(180%);backdrop-filter:blur(20px) saturate(180%);border:1px solid var(--glass-line);box-shadow:var(--glass-sh),inset 0 1px 0 var(--glass-hi)}.topbar::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1px;pointer-events:none;background:linear-gradient(150deg,var(--glass-rim) 0,rgba(255,255,255,0) 36%,rgba(255,255,255,0) 64%,var(--glass-rim) 100%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude}.ibtn{position:relative;background:var(--glass-field);border:1px solid var(--glass-field-brd);border-radius:11px;box-shadow:inset 0 1px 0 var(--glass-hi);transition:.18s cubic-bezier(.34,1.4,.64,1)}.ibtn:hover{background:var(--glass);border-color:var(--glass-rim);color:var(--accent);transform:translateY(-1px)}.ibtn:active{transform:translateY(0) scale(.96)}.card{position:relative;background:var(--glass);-webkit-backdrop-filter:blur(var(--glass-blur)) saturate(170%);backdrop-filter:blur(var(--glass-blur)) saturate(170%);border:1px solid var(--glass-line);border-radius:20px;corner-shape:squircle;box-shadow:var(--glass-sh),inset 0 1px 0 var(--glass-hi)}.card>*{position:relative;z-index:1}.card::before{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;z-index:0;background:radial-gradient(440px 260px at var(--mx,50%) var(--my,-12%),var(--glass-hi),transparent 68%)}.card::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1px;pointer-events:none;z-index:0;background:linear-gradient(150deg,var(--glass-rim) 0,rgba(255,255,255,0) 32%,rgba(255,255,255,0) 64%,var(--glass-rim) 100%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude}.fgrp{background:var(--glass-field);border:1px solid var(--glass-field-brd);border-radius:14px;corner-shape:squircle}.note{background:var(--glass-field);border:1px solid var(--glass-field-brd);border-left:3px solid var(--accent);border-radius:14px}pre.code{background:var(--glass-field);border:1px solid var(--glass-field-brd);border-radius:14px}.msg{border-radius:13px}input[type=text],input[type=password],input[type=number],select,textarea{background:var(--glass-field);border:1px solid var(--glass-field-brd);border-radius:12px;box-shadow:inset 0 1px 0 var(--glass-hi)}.sp span{background:var(--glass-field);border:1px solid var(--glass-field-brd)}th{background:var(--glass-field)}.btn{background:var(--glass-field);border:1px solid var(--glass-field-brd);border-radius:13px;position:relative;box-shadow:inset 0 1px 0 var(--glass-hi),0 4px 14px rgba(0,0,0,.16);transition:.18s cubic-bezier(.34,1.4,.64,1)}.btn:hover{background:var(--glass);border-color:var(--glass-rim);color:var(--text);transform:translateY(-1px)}.btn:active{transform:translateY(0) scale(.985)}.btn.sm{border-radius:10px}.btn.pri{background:linear-gradient(135deg,var(--accent),var(--accent2));border-color:transparent;color:#0b0e14;box-shadow:0 8px 24px var(--accent-dim),inset 0 1px 0 rgba(255,255,255,.45);overflow:hidden}.btn.pri:hover{color:#0b0e14;filter:brightness(1.06)}.btn.pri::after{content:"";position:absolute;top:-60%;left:-40%;width:36%;height:220%;pointer-events:none;transform:rotate(16deg);background:linear-gradient(90deg,rgba(255,255,255,0),rgba(255,255,255,.6),rgba(255,255,255,0));opacity:0;transition:opacity .2s}.btn.pri:hover::after{opacity:1;animation:sheen .85s cubic-bezier(.4,0,.2,1)}@keyframes sheen{from{left:-40%}to{left:130%}}.bar .stat{background:var(--glass);-webkit-backdrop-filter:blur(18px) saturate(180%);backdrop-filter:blur(18px) saturate(180%);border:1px solid var(--glass-line);border-radius:14px;box-shadow:var(--glass-sh)}.toast{background:var(--glass);-webkit-backdrop-filter:blur(24px) saturate(180%);backdrop-filter:blur(24px) saturate(180%);border:1px solid var(--glass-line);border-radius:16px;box-shadow:var(--glass-sh)}.pill{box-shadow:inset 0 1px 0 rgba(255,255,255,.18)}.btn::before,.ibtn::before,.sp span::before,.pill::before,.nav-item.on::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1px;pointer-events:none;background:linear-gradient(160deg,var(--glass-rim-sm) 0,rgba(255,255,255,0) 42%,rgba(255,255,255,0) 58%,var(--glass-rim-sm) 100%);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);mask-composite:exclude}.btn{background:var(--glass-btn);border-radius:13px;box-shadow:inset 0 1px 0 var(--glass-hi),0 6px 18px rgba(0,0,0,.20),0 1px 2px rgba(0,0,0,.18)}.btn:hover{background:var(--glass-btn-hi);border-color:var(--glass-rim-sm);color:var(--text);transform:translateY(-1px);box-shadow:inset 0 1px 0 var(--glass-hi),0 10px 26px rgba(0,0,0,.26)}.bar .btn{box-shadow:inset 0 1px 0 var(--glass-hi),var(--glass-sh)}.ibtn{background:var(--glass-btn);box-shadow:inset 0 1px 0 var(--glass-hi),0 4px 12px rgba(0,0,0,.16)}.ibtn:hover{background:var(--glass-btn-hi)}.sp span{position:relative;background:var(--glass-btn);box-shadow:inset 0 1px 0 var(--glass-hi)}.sp input:checked+span{box-shadow:inset 0 1px 0 rgba(255,255,255,.35),0 4px 14px var(--accent-dim)}.pill{position:relative;box-shadow:inset 0 1px 0 rgba(255,255,255,.22)}.ver-chip{position:relative;box-shadow:inset 0 1px 0 rgba(255,255,255,.20)}.nav-item{border-radius:12px}.nav-item.on{background:linear-gradient(180deg,rgba(255,255,255,.10),rgba(255,255,255,0)),var(--sb-active-bg);box-shadow:inset 0 1px 0 var(--glass-hi),0 8px 20px rgba(0,0,0,.18)}.sw .sl{background:var(--glass-field);border:1px solid var(--glass-field-brd);box-shadow:inset 0 1px 2px rgba(0,0,0,.16)}.sw input:checked+.sl{background:linear-gradient(135deg,var(--accent),var(--accent2));border-color:transparent;box-shadow:inset 0 1px 0 rgba(255,255,255,.40),0 2px 10px var(--accent-dim)}.sw .sl::before{box-shadow:0 1px 4px rgba(0,0,0,.40)}.bdg{box-shadow:inset 0 1px 0 rgba(255,255,255,.20)}.fgrp,.note,pre.code{box-shadow:inset 0 1px 0 var(--glass-hi)}.msg{box-shadow:inset 0 1px 0 rgba(255,255,255,.14)}.prog{background:var(--glass-field);border:1px solid var(--glass-field-brd);box-shadow:inset 0 1px 2px rgba(0,0,0,.14)}.steps li::before{background:var(--accent-dim);box-shadow:inset 0 1px 0 rgba(255,255,255,.22)}.dz{background:var(--err-dim);border:1px solid rgba(248,113,113,.30);border-radius:18px;-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);box-shadow:var(--glass-sh)}@supports not ((backdrop-filter:blur(1px)) or (-webkit-backdrop-filter:blur(1px))){.sidebar,.topbar{background:var(--card2)}.card{background:var(--card)}.btn,.ibtn,.sp span{background:var(--card2)}.bar .stat,.toast{background:var(--card)}}@media(prefers-reduced-motion:reduce){.bgfx i{animation:none}.btn.pri:hover::after{animation:none;opacity:0}.ibtn:hover,.btn:hover{transform:none}.view.on{animation:none}}@media(max-width:640px){:root{--glass-blur:14px}.sidebar{-webkit-backdrop-filter:blur(18px) saturate(180%);backdrop-filter:blur(18px) saturate(180%)}.bgfx i:nth-child(3),.bgfx i:nth-child(4){display:none}}@media(max-width:960px){.sidebar{position:fixed;left:12px;top:12px;height:calc(100vh - 24px);background:var(--sb-glass-m);transform:translateX(calc(-100% - 28px));transition:transform .22s ease;z-index:70;box-shadow:var(--glass-sh),inset 0 1px 0 var(--glass-hi)}.sidebar.open{transform:translateX(0)}.ibtn.hamb{display:flex}.app{padding:10px;gap:10px}.wrap{padding:0 2px 92px}.topbar{padding:10px 14px;top:10px}}@media(max-width:560px){.topbar .pill{display:none}}[data-style="material"]{--bg:var(--m-surface);--bg2:var(--m-surface-container);--card:var(--m-surface-container-low);--card2:var(--m-surface-container);--border:var(--m-outline-variant);--line:var(--m-outline-variant);--text:var(--m-on-surface);--dim:var(--m-on-surface-variant);--faint:var(--m-outline);--accent:var(--m-primary);--accent2:var(--m-tertiary);--accent-dim:var(--m-primary-container);--ok:var(--m-primary);--ok-dim:var(--m-primary-container);--err:var(--m-error);--err-dim:var(--m-error-container);--warn:var(--m-tertiary);--glass-rim:transparent;--glass-rim-sm:transparent;--glass-hi:transparent;--sb-rim:transparent;--sb-vol-a:transparent;--sb-vol-b:transparent;--m-e1:0 1px 2px rgba(0,0,0,.42),0 1px 3px 1px rgba(0,0,0,.24);--m-e2:0 1px 2px rgba(0,0,0,.42),0 2px 6px 2px rgba(0,0,0,.24);--m-e3:0 1px 3px rgba(0,0,0,.42),0 4px 8px 3px rgba(0,0,0,.24);--shadow:var(--m-e2);font-family:Roboto,"Roboto Flex","Noto Sans SC","PingFang SC","Microsoft YaHei",system-ui,sans-serif}[data-theme="light"][data-style="material"]{--m-e1:0 1px 2px rgba(0,0,0,.16),0 1px 3px 1px rgba(0,0,0,.09);--m-e2:0 1px 2px rgba(0,0,0,.16),0 2px 6px 2px rgba(0,0,0,.09);--m-e3:0 1px 3px rgba(0,0,0,.16),0 4px 8px 3px rgba(0,0,0,.09)}[data-style="material"] .bgfx{display:none}[data-style="material"] .card::before,[data-style="material"] .card::after,[data-style="material"] .sidebar::before,[data-style="material"] .sidebar::after,[data-style="material"] .topbar::after{display:none}[data-style="material"] .sidebar{background:var(--m-surface-container-low);-webkit-backdrop-filter:none;backdrop-filter:none;border:none;border-radius:16px;box-shadow:var(--m-e1)}[data-style="material"] .brand .lg{border-radius:12px;box-shadow:none}[data-style="material"] .brand .bt b{font-weight:500}[data-style="material"] .nav-item{border-radius:28px;padding:10px 16px;font-size:14px}[data-style="material"] .nav-item.on::before{display:none}[data-style="material"] .nav-item.on{background:var(--m-secondary-container);color:var(--m-on-secondary-container);font-weight:500;box-shadow:none}[data-style="material"] .nav-item:hover{background:transparent;color:var(--text)}[data-style="material"] .side-foot{border-top:1px solid var(--m-outline-variant)}[data-style="material"] .ver-chip{background:var(--m-secondary-container);color:var(--m-on-secondary-container);border-radius:8px;box-shadow:none}[data-style="material"] .topbar{background:var(--m-surface);-webkit-backdrop-filter:none;backdrop-filter:none;border:none;border-radius:16px;box-shadow:none}[data-style="material"] .topbar h1{font-weight:400;font-size:20px}[data-style="material"] .ibtn{background:transparent;border:none;border-radius:50%;color:var(--m-on-surface-variant);box-shadow:none;overflow:hidden}[data-style="material"] .ibtn:hover{background:transparent;color:var(--m-on-surface)}[data-style="material"] .ibtn:active{transform:none}[data-style="material"] .pill{background:var(--m-secondary-container);color:var(--m-on-secondary-container);border-radius:8px;box-shadow:none;padding:5px 12px;font-weight:500}[data-style="material"] .card{background:var(--m-surface-container-low);border:none;border-radius:16px;box-shadow:var(--m-e1);-webkit-backdrop-filter:none;backdrop-filter:none}[data-style="material"] .card h3{font-weight:500}[data-style="material"] .card h3 .dot{background:var(--m-primary)}[data-style="material"] .fgrp,[data-style="material"] .note,[data-style="material"] pre.code{background:var(--m-surface-container);border:1px solid var(--m-outline-variant);border-radius:12px;box-shadow:none}[data-style="material"] .note{border-left:1px solid var(--m-outline-variant)}[data-style="material"] .msg{border-radius:12px;box-shadow:none}[data-style="material"] input[type=text],[data-style="material"] input[type=password],[data-style="material"] input[type=number],[data-style="material"] select,[data-style="material"] textarea{background:transparent;border:1px solid var(--m-outline);border-radius:8px;box-shadow:none}[data-style="material"] input:focus,[data-style="material"] select:focus,[data-style="material"] textarea:focus{border-color:var(--m-primary);box-shadow:inset 0 0 0 1px var(--m-primary)}[data-style="material"] th{background:var(--m-surface-container);font-weight:500}[data-style="material"] .bdg{box-shadow:none;background:var(--m-secondary-container);color:var(--m-on-secondary-container)}[data-style="material"] .box{background:var(--m-surface-container-high);border:none;border-radius:28px;-webkit-backdrop-filter:none;backdrop-filter:none;box-shadow:var(--m-e3);corner-shape:round}[data-style="material"] .box::after{display:none}[data-style="material"] .logo{background:var(--m-primary-container);border-radius:16px;box-shadow:none}[data-style="material"] .logo svg{stroke:var(--m-on-primary-container)}[data-style="material"] .box p{color:var(--m-on-surface-variant)}[data-style="material"] .btn{background:var(--m-secondary-container);color:var(--m-on-secondary-container);border:none;border-radius:20px;box-shadow:none;font-weight:500;-webkit-mask:none;overflow:hidden}[data-style="material"] .btn:hover{background:var(--m-secondary-container);color:var(--m-on-secondary-container);transform:none;box-shadow:var(--m-e1)}[data-style="material"] .btn:active{transform:none}[data-style="material"] .btn.pri{background:var(--m-primary);color:var(--m-on-primary);box-shadow:none;border-radius:20px}[data-style="material"] .btn.pri:hover{background:var(--m-primary);color:var(--m-on-primary);box-shadow:var(--m-e1);filter:none}[data-style="material"] .btn.pri::after{display:none}[data-style="material"] .btn.sm{border-radius:18px}[data-style="material"] .btn.dgr{background:var(--m-error);color:var(--m-on-error)}[data-style="material"] .sp span{background:transparent;border:1px solid var(--m-outline);color:var(--m-on-surface-variant);border-radius:20px;box-shadow:none}[data-style="material"] .sp input:checked+span{background:var(--m-secondary-container);color:var(--m-on-secondary-container);border-color:transparent;box-shadow:none}[data-style="material"] .btn::before,[data-style="material"] .ibtn::before,[data-style="material"] .sp span::before,[data-style="material"] .nav-item::before{content:"";position:absolute;inset:0;border-radius:inherit;background:currentColor;opacity:0;-webkit-mask:none;mask:none;pointer-events:none;transition:opacity .12s}[data-style="material"] .btn:hover::before,[data-style="material"] .ibtn:hover::before,[data-style="material"] .sp span:hover::before,[data-style="material"] .nav-item:hover::before{opacity:.08}[data-style="material"] .btn:active::before,[data-style="material"] .ibtn:active::before,[data-style="material"] .sp span:active::before{opacity:.12}[data-style="material"] .card,.md-rip-host{position:relative}[data-style="material"] .nav-item,[data-style="material"] .sp span,[data-style="material"] .pill,[data-style="material"] .fgrp{position:relative;overflow:hidden}.md-rip{position:absolute;border-radius:50%;pointer-events:none;background:currentColor;opacity:0;transform:scale(0);animation:mdRip .62s cubic-bezier(.2,0,0,1) forwards}@keyframes mdRip{0%{opacity:.20;transform:scale(.25)}55%{opacity:.14}100%{opacity:0;transform:scale(1)}}@media(prefers-reduced-motion:reduce){.md-rip{display:none}}[data-style="material"] .sw .sl{background:var(--m-surface-container-highest);border:1px solid var(--m-outline);box-shadow:none}[data-style="material"] .sw input:checked+.sl{background:var(--m-primary);border-color:var(--m-primary);box-shadow:none}[data-style="material"] .sw .sl::before{box-shadow:0 1px 3px rgba(0,0,0,.30)}[data-style="material"] .prog{background:var(--m-surface-container-highest);border:none;border-radius:4px;box-shadow:none;height:8px}[data-style="material"] .prog>div{border-radius:4px;background:var(--m-primary)}[data-style="material"] .steps li::before{background:var(--m-primary-container);color:var(--m-on-primary-container);box-shadow:none}[data-style="material"] .dz{background:var(--m-error-container);border:none;border-radius:16px;-webkit-backdrop-filter:none;backdrop-filter:none;box-shadow:none}[data-style="material"] .dz h3{color:var(--m-on-error-container)}[data-style="material"] .dz p{color:var(--m-on-error-container)}[data-style="material"] .bar .stat,[data-style="material"] .toast{background:var(--m-surface-container-high);-webkit-backdrop-filter:none;backdrop-filter:none;border:none;border-radius:12px;box-shadow:var(--m-e3);color:var(--text)}[data-style="material"] .bar .btn{box-shadow:var(--m-e2)}[data-style="material"] .qr img{border-radius:12px}.seg{display:flex;gap:8px;flex-wrap:wrap}.seg button{flex:1;min-width:120px;justify-content:center}.seg button.on{background:var(--accent);color:#fff;border-color:transparent}[data-style="material"] .seg button.on{background:var(--m-primary);color:var(--m-on-primary)}.md-sw{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.md-sw i{width:30px;height:30px;border-radius:50%;cursor:pointer;display:block;box-shadow:0 0 0 1px var(--border);transition:transform .15s}.md-sw i:hover{transform:scale(1.1)}.md-sw i.on{box-shadow:0 0 0 2px var(--accent),0 0 0 4px var(--bg2)}.md-pal{margin-top:14px;border:1px solid var(--border);border-radius:12px;overflow:hidden}.md-pal .r{display:flex;align-items:center;gap:2px;padding:3px 6px}.md-pal .r b{width:66px;flex:0 0 66px;font-size:10.5px;font-weight:500;color:var(--dim);font-family:ui-monospace,Consolas,monospace}.md-pal .r i{flex:1;height:20px;border-radius:4px;display:block;cursor:pointer;position:relative;z-index:0;transition:transform .12s ease,box-shadow .12s ease}.md-pal .r:hover b{color:var(--text)}.md-pal .r i:hover{transform:scale(1.16);z-index:3;box-shadow:0 0 0 1.5px var(--text),0 4px 10px rgba(0,0,0,.45)}.md-pal .r i.on{z-index:2;box-shadow:inset 0 0 0 2px rgba(255,255,255,.94),inset 0 0 0 4px rgba(0,0,0,.56)}.md-pal .r:first-child i{border-radius:6px 6px 4px 4px}.md-pal .r:last-child i{border-radius:4px 4px 6px 6px}.md-out{display:flex;align-items:center;gap:9px;margin-top:10px;flex-wrap:wrap;font-size:12px}.md-out .chip{width:20px;height:20px;border-radius:6px;flex:0 0 20px;display:block;box-shadow:0 0 0 1px var(--border)}.md-out .hx{font-family:ui-monospace,Consolas,monospace;color:var(--text);cursor:pointer;letter-spacing:.4px;padding:3px 7px;border-radius:7px;background:var(--bg2);box-shadow:0 0 0 1px var(--border)}.md-out .hx:hover{background:var(--card2)}.md-out .tag{color:var(--faint)}.md-seed{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.md-seed i{width:34px;height:34px;border-radius:9px;cursor:pointer;display:block;box-shadow:0 0 0 1px var(--border);transition:transform .15s}.md-seed i:hover{transform:scale(1.08)}.md-seed i.on{box-shadow:0 0 0 2px var(--accent),0 0 0 4px var(--bg2)}

/* ===== CFNext \u81EA\u6709\u7EC4\u4EF6\u5C42\uFF1A\u5BF9\u9F50\u53C2\u8003\u9762\u677F\u89C6\u89C9 ===== */
.view-head{margin-bottom:16px}
.view-head h2{font-size:20px;font-weight:700}
.view-head p{color:var(--dim);font-size:13px;margin-top:4px}
.mark{width:34px;height:34px;flex:0 0 34px;border-radius:10px;background:linear-gradient(135deg,var(--accent),var(--accent2));display:flex;align-items:center;justify-content:center;box-shadow:0 4px 12px var(--accent-dim)}
.mark svg{width:19px;height:19px}
.mark path{stroke:#fff}
.fold{display:none}
.fold.open{display:block}
.foldbtn{margin-left:auto;flex:0 0 26px;width:26px;height:26px;padding:0;border:1px solid var(--border);border-radius:8px;background:var(--card2);color:var(--dim);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:color .18s,border-color .18s,background .18s}
.foldbtn:hover{color:var(--text);border-color:var(--accent);background:var(--accent-dim)}
.foldbtn svg{width:14px;height:14px;transition:transform .2s ease}
.foldbtn[data-open="1"] svg{transform:rotate(180deg)}
.foldbtn path{fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.card h3 .tick{width:4px;height:15px;border-radius:3px;background:linear-gradient(var(--accent),var(--accent2))}
.btn.primary{background:linear-gradient(135deg,var(--accent),var(--accent2));border-color:transparent;color:#fff;font-weight:600}
.btn.primary:hover{filter:brightness(1.06);color:#fff}
.spill input:checked + span{background:var(--accent);border-color:var(--accent);color:#fff;font-weight:600}
.note-box{background:var(--card2);border:1px solid var(--border);border-left:3px solid var(--accent);border-radius:10px;padding:12px 14px;font-size:12.5px;color:var(--dim);line-height:1.7;margin-bottom:12px}
.danger-zone{border:1px solid var(--err);border-radius:14px;padding:16px;background:var(--err-dim)}
.steps li::before{background:var(--accent-dim);color:var(--accent)}
[data-theme="light"] .steps li::before{color:var(--accent)}
.msg.info{background:var(--accent-dim);color:var(--accent)}
[data-theme="light"] .msg.info{color:var(--accent)}
.qrbox img{border-radius:12px}
.mmodebox{border-radius:16px}
.mmodecard{border-radius:14px}
/* \u5F00\u5173\u6ED1\u5757\u672C\u4F53\uFF1ACFNext \u7684 DOM \u662F label.switch>span.sl\uFF08\u65E0 .sw \u7956\u5148\uFF09\uFF0Cnimbus \u7684 .sw .sl \u4E0D\u5339\u914D\uFF0C\u987B\u5355\u72EC\u8865\u56DE */
.switch .sl{position:absolute;inset:0;background:var(--glass-field);border:1px solid var(--glass-field-brd);border-radius:22px;cursor:pointer;transition:.18s;box-shadow:inset 0 1px 2px rgba(0,0,0,.16)}
.switch .sl::before{content:"";position:absolute;width:16px;height:16px;left:3px;top:3px;background:#fff;border-radius:50%;transition:transform .18s;box-shadow:0 1px 4px rgba(0,0,0,.40)}
.switch input:checked+.sl{background:linear-gradient(135deg,var(--accent),var(--accent2));border-color:transparent;box-shadow:inset 0 1px 0 rgba(255,255,255,.40),0 2px 10px var(--accent-dim)}
.switch input:checked+.sl::before{transform:translateX(18px)}
[data-style="material"] .switch .sl{background:var(--m-surface-container-highest);border:1px solid var(--m-outline);box-shadow:none}
[data-style="material"] .switch input:checked+.sl{background:var(--m-primary);border-color:var(--m-primary);box-shadow:none}
[data-style="material"] .switch .sl::before{box-shadow:0 1px 3px rgba(0,0,0,.30)}
/* \u6309\u94AE\u7EDF\u4E00\u6DB2\u6001\u73BB\u7483\uFF1A\u534A\u900F\u660E + \u6A21\u7CCA + \u5185\u9AD8\u5149\uFF0C\u4E0E\u5361\u7247/\u8F93\u5165\u6846\u540C\u4E00\u6750\u8D28 */
.btn{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:var(--text);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);box-shadow:inset 0 1px 0 rgba(255,255,255,.14),0 2px 8px rgba(0,0,0,.18);transition:border-color .15s,color .15s,box-shadow .15s,transform .15s}
[data-theme="light"] .btn{background:rgba(255,255,255,.55);border:1px solid rgba(30,45,70,.10);box-shadow:inset 0 1px 0 rgba(255,255,255,.90),0 2px 8px rgba(30,45,70,.06)}
.btn:hover{border-color:var(--accent);color:var(--accent);box-shadow:inset 0 1px 0 rgba(255,255,255,.18),0 4px 14px var(--accent-dim)}
.btn.pri,.btn.primary{background:linear-gradient(135deg,var(--accent),var(--accent2));border-color:rgba(255,255,255,.18);color:#fff;box-shadow:inset 0 1px 0 rgba(255,255,255,.35),0 6px 18px var(--accent-dim)}
.btn.pri:hover,.btn.primary:hover{filter:brightness(1.08);color:#fff;box-shadow:inset 0 1px 0 rgba(255,255,255,.45),0 8px 22px var(--accent-dim)}
.btn.dgr,.btn.danger{background:var(--err-dim);border-color:rgba(248,113,113,.28);color:var(--err);box-shadow:inset 0 1px 0 rgba(255,255,255,.10)}
.ibtn{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);box-shadow:inset 0 1px 0 rgba(255,255,255,.14)}
[data-theme="light"] .ibtn{background:rgba(255,255,255,.55);border-color:rgba(30,45,70,.10);box-shadow:inset 0 1px 0 rgba(255,255,255,.90)}
.nav-item{background:transparent;border-color:transparent}
.nav-item.on,.nav-item:hover{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.12);box-shadow:inset 0 1px 0 rgba(255,255,255,.12)}
[data-theme="light"] .nav-item.on,[data-theme="light"] .nav-item:hover{background:rgba(255,255,255,.55);border-color:rgba(30,45,70,.08);box-shadow:inset 0 1px 0 rgba(255,255,255,.90)}
@media (max-width:960px){.grid2,.grid3{grid-template-columns:1fr}}

</style>
</head>
<body><div class="bgfx" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
<div class="app">

<!-- ===== \u4FA7\u8FB9\u680F ===== -->
<aside class="sidebar" id="sidebar">
  <div class="brand">
    <div class="mark"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h4l3-7 4 14 3-7h2"/></svg></div>
    <div class="bt"><b>CFNext</b><span>Cloudflare \u96A7\u9053\u9762\u677F</span></div>
  </div>
  <nav class="nav" id="nav"></nav>
  <div class="side-foot">
    <span>\u90E8\u7F72\u7248\u672C</span>
    <span class="ver-chip" id="sideVer" title="\u70B9\u51FB\u68C0\u6D4B\u66F4\u65B0" onclick="checkUpdate()">v\u2014</span>
  </div>
</aside>

<!-- ===== \u4E3B\u533A ===== -->
<div class="main">
  <div class="topbar">
    <button class="ibtn hamb" id="hamb" title="\u83DC\u5355"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>
    <h1 id="pageTitle">\u4EEA\u8868\u76D8</h1>
    <span class="pill" id="connPill"><span class="dot"></span><span id="connText">\u8FDE\u63A5\u4E2D</span></span>
    <button class="ibtn" id="themeBtn" title="\u5207\u6362\u65E5\u95F4 / \u591C\u95F4"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path id="themeIcon" d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg></button><button class="ibtn" id="exitBtn" title="\u9000\u51FA\u5F53\u524D\u6A21\u5F0F\uFF0C\u56DE\u5230\u6A21\u5F0F\u9009\u62E9" onclick="exitMode()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg></button>
  </div>
  <div class="wdwarn" id="wdwarn">\u5F53\u524D\u8FD0\u884C\u5728 *.workers.dev \u57DF\u540D\u4E0A\uFF1A\u8BA2\u9605\u4E0E\u8282\u70B9\u4E0B\u53D1\u529F\u80FD\u6B63\u5E38\uFF1B\u82E5\u9047\u8FDE\u63A5\u4E0D\u7A33\u6216\u8BBF\u95EE\u53D7\u9650\uFF0C\u5EFA\u8BAE\u5728 Cloudflare \u9762\u677F\u7ED1\u5B9A\u81EA\u5B9A\u4E49\u57DF\u540D\u540E\u4F7F\u7528\u3002</div>

  <div class="wrap" id="content">
    <!-- ===== \u89C6\u56FE\uFF1A\u4EEA\u8868\u76D8 ===== -->
    <section class="view" data-view="dashboard">
      <div class="view-head"><h2>\u4EEA\u8868\u76D8</h2><p>\u5FEB\u901F\u5F00\u59CB\u3001\u8BA2\u9605\u7BA1\u7406\u3001\u914D\u989D\u901F\u89C8\u4E0E\u8FD0\u884C\u72B6\u6001</p></div>
      <div class="card">
        <h3><span class="tick"></span>\u5FEB\u901F\u5F00\u59CB</h3>
        <ol class="steps">
          <li><b>\u90E8\u7F72\u5373\u7528</b>\uFF1A\u7ED1\u5B9A\u57DF\u540D\u540E\u5BA2\u6237\u7AEF\u8BA2\u9605\u5373\u53EF\u83B7\u5F97\u6D77\u91CF\u8282\u70B9\uFF08\u5185\u7F6E 300 \u6761\u4F18\u9009 IP \u4E0E\u5730\u533A\u57DF\u540D\u6E90\uFF09\uFF0C\u9ED8\u8BA4\u5DF2\u914D\u597D\u5927\u9646\u76F4\u8FDE\u5206\u6D41\uFF08\u5927\u9646\u5E94\u7528\u3001\u5FAE\u8F6F\u3001\u82F9\u679C\u76F4\u8FDE\uFF0C\u56FD\u5916\u670D\u52A1\u8D70\u51FA\u53E3\uFF09\u3002</li>
          <li><b>\u8C03\u4F18\u8282\u70B9</b>\uFF1A\u5728\u300C\u4F18\u9009\u914D\u7F6E\u300D\u5728\u7EBF\u6D4B\u901F\uFF0C\u628A\u6700\u4F18 IP \u52A0\u5165\u4F18\u9009\u5217\u8868\uFF08\u81EA\u5B9A\u4E49\u8BA2\u9605\u6A21\u5F0F\u5185\u7F6E\u5E38\u7528\u8BA2\u9605\u6E90\uFF0C\u53EF\u81EA\u884C\u589E\u5220\uFF0C\u53EF\u8FFD\u52A0\u5185\u7F6E\u4F18\u9009\u6C60\u4E0E\u9ED8\u8BA4\u8282\u70B9\uFF09\u3002</li>
          <li><b>\u4FDD\u969C\u989D\u5EA6</b>\uFF1A\u5728\u300C\u914D\u989D\u5B89\u5168\u300D\u5F00\u542F\u7528\u91CF\u76D1\u63A7\u4E0E\u81EA\u52A8\u8C03\u8282\uFF0C\u9632\u6B62\u514D\u8D39\u989D\u5EA6\u8D85\u652F\uFF08\u9700\u5728\u9762\u677F\u8BBE\u7F6E\u4E2D\u914D\u7F6E Cloudflare \u8D26\u6237 ID \u4E0E API \u4EE4\u724C\uFF09\u3002</li>
        </ol>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u8BA2\u9605\u5730\u5740</h3>
        <div class="row" style="margin-bottom:12px">
          <div class="field grow" style="margin:0"><label>\u8BA2\u9605\u683C\u5F0F</label>
            <select id="subFmt">
              <option value="auto">\u81EA\u52A8\u8BC6\u522B</option>
              <option value="clash">Clash / Mihomo</option>
              <option value="singbox">Sing-box</option>
              <option value="karing">Karing</option>
              <option value="surge">Surge</option>
              <option value="surfboard">Surfboard</option>
              <option value="loon">Loon</option>
              <option value="quanx">Quantumult X</option>
              <option value="v2ray">v2rayN / Shadowrocket</option>
              <option value="stash">Stash</option>
              <option value="plain">\u660E\u6587 vless</option>
            </select>
          </div>
        </div>
        <div class="field"><label>\u8BA2\u9605\u94FE\u63A5</label>
          <div class="inrow">
            <input type="text" id="subUrl" readonly onclick="this.select()">
            <button class="btn sm" onclick="copySub()">\u590D\u5236</button>
            <button class="btn sm" onclick="toggleQR()">\u4E8C\u7EF4\u7801</button>
            <button class="btn sm" onclick="downloadSub()">\u4E0B\u8F7D</button>
            <button class="btn sm primary" onclick="previewSub()">\u9884\u89C8</button>
          </div>
        </div>
        <div id="qrWrap" style="display:none"></div>
        <p class="hint" style="margin-top:12px" id="subHint"></p>
        <div id="subPrev" style="display:none;margin-top:12px">
          <div class="kv"><span class="k">\u8BA2\u9605\u7C7B\u578B</span><span class="v" id="prevType">\u2014</span></div>
          <div class="kv"><span class="k">\u8282\u70B9\u6570\u91CF</span><span class="v" id="prevCount">\u2014</span></div>
          <pre class="code" id="prevBody" style="margin-top:10px"></pre>
        </div>
      </div>
      <div class="card" id="cardFilter">
        <h3><span class="tick"></span>\u5730\u533A\u4E0E\u7EBF\u8DEF\u7B5B\u9009</h3>
        <div class="filter-region">
          <span class="filter-region-label">\u8282\u70B9\u5730\u533A</span>
          <div class="pills">
            <label class="spill"><input type="checkbox" id="fl-region-all" checked><span>\u5168\u90E8\u5730\u533A</span></label>
            <label class="spill"><input type="checkbox" id="fl-region-HK"><span>\u9999\u6E2F</span></label>
            <label class="spill"><input type="checkbox" id="fl-region-TW"><span>\u53F0\u6E7E</span></label>
            <label class="spill"><input type="checkbox" id="fl-region-US"><span>\u7F8E\u56FD</span></label>
            <label class="spill"><input type="checkbox" id="fl-region-SG"><span>\u65B0\u52A0\u5761</span></label>
            <label class="spill"><input type="checkbox" id="fl-region-JP"><span>\u65E5\u672C</span></label>
            <label class="spill"><input type="checkbox" id="fl-region-KR"><span>\u97E9\u56FD</span></label>
            <label class="spill"><input type="checkbox" id="fl-region-DE"><span>\u5FB7\u56FD</span></label>
          </div>
        </div>
        <div class="filter-row">
          <div class="filter-group">
            <div class="filter-group-title">IP \u7C7B\u578B</div>
            <div class="pills">
              <label class="spill"><input type="checkbox" id="fl-ip4" checked><span>IPv4</span></label>
              <label class="spill"><input type="checkbox" id="fl-ip6"><span>IPv6</span></label>
            </div>
          </div>
          <div class="filter-group">
            <div class="filter-group-title">IPv6 \u4E0B\u53D1</div>
            <div class="pills nowrap">
              <label class="spill"><input type="radio" name="ip6mode" id="ip6-off" value="off" checked><span>\u4E0D\u4E0B\u53D1</span></label>
              <label class="spill"><input type="radio" name="ip6mode" id="ip6-tail" value="tail"><span>\u4EC5\u5907\u80CE</span></label>
              <label class="spill"><input type="radio" name="ip6mode" id="ip6-full" value="full"><span>\u7B49\u6743\u6DF7\u5408</span></label>
            </div>
          </div>
          <div class="filter-group">
            <div class="filter-group-title">\u8FD0\u8425\u5546\u504F\u597D</div>
            <div class="pills">
              <label class="spill"><input type="checkbox" id="fl-isp-m" checked><span>\u79FB\u52A8</span></label>
              <label class="spill"><input type="checkbox" id="fl-isp-c" checked><span>\u8054\u901A</span></label>
              <label class="spill"><input type="checkbox" id="fl-isp-t" checked><span>\u7535\u4FE1</span></label>
            </div>
          </div>
          <div class="filter-group">
            <div class="filter-group-title">\u5730\u5740\u6765\u6E90</div>
            <div class="pills nowrap">
              <label class="spill"><input type="checkbox" id="fl-native"><span>\u539F\u751F\u5730\u5740</span></label>
              <label class="spill"><input type="checkbox" id="fl-pref-domain" checked><span>\u4F18\u9009\u57DF\u540D</span></label>
              <label class="spill"><input type="checkbox" id="fl-pref-ip" checked><span>\u4F18\u9009 IP</span></label>
              <label class="spill"><input type="checkbox" id="fl-custom-pref"><span>\u81EA\u5B9A\u4E49\u4F18\u9009</span></label>
              <label class="spill"><input type="checkbox" id="fl-random-pref"><span>\u968F\u673A\u4F18\u9009</span></label>
            </div>
          </div>
        </div>
        <p class="hint" style="margin-top:12px">\u300C\u8282\u70B9\u5730\u533A\u300D\u591A\u9009\u8FC7\u6EE4\u5730\u533A\uFF1B\u300C\u8FD0\u8425\u5546\u504F\u597D\u300D\u6309\u8282\u70B9\u540D\u79F0\u4E2D\u7684\u8FD0\u8425\u5546\u6807\u8BB0\u8FC7\u6EE4\uFF08\u79FB\u52A8/\u8054\u901A/\u7535\u4FE1\uFF09\uFF0C\u65E0\u6807\u8BB0\u65F6\u4E0D\u751F\u6548\uFF1B\u300C\u5730\u5740\u6765\u6E90\u300D\u63A7\u5236\u4E0B\u53D1\u6765\u6E90\uFF08\u539F\u751F\u5730\u5740/\u4F18\u9009\u57DF\u540D/\u4F18\u9009 IP/\u81EA\u5B9A\u4E49\u4F18\u9009/\u968F\u673A\u4F18\u9009\uFF09\u3002\u4EFB\u4E00\u7EF4\u5EA6\u65E0\u8282\u70B9\u65F6\u81EA\u52A8\u653E\u5BBD\uFF0C\u4FDD\u8BC1\u8BA2\u9605\u975E\u7A7A\u3002<br>
          <b>IPv6 \u4E0B\u53D1</b>\uFF08\u6E05\u5355\u8D28\u91CF\uFF09\uFF1AIPv6 \u5230 CF \u7684\u53EF\u8FBE\u6027\u53D6\u51B3\u4E8E\u5BA2\u6237\u7AEF\u6240\u5728\u7F51\u7EDC\uFF0C\u4E0D\u5C11\u5BB6\u5EAD\u5BBD\u5E26 v6 \u5230 CF \u7684\u8DEF\u5F84\u6BD4 v4 \u5DEE\u751A\u81F3\u4E0D\u901A\uFF0CIPv6 \u8282\u70B9\u5728\u5BA2\u6237\u7AEF\u9010\u8282\u70B9\u6D4B\u5EF6\u8FDF\u65F6\u4F1A\u88AB\u5927\u91CF\u8D85\u65F6\u9879\u62D6\u957F\u3002<b>\u300C\u4E0D\u4E0B\u53D1\u300D\u4E3A\u9ED8\u8BA4</b>\u2014\u2014\u5373\u4F7F\u52FE\u9009\u4E86\u300CIPv6\u300D\u4E5F\u4E0D\u8FDB\u6E05\u5355\uFF1B\u300C\u4EC5\u5907\u80CE\u300D= \u5360\u6BD4\u5C01\u9876 10% \u4E14\u6574\u4F53\u6392\u5230\u5217\u8868\u5C3E\u90E8\uFF0CIPv4 \u6253\u5934\uFF1B\u300C\u7B49\u6743\u6DF7\u5408\u300D= \u65E7\u884C\u4E3A\u3002\u4EC5\u52FE\u9009 IPv6\uFF08\u5355\u9009\uFF09\u65F6\u7B56\u7565\u81EA\u52A8\u8BA9\u4F4D\uFF0C\u4FDD\u8BC1\u8BA2\u9605\u4E0D\u4E3A\u7A7A\u3002</p>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u914D\u989D\u901F\u89C8 <span class="sub" id="dbSub">\u672A\u914D\u7F6E\u76D1\u63A7</span></h3>
        <div id="dbWrap" style="display:none">
          <div class="kv"><span class="k">\u5F53\u65E5\u8BF7\u6C42\u91CF</span><span class="v" id="dbReq">\u2014</span></div>
          <div style="margin:10px 0 6px;height:8px;border-radius:6px;background:var(--card2);overflow:hidden">
            <div id="dbBar" style="height:100%;width:0%;border-radius:6px;background:linear-gradient(90deg,var(--ok),var(--accent));transition:width .5s"></div>
          </div>
          <div class="kv"><span class="k">\u5DF2\u7528\u989D\u5EA6</span><span class="v" id="dbPct">\u2014</span></div>
        </div>
        <p class="hint" style="margin-top:10px">\u514D\u8D39\u8BA1\u5212\u6309 Cloudflare \u8D26\u53F7\u8BA1\u7B97\uFF1A\u6BCF\u4E2A\u8D26\u53F7\u6BCF\u5929\u5171\u7528 100,000 \u6B21 Workers / Pages Functions \u8BF7\u6C42\u989D\u5EA6\u3002\u540C\u8D26\u53F7\u4E0B\u6240\u6709\u9879\u76EE\u5408\u5E76\u8BA1\u7B97\uFF0C\u4E0D\u540C\u8D26\u53F7\u5206\u522B\u7EDF\u8BA1\uFF1B\u8BF7\u5728\u300C\u914D\u989D\u5B89\u5168 \u2192 \u591A\u8D26\u53F7\u914D\u989D\u76D1\u63A7\u300D\u67E5\u770B\u5404\u8D26\u53F7\u7528\u91CF\u3002</p>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u8FD0\u884C\u72B6\u6001</h3>
        <div class="kv"><span class="k">\u534F\u8BAE</span><span class="v" id="stProto">\u2014</span><span class="mbadge" id="stMode">\u2014</span></div>
        <div class="kv"><span class="k">KV \u6301\u4E45\u5316</span><span class="v" id="stKv">\u2014</span></div>
        <div class="kv"><span class="k">\u9762\u677F\u5165\u53E3</span><span class="v" id="stEntry">\u2014</span></div>
      </div>
    </section>

    <!-- ===== \u89C6\u56FE\uFF1A\u8282\u70B9\u914D\u7F6E\uFF08\u534F\u8BAE / TLS / ECH / \u843D\u5730\u51FA\u7AD9\uFF09 ===== -->
    <section class="view" data-view="nodes">
      <div class="view-head"><h2>\u8282\u70B9\u914D\u7F6E</h2><p>\u534F\u8BAE\u3001TLS/ECH\u3001\u8D1F\u8F7D\u5747\u8861\u4E0E\u843D\u5730\u51FA\u7AD9\uFF08\u4FDD\u5B58\u540E\u7ACB\u5373\u751F\u6548\uFF09</p></div>
      <div class="grid3">
        <div class="card">
          <h3><span class="tick"></span>\u534F\u8BAE\u5F00\u5173</h3>
          <div class="proto-row"><label class="switch"><input type="checkbox" id="en-vless" checked><span class="sl"></span></label><span>VLESS \u534F\u8BAE\uFF08\u9ED8\u8BA4\u5F00\u542F\uFF09</span></div>
          <div class="proto-row"><label class="switch"><input type="checkbox" id="en-trojan"><span class="sl"></span></label><span>Trojan \u534F\u8BAE\uFF08\u652F\u6301Mihomo\u5185\u6838\uFF09</span></div>
          <div class="proto-row"><label class="switch"><input type="checkbox" id="en-xhttp"><span class="sl"></span></label><span>XHTTP \u534F\u8BAE\uFF08\u652F\u6301Mihomo\u5185\u6838\uFF0C\u987B\u7ED1\u5B9A\u57DF\u540D\u5F00\u542FgRPC\uFF09</span></div>
          <div class="field" style="margin-top:12px"><label>Trojan \u5BC6\u7801\uFF08\u7559\u7A7A\u4F7F\u7528 UUID\uFF09</label><input type="text" id="tp-pass" placeholder="Trojan \u5BC6\u7801" autocomplete="off"></div>
        </div>
        <div class="card">
          <h3><span class="tick"></span>TLS \u4E0E\u4F20\u8F93</h3>
          <div class="proto-row"><label class="switch"><input type="checkbox" id="tls-only"><span class="sl"></span></label><span>\u4EC5 TLS \u7AEF\u53E3\uFF08\u8DF3\u8FC7 80/8080 \u7B49\u660E\u6587\u7AEF\u53E3\uFF09</span></div>
          <div class="field" style="margin-top:12px"><label>ALPN \u534F\u5546\uFF08h2 / http/1.1\uFF0C\u9017\u53F7\u5206\u9694\uFF09</label><input type="text" id="alpn" placeholder="\u7559\u7A7A\u81EA\u52A8\uFF0C\u5982 h2,http/1.1" autocomplete="off"></div>
          <p class="hint">\u660E\u6587\u7AEF\u53E3\u8282\u70B9\uFF0880/8080/8880/2052/2082/2086/2095\uFF09\u5F00\u542F\u300C\u4EC5 TLS\u300D\u540E\u4ECE\u8BA2\u9605\u5254\u9664\u3002</p>
        </div>
      </div>
      <div class="grid2">
        <div class="card">
          <h3><span class="tick"></span>\u8D1F\u8F7D\u5747\u8861</h3>
          <div class="proto-row"><label class="switch"><input type="checkbox" id="q-lb-on"><span class="sl"></span></label><span>\u8D1F\u8F7D\u5747\u8861\uFF08\u6253\u4E71\u4E0B\u53D1\u987A\u5E8F\uFF09</span></div>
          <p class="hint" style="margin-top:12px">\u6BCF\u6B21\u8BA2\u9605\u5BF9\u8282\u70B9\u987A\u5E8F\u968F\u673A\u8F6E\u6362\uFF08Fisher-Yates\uFF09\uFF0C\u8FDE\u63A5\u5206\u6563\u907F\u514D\u96C6\u4E2D\u8E29\u540C\u4E00\u6279\u5934\u90E8 IP\uFF1B\u5173\u95ED\u5219\u56FA\u5B9A\u987A\u5E8F\u3002<br>
            <b>\u4FDD\u5E95\u524D\u7F6E</b>\uFF1A\u300C\u4F18\u9009IP-Sxx\u300D\uFF08\u5B9E\u6D4B\u9AD8\u5B58\u6D3B IP\uFF09/\u300C\u5185\u7F6E\xB7\u4FDD\u5E95-XX\u300D/\u300C\u96A7\u9053\u524D\u7F6E-XX\u300D\u59CB\u7EC8\u4FDD\u7559\u5728\u6E05\u5355\u5934\u90E8\uFF08\u7EC4\u5185\u4ECD\u968F\u673A\u8F6E\u6362\uFF09\uFF0C
            \u5176\u4F59\u8282\u70B9\u6574\u4F53\u4E71\u5E8F\u2014\u2014\u65E2\u4FDD\u8BC1\u5BA2\u6237\u7AEF\u300C\u53D6\u7B2C\u4E00\u4E2A\u300D\u5C31\u662F\u7A33\u5B9A\u8282\u70B9\uFF0C\u53C8\u4E0D\u727A\u7272\u5206\u6563\u8FDE\u63A5\u7684\u6536\u76CA\uFF1B\u540C\u65F6\u907F\u514D\u8FD9\u6279\u6700\u7A33\u7684\u8282\u70B9\u5728\u8282\u70B9\u6570\u5C01\u9876\u65F6\u88AB\u5C3E\u90E8\u622A\u65AD\u780D\u6389\u3002</p>
        </div>
        <div class="card">
          <h3><span class="tick"></span>\u56FD\u5BB6\u6807\u6CE8</h3>
          <div class="field" style="margin-top:10px"><label>\u65E0\u540D\u8282\u70B9\u9ED8\u8BA4\u56FD\u5BB6</label><select id="q-clabel">
            <option value="">\u6309\u8BA2\u9605\u65F6\u673A\u623F\u5B9E\u6D4B\uFF08\u9ED8\u8BA4\uFF09</option>
            <option value="OFF">\u4E0D\u6807\u6CE8</option>
            <option value="HK">\u56FA\u5B9A\uFF1A\u9999\u6E2F</option>
            <option value="TW">\u56FA\u5B9A\uFF1A\u53F0\u6E7E</option>
            <option value="MO">\u56FA\u5B9A\uFF1A\u6FB3\u95E8</option>
            <option value="JP">\u56FA\u5B9A\uFF1A\u65E5\u672C</option>
            <option value="SG">\u56FA\u5B9A\uFF1A\u65B0\u52A0\u5761</option>
            <option value="KR">\u56FA\u5B9A\uFF1A\u97E9\u56FD</option>
            <option value="US">\u56FA\u5B9A\uFF1A\u7F8E\u56FD</option>
            <option value="DE">\u56FA\u5B9A\uFF1A\u5FB7\u56FD</option>
            <option value="GB">\u56FA\u5B9A\uFF1A\u82F1\u56FD</option>
            <option value="FR">\u56FA\u5B9A\uFF1A\u6CD5\u56FD</option>
            <option value="CA">\u56FA\u5B9A\uFF1A\u52A0\u62FF\u5927</option>
            <option value="AU">\u56FA\u5B9A\uFF1A\u6FB3\u5927\u5229\u4E9A</option>
            <option value="SE">\u56FA\u5B9A\uFF1A\u745E\u5178</option>
            <option value="NL">\u56FA\u5B9A\uFF1A\u8377\u5170</option>
            <option value="FI">\u56FA\u5B9A\uFF1A\u82AC\u5170</option>
            <option value="IN">\u56FA\u5B9A\uFF1A\u5370\u5EA6</option>
            <option value="TR">\u56FA\u5B9A\uFF1A\u571F\u8033\u5176</option>
            <option value="BR">\u56FA\u5B9A\uFF1A\u5DF4\u897F</option>
          </select></div>
          <p class="hint" style="margin-top:12px">\u4EC5\u5F71\u54CD\u65E0\u6CD5\u4ECE\u540D\u5B57\u8BC6\u522B\u5730\u533A\u7684\u8282\u70B9\uFF08\u4F18\u9009IP/\u4FDD\u7559N/\u81EA\u5B9A\u540D\u7B49\uFF09\u3002\u300C\u673A\u623F\u5B9E\u6D4B\u300D= \u771F\u5B9E\u8DEF\u7531\u843D\u70B9\uFF0C\u968F\u8FD0\u8425\u5546\u7EBF\u8DEF\u53D8\u5316\uFF08\u540C\u4E00\u7F51\u7EDC\u4E0B\u5168\u90E8\u540C\u540D\u662F\u6B63\u5E38\u73B0\u8C61\uFF09\uFF1B\u300C\u56FA\u5B9A\u300D\u53EA\u6539\u8282\u70B9\u540D\uFF0C\u4E0D\u6539\u53D8\u5B9E\u9645\u843D\u5730\u3002\u8BA2\u9605\u94FE\u63A5\u53EF\u52A0 ?country=HK \u6216 ?country=off \u4E34\u65F6\u8986\u76D6\uFF08\u4F18\u5148\u4E8E\u672C\u8BBE\u7F6E\uFF09\u3002</p>
        </div>
      </div>
      <div class="card">
        <h3><span class="tick"></span>ECH \u52A0\u5BC6\uFF08\u53EF\u9009\uFF09</h3>
        <div class="proto-row"><label class="switch"><input type="checkbox" id="ech-on"><span class="sl"></span></label><span>\u542F\u7528 ECH \u52A0\u5BC6\uFF08\u9700\u7ED1\u5B9A\u81EA\u5B9A\u4E49\u57DF\u540D\uFF09</span></div>
        <div class="grid2" style="margin-top:12px">
          <div class="field" style="margin-bottom:0"><label>ECH \u57DF\u540D\uFF08\u7559\u7A7A\u7528\u9ED8\u8BA4 cloudflare-ech.com\uFF09</label><input type="text" id="ech-host" placeholder="cloudflare-ech.com" autocomplete="off"></div>
          <div class="field" style="margin-bottom:0"><label>\u81EA\u5B9A\u4E49 ECH DNS\uFF08DoH \u5730\u5740\uFF0C\u7559\u7A7A\u7528\u5BA2\u6237\u7AEF\u9ED8\u8BA4\uFF09</label><input type="text" id="ech-dns" placeholder="https://223.5.5.5/dns-query" autocomplete="off"></div>
        </div>
        <p class="hint">\u5F00\u542F\u540E\u8BA2\u9605\u8282\u70B9\u9644\u5E26 ech \u53C2\u6570\u4E0E alpn \u534F\u5546\uFF0C\u5BA2\u6237\u7AEF\u9700\u652F\u6301 ECH \u624D\u751F\u6548\u3002</p>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u843D\u5730\u4E0E\u51FA\u7AD9</h3>
        <div class="field"><label>\u53CD\u4EE3 / \u843D\u5730\uFF08\u53EF\u586B\u591A\u4E2A\uFF0C\u82F1\u6587\u9017\u53F7\u5206\u9694\uFF1B\u652F\u6301\u57DF\u540D\u4E0E IP\uFF0C\u53EF\u5E26\u4E24\u4F4D\u56FD\u5BB6\u4EE3\u7801\uFF1B\u7559\u7A7A\u5219\u76F4\u8FDE\u5931\u8D25\u540E\u8D70\u5185\u7F6E\u5730\u533A\u51FA\u53E3\uFF09</label><input type="text" id="s-proxyIP" placeholder="\u5982\uFF1AProxy-HK.a.com,HK.43.132.231.159:443,8.219.155.125:443#JP" autocomplete="off"></div>
        <p class="hint">\u591A\u6761\u65F6\u6309\u8282\u70B9\u843D\u5730\u56FD\u5BB6\u81EA\u52A8\u5339\u914D\u3002\u5E26\u56FD\u5BB6\u4EE3\u7801\u7684\u6761\u76EE\u53EA\u7528\u4E8E\u8BE5\u56FD\u8282\u70B9\uFF0C\u4E24\u79CD\u5199\u6CD5\u7B49\u4EF7\uFF1A\u57DF\u540D\u628A\u56FD\u5BB6\u4EE3\u7801\u653E\u5728\u540D\u5B57\u91CC\uFF08\u5982 Proxy-HK.\u2026 \u91CC\u7684 HK\uFF09\uFF0CIP \u5199\u6210\u524D\u7F00\u5F0F HK.1.2.3.4:443 \u6216\u540E\u7F00\u5F0F 1.2.3.4:443#HK\uFF08IPv6 \u7528\u65B9\u62EC\u53F7\uFF0C\u5982 HK.[2001:db8::1]:443\uFF09\u3002\u4E0D\u5E26\u56FD\u5BB6\u4EE3\u7801\u7684\u6761\u76EE\uFF08\u542B\u7EAF IP\uFF09\u4F5C\u4E3A\u901A\u7528\u5019\u9009\uFF0C\u6309\u586B\u5199\u987A\u5E8F\u4F9D\u6B21\u5C1D\u8BD5\u3002\u67D0\u56FD\u65E0\u5BF9\u5E94\u6761\u76EE\u65F6\u9000\u56DE\u5217\u8868\u9996\u6761\uFF1B\u53EA\u586B\u4E00\u6761\u65F6\u884C\u4E3A\u4E0E\u65E7\u7248\u4E00\u81F4\u3002</p>
        <div class="field"><label>\u51FA\u7AD9\uFF08\u53EF\u9009\uFF09</label><input type="text" id="s-outbound" placeholder="socks5://user:pass@1.2.3.4:1080 \u6216 ss://chacha20-ietf-poly1305:\u5BC6\u7801@1.2.3.4:8388" autocomplete="off"></div>
        <p class="hint">\u652F\u6301 socks5://\uFF08\u53EF\u5E26 user:pass@\uFF09\u3001http(s)://\u3001ss:// \u6216 host:port\uFF08\u9ED8\u8BA4\u6309 socks5\uFF0C\u7AEF\u53E3 1080\uFF09\u3002SS \u52A0\u5BC6\u652F\u6301 aes-128-gcm / aes-256-gcm / chacha20-ietf-poly1305\u3002</p>
        <div class="field" style="margin-bottom:0"><label>\u51FA\u7AD9\u65B9\u5F0F</label>
          <select id="s-outmode">
            <option value="">\u9ED8\u8BA4\uFF08\u4F18\u5148\u51FA\u53E3\uFF0C\u5931\u8D25\u76F4\u8FDE\uFF09</option>
            <option value="no">\u76F4\u8FDE\u4F18\u5148\uFF08no\uFF09</option>
            <option value="only">\u4EC5\u8D70\u51FA\u53E3\uFF08only\uFF09</option>
          </select>
        </div>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u4FDD\u5B58\u4E0E\u751F\u6548</h3>
        <div class="note-box" style="margin:0">\u914D\u7F6E\u4FEE\u6539\u540E\u70B9\u53F3\u4E0B\u89D2\u300C\u4FDD\u5B58\u5168\u90E8\u300D\u5199\u5165 KV \u5E76\u751F\u6548\uFF0C\u8BA2\u9605\u4E0E\u8282\u70B9\u6784\u6210\u7ACB\u5373\u66F4\u65B0\uFF1B\u300C\u91CD\u7F6E\u300D\u6E05\u7A7A\u540E\u7AEF KV \u914D\u7F6E\u5E76\u9000\u51FA\u767B\u5F55\uFF08\u542B\u6E05\u9664\u524D\u7AEF\u767B\u5F55\u5BC6\u7801\uFF09\uFF0C\u56DE\u5230\u300C\u8BBE\u7F6E\u7BA1\u7406\u5BC6\u7801\u300D\u9875\u3002</div>
      </div>
    </section>

    <!-- ===== \u89C6\u56FE\uFF1A\u4F18\u9009\u914D\u7F6E ===== -->
    <section class="view" data-view="optimizer">
      <div class="view-head"><h2>\u4F18\u9009\u914D\u7F6E</h2><p>\u62C9\u53D6\u5019\u9009 IP \u2192 \u672C\u5730\u6D4B\u901F \u2192 \u6700\u4F18\u8282\u70B9\u52A0\u5165\u8BA2\u9605</p></div>
      <div class="card">
        <h3><span class="tick"></span>\u5728\u7EBF\u4F18\u9009</h3>
        <div class="grid3">
          <div class="field" style="grid-column:span 2;margin:0"><label>\u6570\u636E\u6E90</label>
            <select id="o-source">
              <option value="wetest_v4">\u5FAE\u6D4B\u7F51 IPv4</option>
              <option value="wetest_v6">\u5FAE\u6D4B\u7F51 IPv6</option>
              <option value="bestcf">\u4F18\u9009 IP \u5217\u8868\uFF08bestcf\uFF09</option>
              <option value="hostmonit">HostMonit \u4F18\u9009</option>
              <option value="cidr">\u5185\u7F6E Cloudflare \u5730\u5740\u6BB5</option>
              <option value="custom">\u81EA\u5B9A\u4E49 URL</option>
            </select>
          </div>
          <div class="field" style="margin:0"><label>\u9ED8\u8BA4\u7AEF\u53E3 <span style="font-weight:400;color:var(--faint)">\uFF08\u6E90\u672A\u5E26\u7AEF\u53E3\u65F6\u7528\uFF09</span></label>
            <select id="o-port" onchange="onPortSel()">
              <optgroup label="HTTPS"><option value="443">443</option><option value="2053">2053</option><option value="2083">2083</option><option value="2087">2087</option><option value="2096">2096</option><option value="8443">8443</option></optgroup>
              <optgroup label="HTTP"><option value="80">80</option><option value="8080">8080</option><option value="8880">8880</option><option value="2052">2052</option><option value="2082">2082</option><option value="2086">2086</option><option value="2095">2095</option></optgroup>
              <option value="custom">\u81EA\u5B9A\u4E49\u2026</option>
            </select>
            <input type="text" id="o-portC" style="display:none;margin-top:8px" placeholder="\u81EA\u5B9A\u4E49\u7AEF\u53E3\u53F7" autocomplete="off">
          </div>
        </div>
        <div class="field" id="o-customWrap" style="display:none;margin-top:12px"><label>\u81EA\u5B9A\u4E49\u6570\u636E\u6E90 URL <span style="font-weight:400;color:var(--faint)">\uFF08\u591A\u4E2A\u7528\u6362\u884C\u6216\u5206\u53F7\u9694\u5F00\uFF0C\u4E0A\u9650 50 \u4E2A\uFF0C\u5E76\u53D1\u62C9\u53D6\uFF1BURL \u67E5\u8BE2\u4E32\u4E2D\u7684\u9017\u53F7\u539F\u6837\u4FDD\u7559\uFF09</span></label><input type="text" id="o-sourceURL" placeholder="https://example.com/ip.txt\uFF08\u591A\u4E2A\u7528\u6362\u884C/\u5206\u53F7\u9694\u5F00\uFF09" autocomplete="off"></div>
        <div class="field" style="margin-top:8px"><label>\u515C\u5E95\u4F18\u9009\u6C60 URL <span style="font-weight:400;color:var(--faint)">\uFF08\u53EF\u9009\uFF0C\u6362\u884C/\u5206\u53F7\u5206\u9694\uFF0C\u4E0A\u9650 10 \u4E2A\uFF1BURL \u67E5\u8BE2\u4E32\u4E2D\u7684\u9017\u53F7\u539F\u6837\u4FDD\u7559\uFF1B\u7559\u7A7A\u7528\u5185\u7F6E bestcf \u5730\u533A\u6C60\uFF09</span></label><input type="text" id="o-fbpool" placeholder="https://a.example/ips.txt;https://b.example/ips.txt" autocomplete="off"></div>
        <div class="grid3" style="margin-top:6px">
          <div class="field" style="margin:0"><label>\u5E76\u53D1\u7EBF\u7A0B\uFF081-50\uFF09</label><input type="number" id="o-threads" min="1" max="50" value="5"></div>
          <div class="field" style="margin:0"><label>\u5019\u9009\u6570\u91CF</label><input type="number" id="o-count" min="1" value="20"></div>
          <div class="field" style="margin:0"><label>\u968F\u673A\u8865\u8DB3\uFF080 \u5173\u95ED\uFF09</label><input type="number" id="o-fill" min="0" value="0"></div>
        </div>
        <div class="row" style="margin-top:14px">
          <label class="switch"><input type="checkbox" id="o-useCidr" checked><span class="sl"></span></label>
          <span style="font-size:13px;color:var(--dim)">\u5019\u9009\u4E0D\u8DB3\u65F6\u7528 Cloudflare \u5730\u5740\u6BB5\u968F\u673A\u8865\u8DB3\uFF08\u672A\u7ECF\u672C\u5730\u6D4B\u901F\uFF0C\u53EF\u80FD\u4E0D\u53EF\u7528\uFF1B\u5EFA\u8BAE\u4FDD\u6301 0\uFF09</span>
          <span style="flex:1"></span>
          <button class="btn primary" onclick="runPick()">\u5F00\u59CB\u4F18\u9009</button>
          <button class="btn" onclick="addAllBest()">\u5168\u90E8\u52A0\u5165\u6700\u4F18</button>
        </div>
        <div class="msg" id="oMsg"></div>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u6D4B\u901F\u7ED3\u679C <span class="sub">\u672C\u5730\uFF08\u6D4F\u89C8\u5668\uFF09\u2192 \u76EE\u6807 IP</span></h3>
        <div class="tbl-wrap">
          <table><colgroup><col style="width:42%"><col style="width:18%"><col style="width:16%"><col style="width:24%"></colgroup>
          <thead><tr><th>IP : \u7AEF\u53E3</th><th>\u5EF6\u8FDF</th><th>\u72B6\u6001</th><th>\u64CD\u4F5C</th></tr></thead>
          <tbody id="oTableBody"><tr><td colspan="4" style="text-align:center;color:var(--faint)">\u5C1A\u672A\u6D4B\u901F \u2014 \u70B9\u51FB\u300C\u5F00\u59CB\u4F18\u9009\u300D\u62C9\u53D6\u5019\u9009</td></tr></tbody></table>
        </div>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u5404\u540E\u7AEF\u4F18\u9009\u8282\u70B9</h3>
        <p class="hint" id="preferred-summary">\u6B63\u5728\u8BFB\u53D6\u5404\u540E\u7AEF\u914D\u7F6E\u2026</p>
        <p class="hint">\u76F4\u63A5\u4FEE\u6539\u5BF9\u5E94\u540E\u7AEF\u5E76\u70B9\u51FB\u5361\u7247\u5185\u7684\u4FDD\u5B58\u6309\u94AE\uFF1B\u5404\u540E\u7AEF\u72EC\u7ACB\u4FDD\u5B58\u3002</p><label for="preferred-target">\u6D4B\u901F\u7ED3\u679C\u52A0\u5165\u5230</label><select id="preferred-target" style="margin-bottom:14px"></select><div id="preferred-overview"></div>
        <button class="btn sm" type="button" onclick="loadPreferredOverview()">\u5237\u65B0\u5404\u540E\u7AEF\u5217\u8868</button>
      </div>
    </section>

    <!-- ===== \u89C6\u56FE\uFF1A\u914D\u989D\u5B89\u5168 ===== -->
    <section class="view" data-view="quota">
      <div class="view-head"><h2>\u914D\u989D\u5B89\u5168</h2><p>\u76D1\u63A7 Cloudflare \u8D26\u6237\u5F53\u65E5\u7528\u91CF\uFF0C\u6309\u514D\u8D39\u989D\u5EA6\u81EA\u52A8\u8C03\u8282\u4E0B\u53D1\u89C4\u6A21\uFF08\u9700\u5728\u9762\u677F\u8BBE\u7F6E\u4E2D\u914D\u7F6E Cloudflare \u8D26\u6237 ID \u53CA API \u4EE4\u724C\uFF09</p></div>
      <div class="card">
        <h3><span class="tick"></span>Cloudflare \u7528\u91CF\u76D1\u63A7 <span class="sub" id="qQuotaSub">\u672A\u914D\u7F6E</span></h3>
        <div id="qQuotaWrap">
          <div class="kv"><span class="k">\u5F53\u65E5\u8BF7\u6C42\u91CF</span><span class="v" id="qReq">\u2014</span></div>
          <div style="margin:10px 0 6px;height:10px;border-radius:6px;background:var(--card2);overflow:hidden">
            <div id="qBar" style="height:100%;width:0%;border-radius:6px;background:linear-gradient(90deg,var(--ok),var(--accent));transition:width .5s"></div>
          </div>
          <div class="kv"><span class="k">\u5DF2\u7528\u989D\u5EA6</span><span class="v" id="qPct">\u2014</span></div>
          <div class="kv"><span class="k">\u5269\u4F59\u989D\u5EA6</span><span class="v" id="qRemain">\u2014</span></div>
          <div class="kv"><span class="k">CPU \u65F6\u95F4</span><span class="v" id="qCpu">\u2014</span></div>
          <div class="kv"><span class="k">\u5B50\u8BF7\u6C42\u6570</span><span class="v" id="qSub">\u2014</span></div>
          <div class="kv"><span class="k">\u6570\u636E\u66F4\u65B0</span><span class="v" id="qAt">\u2014</span></div>
        </div>
        <div id="qQuotaEmpty" style="display:none">
          <div class="note-box" style="margin:0">\u5C1A\u672A\u914D\u7F6E Cloudflare \u76D1\u63A7\uFF1A\u5728\u300C\u9762\u677F\u8BBE\u7F6E\u300D\u586B\u5199 Cloudflare \u8D26\u6237 ID \u4E0E API \u4EE4\u724C\uFF08\u6216\u90E8\u7F72\u65F6\u914D\u7F6E\u73AF\u5883\u53D8\u91CF CF_ACCOUNT_ID / CF_API_TOKEN\uFF09\uFF0C\u5373\u53EF\u5B9E\u65F6\u67E5\u770B\u5F53\u65E5\u8BF7\u6C42\u91CF\u5E76\u542F\u7528\u81EA\u52A8\u8C03\u8282\u3002</div>
        </div>
        <div id="qQuotaErr" style="display:none">
          <div class="note-box" style="margin:0;border-left-color:var(--err)" id="qQuotaErrText">\u7528\u91CF\u67E5\u8BE2\u5931\u8D25</div>
        </div>
        <div class="row" style="margin-top:14px">
          <label class="switch"><input type="checkbox" id="q-auto-on"><span class="sl"></span></label>
          <span style="font-size:13px">\u81EA\u52A8\u8C03\u8282\uFF1A\u5F53\u65E5\u7528\u91CF \u2265 60% \u65F6\u6309\u6BD4\u4F8B\u6536\u7F29\u8282\u70B9\u4E0A\u9650\uFF08\u4FDD\u62A4\u8D26\u6237\u514D\u8D39\u989D\u5EA6\uFF09</span>
          <span style="flex:1"></span>
          <button class="btn sm" onclick="refreshQuota()">\u5237\u65B0\u7528\u91CF</button>
        </div>
        <p class="hint">\u81EA\u52A8\u8C03\u8282\uFF1A\u7528\u91CF\u8FBE\u514D\u8D39\u989D\u5EA6 60% \u540E\u8282\u70B9\u4E0A\u9650\u6309\u6BD4\u4F8B\u6536\u7F29\uFF0860%\u21921000 \u6761\u300170%\u2192750\u300180%\u2192500\u300190%\u2192250\u3001100%\u2192100 \u6761\u4FDD\u5E95\uFF09\uFF0C\u7528\u91CF\u8D8A\u9AD8\u4E0B\u53D1\u8D8A\u5C11\u3002</p>
        <div class="row" style="margin-top:10px">
          <label class="switch"><input type="checkbox" id="q-strict-on"><span class="sl"></span></label>
          <span style="font-size:13px">\u4E25\u683C\u6A21\u5F0F\uFF1A\u5F53\u65E5\u7528\u91CF\u9AD8\u4E8E 95% \u65F6\u505C\u6B62\u4E0B\u53D1\u4EFB\u4F55\u8282\u70B9\uFF08\u4FDD\u62A4\u8D26\u6237\u514D\u8D39\u989D\u5EA6\uFF09</span>
        </div>
        <p class="hint">\u4E25\u683C\u6A21\u5F0F\uFF1A\u5F00\u542F\u540E\uFF0C\u5F53\u65E5\u7528\u91CF\u8D85\u8FC7 95% \u65F6\u8BA2\u9605\u5C06\u4E0D\u518D\u4E0B\u53D1\u4EFB\u4F55\u8282\u70B9\uFF08\u6B21\u65E5\u81EA\u52A8\u6062\u590D\uFF09\uFF1B\u5173\u95ED\u5219\u6CBF\u7528\u4E0A\u65B9\u81EA\u52A8\u8C03\u8282\u7684\u6BD4\u4F8B\u6536\u7F29\u7B56\u7565\u3002\u9700\u5148\u5728\u300C\u9762\u677F\u8BBE\u7F6E\u300D\u914D\u7F6E Cloudflare \u8D26\u6237 ID \u4E0E API \u4EE4\u724C\u3002</p>
      </div>
      <div class="grid2">
        <div class="card">
          <h3><span class="tick"></span>\u4E0B\u53D1\u63A7\u5236</h3>
          <div class="proto-row"><label class="switch"><input type="checkbox" id="q-nl-on"><span class="sl"></span></label><span>\u7CBE\u786E\u8282\u70B9\u6570\u91CF\u63A7\u5236</span></div>
          <div class="field" style="margin-top:10px"><label>\u7CBE\u786E\u8282\u70B9\u4E0A\u9650\uFF081-1000\uFF09</label><input type="number" id="q-nl-count" min="1" max="1000" value="300"></div>
          <p class="hint">\u9ED8\u8BA4\u5F00\u542F\uFF1A\u6240\u6709\u683C\u5F0F\u8BA2\u9605\u7CBE\u786E\u4E0B\u53D1\u5230\u8BBE\u5B9A\u6570\u91CF\uFF08\u9ED8\u8BA4 300\uFF0C\u8303\u56F4 1-1000\uFF09\uFF0C\u66FF\u4EE3\u539F 300/800 \u5206\u6863\uFF1B\u52FE\u9009\u4E09\u79CD\u534F\u8BAE\u65F6\u603B\u6570\u4ECD\u4E3A\u8BBE\u5B9A\u503C\u3002</p>
        </div>
        <div class="card">
          <h3><span class="tick"></span>CPU \u8D85\u989D\u9650\u5236</h3>
          <div class="proto-row"><label class="switch"><input type="checkbox" id="q-cpu-on"><span class="sl"></span></label><span>\u542F\u7528 CPU \u8D85\u989D\u9650\u5236\uFF08\u9ED8\u8BA4\u5173\u95ED\uFF09</span></div>
          <p class="hint" style="margin-top:12px">\u9ED8\u8BA4\u5173\u95ED\uFF1A\u6309\u8BBE\u5B9A\u6570\u91CF\u5B8C\u6574\u4E0B\u53D1\u3002\u5F00\u542F\u540E\u5BF9\u8BA2\u9605\u751F\u6210\u964D\u8F7D \u2014\u2014 \u8282\u70B9\u6309\u4E0A\u9650\u7684 60% \u4E0B\u53D1\uFF08\u524A\u51CF 40%\uFF09\uFF0C\u5355\u6B21\u8BA2\u9605\u8BF7\u6C42\u7684 CPU \u6D88\u8017\u5B9E\u6D4B\u4E0B\u964D\u7EA6 25%\uFF0C\u7528\u4E8E\u89C4\u907F\u514D\u8D39\u8BA1\u5212 10ms/\u8BF7\u6C42 \u7684\u8D85\u989D\u98CE\u9669\uFF1B\u4EE3\u4EF7\u662F\u4E0B\u53D1\u7684\u8282\u70B9\u6570\u91CF\u76F8\u5E94\u51CF\u5C11\u3002</p>
        </div>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u5F53\u524D\u4E0B\u53D1\u7B56\u7565</h3>
        <div class="grid3">
          <div class="field" style="margin:0"><div class="kv"><span class="k">\u8282\u70B9\u6570\u91CF\u63A7\u5236</span><span class="v" id="qNl">\u2014</span></div><div class="kv"><span class="k">\u7CBE\u786E\u8282\u70B9\u4E0A\u9650</span><span class="v" id="qNlCount">\u2014</span></div></div>
          <div class="field" style="margin:0"><div class="kv"><span class="k">CPU \u8D85\u989D\u9650\u5236</span><span class="v" id="qCpuLimit">\u2014</span></div><div class="kv"><span class="k">\u8D1F\u8F7D\u5747\u8861</span><span class="v" id="qLb">\u2014</span></div></div>
          <div class="field" style="margin:0"><div class="kv"><span class="k">IPv6 \u4E0B\u53D1</span><span class="v" id="qIp6">\u2014</span></div></div>
        </div>
        <p class="hint" style="margin-top:10px">\u6BCF\u6B21\u8BA2\u9605\u8BF7\u6C42\u6D88\u8017 Worker CPU\uFF08\u514D\u8D39\u8BA1\u5212 10ms/\u8BF7\u6C42\uFF09\u3002\u9762\u677F\u6309\u300C\u514D\u8D39\u989D\u5EA6 \u2192 \u8282\u70B9\u6570\u300D\u9010\u5C42\u8BBE\u9632\u3002</p>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u4FDD\u62A4\u673A\u5236\u8BF4\u660E</h3>
        <div class="note-box">\u4E09\u9053\u9632\u7EBF\uFF08\u4F18\u5148\u7EA7\u4ECE\u9AD8\u5230\u4F4E\uFF09\uFF1A\u2460 \u7528\u91CF\u76D1\u63A7\uFF1B\u2461 \u81EA\u52A8\u8C03\u8282\uFF08\u7528\u91CF \u226560% \u65F6\u6309\u6BD4\u4F8B\u6536\u7F29\u8282\u70B9\u4E0A\u9650\uFF0C\u53EA\u6536\u7D27\u4E0D\u653E\u5927\uFF09\uFF1B\u2462 \u6570\u91CF\u4E0A\u9650\u7CBE\u786E\u9650\u5236\u3002\u53EF\u9009\u300CCPU \u8D85\u989D\u9650\u5236\u300D\u5728\u4EE5\u4E0A\u57FA\u7840\u4E0A\u518D\u964D\u8F7D\u3002\u5404\u5C42\u4E0A\u9650\u51B2\u7A81\u53D6\u8F83\u5C0F\u503C\uFF0CCPU \u6D88\u8017\u59CB\u7EC8\u5728\u514D\u8D39\u989D\u5EA6\u5185\u3002</div>
      </div>
    </section>

    <!-- ===== \u89C6\u56FE\uFF1A\u9762\u677F\u8BBE\u7F6E ===== -->
    <!-- ===== \u89C6\u56FE\uFF1AWARP \u6A21\u5F0F ===== -->
    <section class="view" data-view="warp">
      <div class="view-head"><h2>WARP \u914D\u7F6E</h2><p>\u4E0B\u53D1 WARP\uFF08WireGuard\uFF09\u8282\u70B9\u7531\u5BA2\u6237\u7AEF\u76F4\u8FDE\uFF1A\u672C\u670D\u52A1\u53EA\u505A\u914D\u7F6E\u89E3\u6790\u4E0E\u683C\u5F0F\u8F6C\u6362\uFF0C\u4E0D\u627F\u8F7D\u6D41\u91CF\u3002WireGuard \u8D70 UDP 2408\uFF0C\u90E8\u5206\u8FD0\u8425\u5546\u5C4F\u853D UDP \u65F6\u8868\u73B0\u4E3A\u5168\u90E8\u8D85\u65F6</p></div>
      <div class="card" style="border-color:var(--accent)">
        <h3><span class="tick"></span>\u63A5\u5165\u8FDB\u5EA6</h3>
        <div class="hint">\u9762\u677F\u4E0E\u914D\u7F6E\u5B58\u50A8\u5DF2\u5C31\u7EEA\uFF1B\u5207\u5230\u672C\u6A21\u5F0F\u540E\u8BA2\u9605\u5373\u4E0B\u53D1 WARP \u8282\u70B9\uFF08\u5BA2\u6237\u7AEF\u76F4\u8FDE\uFF09\u3002\u6CE8\u518C\u5728\u9996\u6B21\u62C9\u53D6\u8BA2\u9605\u65F6\u81EA\u52A8\u5B8C\u6210\uFF0C\u4E4B\u540E\u4E00\u76F4\u590D\u7528\u3002</div>
      </div>
      <div class="grid3">
        <div class="card">
          <h3><span class="tick"></span>\u51ED\u636E\uFF08\u81EA\u52A8\u751F\u6210\uFF09</h3>
          <div class="field"><label class="spill"><input type="checkbox" id="w-on"> \u542F\u7528 WARP \u8282\u70B9\u4E0B\u53D1</label></div>
          <div class="field"><label>\u6CE8\u518C\u72B6\u6001</label><div class="hint" id="w-stat" style="margin:0">\u2014</div></div>
          <div class="field"><label>\u8282\u70B9\u540D\u79F0</label><input type="text" id="w-name" placeholder="WARP"></div>
          <div class="field"><label>\u5BF9\u7AEF\u5019\u9009\uFF08\u53EF\u9009\uFF0C\u4E00\u884C\u4E00\u4E2A\u300CIP:\u7AEF\u53E3\u300D\uFF0C\u6700\u591A 50 \u4E2A\uFF09</label>
            <textarea id="w-eps" rows="4" placeholder="\u7559\u7A7A\u5219\u4F7F\u7528\u5185\u7F6E 50 \u4E2A\u5B98\u65B9 anycast \u63A5\u5165\u70B9"></textarea>
          </div>
          <div class="inrow"><button class="btn sm" onclick="regenWarp()">\u91CD\u65B0\u751F\u6210\u51ED\u636E</button></div>
          <div class="hint">\u90E8\u7F72\u540E\u65E0\u9700\u4EFB\u4F55\u586B\u5199\uFF1A\u9996\u6B21\u62C9\u53D6\u8BA2\u9605\u65F6\u672C\u670D\u52A1\u4F1A\u81EA\u52A8\u5B8C\u6210\u6CE8\u518C\u5E76\u5199\u5165\u4F60\u7684\u5B58\u50A8\uFF0C\u4E4B\u540E\u4E00\u76F4\u590D\u7528\u3002\u51ED\u636E\u53EA\u4FDD\u5B58\u5728\u4F60\u81EA\u5DF1\u7684\u5B58\u50A8\u4E2D\uFF0C\u4E0D\u5916\u53D1\u3002\u82E5\u6362\u5BA2\u6237\u7AEF\u540E\u8FDE\u4E0D\u4E0A\uFF0C\u53EF\u70B9\u4E0A\u65B9\u6309\u94AE\u91CD\u7B7E\u4E00\u6B21\u3002</div>
        </div>
      </div>
    </section>

    <!-- ===== \u89C6\u56FE\uFF1A\u5BB6\u5BBD\u6A21\u5F0F ===== -->
    <section class="view" data-view="home">
      <div class="view-head"><h2>\u5BB6\u5BBD\u6A21\u5F0F</h2><p>VPN Gate OpenVPN \u5BB6\u5BBD\u51FA\u53E3\uFF0C\u7ECF\u96A7\u9053\u524D\u7F6E\u62E8\u53F7\uFF08\u4EC5 Mihomo \u5185\u6838\uFF09</p></div>
      <div class="card" style="border-color:var(--accent)">
        <h3><span class="tick"></span>\u5BB6\u5BBD\u51FA\u53E3</h3>
        <div class="proto-row"><label class="switch"><input type="checkbox" id="hw-on"><span class="sl"></span></label><span>VPN Gate OpenVPN \uFF08\u4EC5Mihomo\u5185\u6838\uFF09</span></div>
        <p class="hint">- \u8BE5\u5F00\u5173\u7531\u8FD0\u884C\u6A21\u5F0F\u81EA\u52A8\u63A7\u5236\uFF1A\u9009\u300C\u5BB6\u5BBD\u6A21\u5F0F\u300D\u81EA\u52A8\u6253\u5F00\uFF0C\u5207\u5230\u5176\u5B83\u6A21\u5F0F\u81EA\u52A8\u5173\u95ED\u3002<br>- \u6BCF\u65E5\u62C9\u53D6\uFF0C\u53D6\u6700\u5FEB 100 \u53F0\uFF0C\u4EC5\u7559 TCP \u5BB6\u5BBD\u8282\u70B9\uFF08\u300C\u5BB6\u5BBD + \u5730\u533A\u300D\u3001\u540C\u533A\u7F16\u53F7\uFF1BUDP \u5254\u9664\uFF09\u3002<br>- \u7F13\u5B58 30 \u5206\u949F\uFF1B&lt;30 \u53F0\u5F3A\u5236\u5237\u65B0\uFF0C\u5931\u8D25\u7528\u65E7\u7F13\u5B58\u3002<br>- \u5BB6\u5BBD\u987B\u7ECF\u96A7\u9053\u524D\u7F6E\u62E8\u53F7\uFF1B\u96A7\u9053\u8282\u70B9 Worker \u81EA\u52A8\u751F\u6210\u3001\u81EA\u52A8\u6D4B\u6D3B\u3001\u4E0D\u53D7\u7B5B\u9009\u3002<br>- \u5F00\u542F\u540E\u8BA2\u9605\u4EC5\u542B\u5BB6\u5BBD + \u96A7\u9053\u8282\u70B9\uFF1B\u9ED8\u8BA4\u8282\u70B9\u4E0D\u4E0B\u53D1\uFF08\u81EA\u5B9A\u4E49\u8BA2\u9605\u9664\u5916\uFF09\u3002</p>
      </div>
      <div class="card">
        <h3><span class="tick"></span>VPN Gate \u624B\u5199\u53C2\u6570</h3>
        <div class="field"><label>\u6BCF\u884C\u4E00\u6761\uFF1A\u4E3B\u673A \u7AEF\u53E3 \u534F\u8BAE \u5730\u533A\uFF08\u7A7A\u683C\u6216\u5192\u53F7\u5206\u9694\uFF0C\u7559\u7A7A\u5219\u81EA\u52A8\u62C9\u53D6\uFF09</label>
          <textarea id="hw-cfg" rows="7" placeholder="116.12.3.63 1357 tcp JP&#10;219.100.37.10 1194 udp KR&#10;1.2.3.4:443:tcp:US"></textarea></div>
        <p class="hint" style="margin-top:8px">- \u624B\u5199\u53C2\u6570<b>\u4F18\u5148\u7EA7\u9AD8\u4E8E\u81EA\u52A8\u62C9\u53D6</b>\uFF1A\u586B\u4E86\u5C31\u4E0D\u518D\u8BBF\u95EE VPN Gate \u5217\u8868\uFF0C\u8BA2\u9605\u91CC\u51FA\u73B0\u7684\u5C31\u662F\u4F60\u624B\u5199\u7684\u8FD9\u51E0\u53F0\u3002<br>- \u4E24\u79CD\u5199\u6CD5\uFF1A\u2460 \u76F4\u63A5\u7C98\u8D34 VPN Gate \u7684 base64 \u914D\u7F6E\uFF08\u53EF\u52A0\u5730\u533A\u7801\u524D\u7F00\uFF0C\u5982 JP: \u5F00\u5934\uFF09\uFF1B\u2461 \u4E3B\u673A \u7AEF\u53E3 \u534F\u8BAE \u5730\u533A\uFF0C\u540C\u65F6\u5728\u672C\u6846\u5185\u7528 ca: / cert: / key: \u7ED9\u51FA\u8BC1\u4E66\u3002<br>- \u5185\u6838\u8981\u6C42 openvpn \u5FC5\u987B\u5E26\u5185\u8054\u8BC1\u4E66\uFF0C<b>\u7F3A\u5C11\u8BC1\u4E66\u7684\u884C\u4F1A\u88AB\u5FFD\u7565</b>\uFF08\u53EF\u5148\u70B9\u300C\u8BD5\u7528\u5E76\u9884\u89C8\u300D\u770B\u89E3\u6790\u7ED3\u679C\uFF09\u3002<br>- \u7AEF\u53E3\u7701\u7565\u9ED8\u8BA4 1194\uFF1B\u534F\u8BAE\u7701\u7565\u9ED8\u8BA4 tcp\uFF08\u53EA\u8BA4 tcp / udp\uFF09\uFF1B\u5730\u533A\u7701\u7565\u9ED8\u8BA4 XX\uFF0C\u8282\u70B9\u540D\u5F62\u5982\u300C\u5BB6\u5BBDJP\u300D\u3002<br>- \u8BA4\u8BC1\u6CBF\u7528 VPN Gate \u516C\u5171\u8D26\u53F7 vpn / vpn\uFF1B\u4EC5 Mihomo \u5185\u6838\u652F\u6301 openvpn \u51FA\u7AD9\u3002</p>
        <div class="inrow" style="margin-top:10px">
          <button class="btn sm" onclick="hwCustomApply()">\u8BD5\u7528\u5E76\u9884\u89C8</button>
          <span class="hint" id="hw-cfg-stat" style="margin:0"></span>
        </div>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u4F7F\u7528\u8BF4\u660E</h3>
        <p class="hint" style="margin:0">\u672C\u6A21\u5F0F\u662F Worker \u6A21\u5F0F\u91CC\u7684\u300C\u5BB6\u5BBD\u6A21\u5F0F\u300D\u72EC\u7ACB\u800C\u6765\uFF0C\u903B\u8F91\u4E0E\u539F\u5148\u5B8C\u5168\u4E00\u81F4\uFF1A\u5F00\u542F\u540E\u8BA2\u9605\u4EC5\u4E0B\u53D1\u5BB6\u5BBD\u51FA\u53E3\u4E0E\u96A7\u9053\u524D\u7F6E\u8282\u70B9\u3002\u5207\u6362\u5230\u5176\u5B83\u6A21\u5F0F\u5373\u6062\u590D\u5BF9\u5E94\u5F62\u6001\uFF0C\u4E92\u4E0D\u5F71\u54CD\u3002</p>
      </div>
    </section>

    <!-- ===== \u89C6\u56FE\uFF1AMASQUE \u6A21\u5F0F ===== -->
    <section class="view" data-view="masque">
      <div class="view-head"><h2>MASQUE \u914D\u7F6E</h2><p>\u4E0B\u53D1 MASQUE \u8282\u70B9\u7531\u5BA2\u6237\u7AEF\u76F4\u8FDE\uFF1A\u9700 Mihomo \u5185\u6838\u652F\u6301\uFF08Clash Verge Rev \u5EFA\u8BAE\u5728\u300C\u8BBE\u7F6E \u2192 \u5185\u6838\u300D\u5207\u5230 Alpha\uFF1BClashMi / FlClash / Shadowrocket \u4EA6\u53EF\uFF09\u3002\u4E0D\u652F\u6301\u7684\u5185\u6838\u4F1A\u6574\u4EFD\u914D\u7F6E\u62D2\u8F7D</p></div>
      <div class="card" style="border-color:var(--accent)">
        <h3><span class="tick"></span>\u63A5\u5165\u8FDB\u5EA6</h3>
        <div class="hint">MASQUE \u8D70<b>\u8BC1\u4E66\u8BA4\u8BC1</b>\uFF1A\u672C\u670D\u52A1\u4F1A\u5728\u9996\u6B21\u62C9\u53D6\u8BA2\u9605\u65F6<b>\u81EA\u52A8\u5B8C\u6210\u6CE8\u518C</b>\u5E76\u628A\u51ED\u636E\u5199\u5165\u4F60\u7684\u5B58\u50A8\uFF0C\u4E4B\u540E\u4E00\u76F4\u590D\u7528\u3002\u4F60\u4E5F\u53EF\u4EE5\u5728\u4E0B\u9762\u624B\u5DE5\u586B\u5165\u81EA\u5DF1\u751F\u6210\u7684\u51ED\u636E\uFF08\u4F18\u5148\u7EA7\u66F4\u9AD8\uFF09\uFF1B\u4E24\u8005\u90FD\u6CA1\u6709\u65F6\u624D\u56DE\u843D\u5230 WARP \u8282\u70B9\uFF0C\u4FDD\u8BC1\u8BA2\u9605\u4E0D\u4F1A\u7A7A\u3002</div>
      </div>
      <div class="grid3">
        <div class="card">
          <h3><span class="tick"></span>\u51ED\u636E\uFF08\u81EA\u52A8\u6CE8\u518C\uFF0C\u53EF\u8986\u76D6\uFF09</h3>
          <div class="field"><label class="spill"><input type="checkbox" id="x-on"> \u542F\u7528 MASQUE \u8282\u70B9\u4E0B\u53D1</label></div>
          <div class="field"><label>\u7C98\u8D34\u672C\u5730\u751F\u6210\u7684\u51ED\u636E\uFF08EC \u79C1\u94A5 / \u516C\u94A5\uFF09</label>
            <textarea id="x-conf" rows="6" placeholder="\u7559\u7A7A\u5219\u7531\u672C\u670D\u52A1\u81EA\u52A8\u6CE8\u518C\uFF1B\u6CE8\u518C\u5931\u8D25\u65F6\u56DE\u843D\u5230 WARP \u8282\u70B9"></textarea>
          </div>
          <div class="field"><label>\u8282\u70B9\u540D\u79F0</label><input type="text" id="x-name" placeholder="MASQUE"></div>
          <div class="hint">\u4E0D\u586B\u4E5F\u80FD\u7528\uFF1A\u7559\u7A7A\u65F6\u672C\u670D\u52A1\u81EA\u52A8\u6CE8\u518C\u3002\u51ED\u636E\u53EA\u4FDD\u5B58\u5728\u4F60\u81EA\u5DF1\u7684\u5B58\u50A8\u4E2D\uFF0C\u4E0D\u5916\u53D1\u3002</div>
        </div>
        <div class="card">
          <h3><span class="tick"></span>\u5BF9\u7AEF\u5019\u9009</h3>
          <div class="field"><label>\u4E00\u884C\u4E00\u4E2A\u300CIP:\u7AEF\u53E3\u300D\uFF0C\u6309\u586B\u5199\u987A\u5E8F\u5C1D\u8BD5\uFF08\u6700\u591A 50 \u4E2A\uFF09</label>
            <textarea id="x-eps" rows="6" placeholder="\u7559\u7A7A\u5219\u4F7F\u7528\u5185\u7F6E\u5B98\u65B9\u7AEF\u70B9\u7EC4\u5408"></textarea>
          </div>
          <div class="hint">MASQUE \u7684 IP \u4E0E\u7AEF\u53E3\u548C WARP \u4E0D\u540C\uFF0C\u4E32\u7528\u4F1A\u8FDE\u4E0D\u4E0A\uFF1B\u7559\u7A7A\u5373\u7528\u5185\u7F6E\u7684\u5B98\u65B9\u7AEF\u70B9\u7EC4\u5408\u3002</div>
        </div>
        <div class="card">
          <h3><span class="tick"></span>\u5BA2\u6237\u7AEF\u517C\u5BB9</h3>
          <div class="hint">\u672C\u6A21\u5F0F\u4EA7\u51FA\u7684\u8282\u70B9<b>\u53EA\u88AB\u90E8\u5206\u5BA2\u6237\u7AEF\u652F\u6301</b>\u3002\u652F\u6301 MASQUE \u7684\u5BA2\u6237\u7AEF\u4E3A <b>Mihomo / Clash Meta \u5185\u6838\u7CFB</b>\uFF1A<b>Clash Verge Rev</b>\uFF08\u9700\u5728\u300C\u8BBE\u7F6E \u2192 \u5185\u6838\u300D\u91CC\u5207\u5230 <b>Alpha</b> \u5185\u6838\uFF09\u3001<b>ClashMi</b>\u3001<b>FlClash</b>\u3001<b>Mihomo Party</b>\u3001<b>Clash Meta for Android</b> \u7B49\uFF1BMASQUE \u8282\u70B9\u53EA\u968F <code>clash</code> \u683C\u5F0F\u4E0B\u53D1\uFF0Csing-box / v2rayN / Shadowrocket / Surge / Loon \u7B49\u683C\u5F0F\u4E0D\u5305\u542B\u5B83\u3002\u5176\u4F59\u5BA2\u6237\u7AEF\u5BFC\u5165\u540E\u4F1A\u770B\u4E0D\u5230\u8282\u70B9\uFF0C\u6216\u76F4\u63A5\u5FFD\u7565\u8BE5\u8282\u70B9\u3002</div>
          <div class="hint">\u82E5\u4F60\u7684\u5BA2\u6237\u7AEF\u4E0D\u5728\u652F\u6301\u8303\u56F4\u5185\uFF0C\u8BF7\u6539\u7528 Worker \u6A21\u5F0F\u6216 WARP \u6A21\u5F0F\u3002</div>
        </div>
      </div>
    </section>

    <section class="view" data-view="account">
      <div class="view-head"><h2>\u9762\u677F\u8BBE\u7F6E</h2><p>\u90E8\u7F72\u57FA\u7840\u4FE1\u606F\uFF08UUID\u3001\u8BA2\u9605\u8DEF\u5F84\u3001\u7BA1\u7406\u5BC6\u7801\uFF09\u4E0E\u8FD0\u884C\u6A21\u5F0F</p></div>
      <div class="card">
        <h3><span class="tick"></span>\u57FA\u7840\u914D\u7F6E</h3>
        <div class="field"><label>UUID\uFF08\u8BA2\u9605\u8282\u70B9\u8EAB\u4EFD\uFF09</label>
          <div class="inrow">
            <input type="text" id="a-uuid" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" autocomplete="off">
            <button class="btn sm" onclick="genUuid()">\u751F\u6210</button>
          </div>
        </div>
        <div class="field"><label>\u81EA\u5B9A\u4E49\u8BA2\u9605\u8DEF\u5F84\uFF08\u53EA\u586B UUID/\u522B\u540D\u6BB5\uFF0C\u5982 AAZ\uFF1B\u7559\u7A7A\u7528 UUID\uFF09</label><input type="text" id="a-suburl" placeholder="AAZ" autocomplete="off"></div>
        <div class="field"><label>\u7BA1\u7406\u5BC6\u7801\uFF08\u7559\u7A7A\u5219\u9762\u677F\u514D\u767B\u5F55\uFF09</label><input type="password" id="a-admin" placeholder="\u8BBE\u7F6E\u540E\u8BBF\u95EE\u9762\u677F\u9700\u767B\u5F55" autocomplete="new-password"></div>
        <p class="hint" style="margin-top:4px">\u90E8\u7F72\u540E\u9996\u6B21\u8BBF\u95EE\u5F3A\u5236\u8981\u6C42\u8BBE\u7F6E\u7BA1\u7406\u5BC6\u7801\uFF1B\u8BBE\u7F6E\u540E\u6B64\u5904\u7559\u7A7A\u5E76\u4FDD\u5B58\u53EF\u6062\u590D\u514D\u767B\u5F55\u3002</p>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u8FD0\u884C\u6A21\u5F0F</h3>
        <div class="field"><label>\u5F53\u524D\u6A21\u5F0F\uFF08\u56DB\u79CD\u6A21\u5F0F\u4E92\u4E0D\u5F71\u54CD\uFF0C\u53EF\u968F\u65F6\u5207\u6362\uFF09</label>
          <div class="inrow">
            <select id="a-mode">
              <option value="worker">Worker \u6A21\u5F0F \u2014 \u4F7F\u7528\u5185\u7F6E\u8282\u70B9\uFF0C\u7531\u672C\u670D\u52A1\u627F\u8F7D\u8F6C\u53D1</option>
              <option value="warp">WARP \u6A21\u5F0F \u2014 \u4E0B\u53D1 WARP \u8282\u70B9\uFF0C\u5BA2\u6237\u7AEF\u76F4\u8FDE</option>
              <option value="masque">MASQUE \u6A21\u5F0F \u2014 \u4E0B\u53D1 MASQUE \u8282\u70B9\uFF0C\u5BA2\u6237\u7AEF\u76F4\u8FDE</option>
              <option value="home">\u5BB6\u5BBD\u6A21\u5F0F \u2014 \u4E0B\u53D1 VPN Gate \u5BB6\u5BBD\u51FA\u53E3\uFF0C\u7ECF\u96A7\u9053\u524D\u7F6E\u62E8\u53F7</option>
            </select>
            <button class="btn sm" onclick="switchModeFromPanel()">\u5207\u6362</button>
          </div>
        </div>
        <div class="field"><label>WARP / MASQUE \u524D\u7F6E\u8282\u70B9\uFF08\u53EF\u9009\uFF09</label>
          <textarea id="a-front" rows="2" spellcheck="false" placeholder="\u7C98\u8D34\u4E00\u4E2A\u8282\u70B9\u94FE\u63A5\uFF0C\u4F8B\uFF1Avless://uuid@host:443?security=tls&type=ws&path=/&host=example.com#\u524D\u7F6E" style="width:100%;min-height:60px;background:var(--glass-field);color:var(--tx);border:1px solid var(--glass-field-brd);border-radius:10px;padding:10px;font:12.5px/1.7 ui-monospace,Consolas,monospace;resize:vertical"></textarea>
          <p class="hint" style="margin:6px 0 0">\u586B\u4E86\u4EE5\u540E\uFF0CWARP / MASQUE \u7684\u539F\u751F\u8282\u70B9\u4F1A\u7ECF\u8FD9\u4E2A\u8282\u70B9\u4E2D\u8F6C\uFF08mihomo \u7684 <code>dialer-proxy</code>\uFF09\uFF1A<b>\u4F60\u7684\u8BBE\u5907 \u2192 \u524D\u7F6E\u8282\u70B9 \u2192 WARP</b>\u3002\u652F\u6301 <code>vless</code> / <code>trojan</code> / <code>ss</code> / <code>socks5</code> / <code>http(s)</code> \u94FE\u63A5\u3002<b>\u524D\u7F6E\u5FC5\u987B\u80FD\u627F\u8F7D UDP</b>\uFF0C\u5426\u5219 WARP \u4F9D\u7136\u8FDE\u4E0D\u4E0A\uFF1B\u94FE\u63A5\u89E3\u6790\u5931\u8D25\u65F6\u4F1A\u81EA\u52A8\u5FFD\u7565\uFF08\u4E0D\u5F71\u54CD\u5176\u4ED6\u8282\u70B9\uFF09\u3002\u7559\u7A7A\u5219\u76F4\u8FDE WARP\u3002\u4EC5\u5BF9 <code>clash</code> \u683C\u5F0F\u751F\u6548\u3002</p>
        </div>
        <div class="hint" id="modeHint">\u5207\u6362\u540E\u5DE6\u4FA7\u5BFC\u822A\u4E0E\u5404\u6A21\u5F0F\u7684\u914D\u7F6E\u533A\u5757\u4F1A\u968F\u4E4B\u6539\u53D8\u3002</div>
      </div>
      <div class="card"><h3><span class="tick"></span>\u5916\u89C2\u98CE\u683C<button class="foldbtn" id="mdFoldBtn" onclick="toggleMdFold()" data-open="0" title="\u5C55\u5F00\u8272\u5F69\u8BBE\u7F6E"><svg viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg></button></h3><p class="hint" style="margin:0 0 12px">\u4E24\u79CD\u8BBE\u8BA1\u8BED\u8A00\u5E76\u5B58\uFF0C\u5207\u6362\u53EA\u5F71\u54CD\u672C\u673A\u663E\u793A\uFF0C\u4E0D\u6539\u52A8 Worker \u914D\u7F6E\u3002</p><div class="field"><label>\u8BBE\u8BA1\u8BED\u8A00</label><div class="inrow seg" id="styleSeg"><button class="btn" data-s="glass" onclick="setStyle('glass')">\u6DB2\u6001\u73BB\u7483</button><button class="btn" data-s="material" onclick="setStyle('material')">Material</button></div></div><div id="mdBox" class="fold"><div class="field"><label>\u79CD\u5B50\u8272\uFF08\u5355\u4E00\u6765\u6E90\u8272\uFF0C\u5176\u4F59 64 \u8272\u7531\u5B83\u6D3E\u751F\uFF09</label><div class="inrow"><div><input type="text" id="mdSeed" placeholder="#6750A4" autocomplete="off" spellcheck="false"></div><button class="btn sm" onclick="resetSeed()">\u9ED8\u8BA4</button></div><div class="md-seed" id="mdSeedRow"></div></div><div class="field"><label>\u4E3B\u9898\u65B9\u6848</label><div class="inrow seg" id="mdVarSeg"></div><p class="hint" id="mdVarDesc" style="margin:8px 0 0"></p></div><div class="md-pal" id="mdPal"></div><div class="md-out" id="mdPalOut"></div><p class="hint" style="margin:10px 0 0">\u5355\u51FB\u4EFB\u610F\u8272\u5757\uFF0C\u5373\u628A\u8BE5\u8272\u8BBE\u4E3A\u65B0\u7684\u79CD\u5B50\u8272\uFF1B\u767D\u5708\u6807\u51FA\u5F53\u524D\u79CD\u5B50\u8272\u5728\u8272\u677F\u4E2D\u7684\u843D\u70B9\u3002\u91C7\u6837 AOSP\u300CMaterial \u8BBE\u8BA1\u300D\u89C4\u8303\uFF1A\u6765\u6E90\u8272\u7ECF CAM16/HCT \u5C55\u5F00\u4E3A 5 \u4E2A\u8272\u8C03\u8C03\u8272\u76D8 \xD7 13 \u4E2A\u8272\u8C03\u5171 65 \u8272\uFF0C\u518D\u6309\u6587\u6863\u7684\u989C\u8272\u89D2\u8272\u8868\u6620\u5C04\u3002\u6807\u53F7 N \u5BF9\u5E94 HCT \u8272\u8C03 (1000\u2212N)/10\u3002</p></div></div>
      <div class="card">
        <h3><span class="tick"></span>Telegram \u7528\u91CF\u901A\u77E5</h3>
        <div class="grid2">
          <div class="field" style="margin:0"><label>Bot Token</label><input type="text" id="q-tgtoken" placeholder="123456789:AAxxxx..." autocomplete="off"></div>
          <div class="field" style="margin:0"><label>Chat ID</label><input type="text" id="q-tgchat" placeholder="123456789" autocomplete="off"></div>
        </div>
        <p class="hint">\u586B\u597D\u540E\u63A8\u9001\u89C4\u5219\uFF1A80%\u300185%\u300190% \u5404\u63D0\u9192\u4E00\u6B21\uFF1B90% \u540E\u6BCF\u6DA8 1% \u63D0\u9192\u4E00\u6B21\uFF0891-99\uFF09\uFF1B\u8FBE 99% \u81EA\u52A8\u505C\u7528\u8BA2\u9605\uFF08\u6B21\u65E5\u81EA\u52A8\u6062\u590D\uFF09\u3002\u9700\u5F53\u524D\u540E\u7AEF\u5DF2\u914D\u7F6E Cloudflare \u8D26\u6237\u76D1\u63A7\uFF1B\u505C\u7528\u4E0E\u6062\u590D\u4E0D\u4F9D\u8D56 TG\uFF0C\u901A\u77E5\u4F9D\u8D56 TG\u3002</p>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u5907\u4EFD\u4E0E\u6062\u590D</h3>
        <p class="hint" style="margin-top:0;margin-bottom:12px">\u4EE5 JSON \u5BFC\u51FA/\u5BFC\u5165\u5168\u90E8\u9762\u677F\u8BBE\u7F6E\uFF08\u534F\u8BAE\u3001\u4F18\u9009\u3001\u7B5B\u9009\u3001\u914D\u989D\u76D1\u63A7\uFF09\uFF0C\u53EF\u4FDD\u5B58\u6216\u8FC1\u79FB\uFF1B\u5BFC\u5165\u540E\u70B9\u300C\u4FDD\u5B58\u5168\u90E8\u300D\u751F\u6548\u3002</p>
        <div class="inrow">
          <button class="btn" onclick="exportConfig()">\u5BFC\u51FA\u914D\u7F6E</button>
          <button class="btn" onclick="$('importFile').click()">\u5BFC\u5165\u914D\u7F6E</button>
          <input type="file" id="importFile" accept=".json,application/json" style="display:none" onchange="importConfig(this)">
        </div>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u8FD0\u884C\u4FE1\u606F</h3>
        <div class="kv"><span class="k">\u9762\u677F\u7248\u672C</span><span class="v" id="aVer">\u2014</span></div>
        <div class="kv"><span class="k">KV \u6301\u4E45\u5316</span><span class="v" id="aKv">\u2014</span></div>        <div class="kv"><span class="k">\u6784\u5EFA\u65E5\u671F</span><span class="v">2026-09-21</span></div>
      </div>
      <div class="danger-zone">
        <h3 style="margin-bottom:8px;color:var(--err)">\u5371\u9669\u64CD\u4F5C</h3>
        <p style="font-size:13px;color:var(--dim);margin-bottom:12px">\u91CD\u7F6E\u5C06\u6E05\u7A7A\u540E\u7AEF KV \u914D\u7F6E\uFF08\u9762\u677F\u914D\u7F6E + \u5DF2\u4E0B\u53D1\u8282\u70B9\u8BB0\u5F55\uFF09\uFF0C\u5E76\u6E05\u9664\u524D\u7AEF\u767B\u5F55\u5BC6\u7801\u3001\u9000\u51FA\u767B\u5F55\uFF0C\u9762\u677F\u56DE\u5230\u300C\u8BBE\u7F6E\u7BA1\u7406\u5BC6\u7801\u300D\u9875\u3002\u4E0D\u53EF\u6062\u590D\u3002</p>
        <button class="btn danger" onclick="resetAll()">\u91CD\u7F6E\u5168\u90E8\u6570\u636E</button>
      </div>
    </section>

    <!-- ===== \u89C6\u56FE\uFF1A\u5173\u4E8E ===== -->
    <section class="view" data-view="about">
      <div class="view-head"><h2>\u5173\u4E8E\u9879\u76EE</h2><p>CFNext \u2014 Cloudflare \u8FB9\u7F18\u7BA1\u7406\u9762\u677F\uFF08\u72EC\u7ACB\u754C\u9762 + \u72EC\u7ACB\u5B9E\u73B0\uFF09</p></div>
      <div class="card">
        <h3><span class="tick"></span>\u76F8\u5173\u94FE\u63A5</h3>
        <p style="font-size:13px;color:var(--dim)">YouTube @\u6570\u5B57\u6D3E\uFF1A<a href="https://www.youtube.com/@PAI_CN" target="_blank" rel="noopener">youtube.com/@PAI_CN</a></p>
        <p style="font-size:13px;color:var(--dim);margin-top:6px">Telegram \u4EA4\u6D41\u7FA4\uFF1A<a href="https://t.me/SZ_PAI" target="_blank" rel="noopener">t.me/SZ_PAI</a></p>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u7279\u522B\u9E23\u8C22</h3>
        <p style="font-size:13px;color:var(--dim);margin-bottom:10px">\u611F\u8C22\u4EE5\u4E0B\u5F00\u6E90\u9879\u76EE\u7684\u542F\u53D1\u4E0E\u652F\u6301\uFF08\u754C\u9762\u4E0E\u4EE3\u7801\u5747\u4E3A\u72EC\u7ACB\u5B9E\u73B0\uFF09</p>
        <div class="tbl-wrap"><table>
          <colgroup><col style="width:34%"><col style="width:66%"></colgroup>
          <thead><tr><th>\u5F00\u6E90\u9879\u76EE</th><th>\u5730\u5740</th></tr></thead>
          <tbody>
            <tr><td>IonRh/Cloudflare-BestIP</td><td><a href="https://github.com/IonRh/Cloudflare-BestIP" target="_blank" rel="noopener">github.com/IonRh/Cloudflare-BestIP</a></td></tr>
            <tr><td>zvos/CF-Workers-Monitor</td><td><a href="https://github.com/zvos/CF-Workers-Monitor" target="_blank" rel="noopener">github.com/zvos/CF-Workers-Monitor</a></td></tr>
            <tr><td>MetaCubeX/meta-rules-dat</td><td><a href="https://github.com/MetaCubeX/meta-rules-dat" target="_blank" rel="noopener">github.com/MetaCubeX/meta-rules-dat</a></td></tr>
            <tr><td>666OS/rules</td><td><a href="https://github.com/666OS/rules" target="_blank" rel="noopener">github.com/666OS/rules</a></td></tr>
            <tr><td>DustinWin/ruleset_geodata</td><td><a href="https://github.com/DustinWin/ruleset_geodata" target="_blank" rel="noopener">github.com/DustinWin/ruleset_geodata</a></td></tr>
            <tr><td>blackmatrix7/ios_rule_script</td><td><a href="https://github.com/blackmatrix7/ios_rule_script" target="_blank" rel="noopener">github.com/blackmatrix7/ios_rule_script</a></td></tr>
            <tr><td>TG-Twilight/AWAvenue-Ads-Rule</td><td><a href="https://github.com/TG-Twilight/AWAvenue-Ads-Rule" target="_blank" rel="noopener">github.com/TG-Twilight/AWAvenue-Ads-Rule</a></td></tr>
            <tr><td>Koolson/Qure</td><td><a href="https://github.com/Koolson/Qure" target="_blank" rel="noopener">github.com/Koolson/Qure</a></td></tr>
          </tbody>
        </table></div>
      </div>
      <div class="card">
        <h3><span class="tick"></span>\u8C03\u7528\u63A5\u53E3</h3>
        <div class="tbl-wrap"><table>
          <colgroup><col style="width:40%"><col style="width:60%"></colgroup>
          <thead><tr><th>\u7528\u9014</th><th>\u63A5\u53E3</th></tr></thead>
          <tbody>
            <tr><td>HostMonit \u4F18\u9009</td><td class="mono">stock.hostmonit.com/CloudFlareYes</td></tr>
            <tr><td>\u4F18\u9009 IP \u5217\u8868</td><td class="mono">cf.090227.xyz/ip.164746.xyz</td></tr>
            <tr><td>bestcf \u5730\u533A\u4F18\u9009\u6C60</td><td class="mono">bestcf.pages.dev/random-region/{HK|TW|JP|SG|US|KR}/100.txt</td></tr>
            <tr><td>DoH \u89E3\u6790</td><td class="mono">cloudflare-dns.com / dns.alidns.com / doh.pub</td></tr>
            <tr><td>Cloudflare \u7528\u91CF\u76D1\u63A7\uFF08GraphQL\uFF09</td><td class="mono">api.cloudflare.com/client/v4/graphql</td></tr>
            <tr><td>\u7248\u672C\u66F4\u65B0\u68C0\u6D4B</td><td class="mono">raw.githubusercontent.com/PAICNI/CFNext/...</td></tr>
            <tr><td>\u8FDC\u7A0B\u89C4\u5219\u96C6\uFF08sing-box / Clash\uFF09</td><td class="mono">raw.githubusercontent.com/MetaCubeX/meta-rules-dat/...</td></tr>
            <tr><td>\u9762\u677F\u4E8C\u7EF4\u7801\u5E93</td><td class="mono">cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js</td></tr>
          </tbody>
        </table></div>
      </div>
    </section>
  </div>
</div>
</div>

<div class="fbar">
  <span class="saved-at" id="savedAt">\u5C1A\u672A\u4FDD\u5B58</span>
  <button class="btn danger" id="resetBtn" onclick="resetAll()">\u91CD\u7F6E</button>
  <button class="btn primary" id="saveBtn" onclick="saveAll()"><span class="dirty-dot"></span>\u4FDD\u5B58\u5168\u90E8</button>
</div>
<div class="mmode" id="mMode">
  <div class="mmodebox">
    <h3>\u9009\u62E9\u8FD0\u884C\u6A21\u5F0F</h3>
    <div class="msub">\u56DB\u79CD\u6A21\u5F0F\u4E92\u4E0D\u5F71\u54CD\uFF0C\u4E4B\u540E\u53EF\u968F\u65F6\u5728\u300C\u9762\u677F\u8BBE\u7F6E\u300D\u91CC\u5207\u6362\u3002\u6A21\u5F0F\u51B3\u5B9A\u9762\u677F\u5F62\u6001\u4E0E\u8BA2\u9605\u4E0B\u53D1\u5185\u5BB9\uFF0C\u8BF7\u6309\u4F60\u7684\u5B9E\u9645\u60C5\u51B5\u9009\u62E9\u3002</div>
    <div class="mmodegrid">
      <button class="mmodecard" onclick="pickMode('worker')">
        <b>Worker \u6A21\u5F0F</b>
        <span>\u4F7F\u7528\u5185\u7F6E\u8282\u70B9\uFF0C\u7531\u672C\u670D\u52A1\u627F\u8F7D\u8F6C\u53D1\u3002\u5F00\u7BB1\u5373\u7528\uFF0C\u65E0\u9700\u989D\u5916\u51C6\u5907\u4EFB\u4F55\u4E1C\u897F\u3002</span>
        <em>\u9002\u5408\uFF1A\u5148\u8DD1\u901A\u3001\u770B\u91CD\u5373\u5F00\u5373\u7528</em>
      </button>
      <button class="mmodecard" onclick="pickMode('warp')">
        <b>WARP \u6A21\u5F0F</b>
        <span>\u4E0B\u53D1 WARP \u8282\u70B9\uFF0C\u7531\u5BA2\u6237\u7AEF\u76F4\u8FDE\uFF0C\u6D41\u91CF\u4E0D\u7ECF\u8FC7\u672C\u670D\u52A1\u3002\u51ED\u636E\u7531\u672C\u670D\u52A1\u81EA\u52A8\u6CE8\u518C\u5E76\u4FDD\u7BA1\uFF0C\u65E0\u9700\u81EA\u5907\u914D\u7F6E\u3002</span>
        <em>\u9002\u5408\uFF1A\u60F3\u7ED9\u672C\u670D\u52A1\u51CF\u8D1F\u3001\u5C11\u66B4\u9732</em>
      </button>
      <button class="mmodecard" onclick="pickMode('masque')">
        <b>MASQUE \u6A21\u5F0F</b>
        <span>\u4E0B\u53D1 MASQUE \u8282\u70B9\uFF0C\u540C\u6837\u7531\u5BA2\u6237\u7AEF\u76F4\u8FDE\u3002\u4EC5\u90E8\u5206\u5BA2\u6237\u7AEF\u652F\u6301\uFF0C\u51ED\u636E\u540C\u6837\u81EA\u52A8\u751F\u6210\u4E0E\u4FDD\u7BA1\uFF0C\u65E0\u9700\u81EA\u5907\u914D\u7F6E\u3002</span>
        <em>\u9002\u5408\uFF1A\u660E\u786E\u77E5\u9053\u81EA\u5DF1\u7684\u5BA2\u6237\u7AEF\u652F\u6301</em>
      </button>
      <button class="mmodecard" onclick="pickMode('home')">
        <b>\u5BB6\u5BBD\u6A21\u5F0F</b>
        <span>\u4E0B\u53D1 VPN Gate OpenVPN \u5BB6\u5BBD\u51FA\u53E3\uFF0C\u7ECF\u96A7\u9053\u524D\u7F6E\u62E8\u53F7\uFF0C\u5BA2\u6237\u7AEF\u76F4\u8FDE\u3002</span>
        <em>\u9002\u5408\uFF1A\u9700\u8981\u771F\u5B9E\u5BB6\u5BBD\u51FA\u53E3\uFF08\u4EC5 Mihomo \u5185\u6838\uFF09</em>
      </button>
    </div>
    <div class="mmodefoot"><a href="javascript:;" onclick="pickMode('worker')">\u5148\u7528 Worker \u6A21\u5F0F\uFF08\u9ED8\u8BA4\uFF09</a></div>
  </div>
</div>
<div class="toast" id="toast"></div>

<script>
/* ===== \u57FA\u7840 ===== */
var APIPATH = location.pathname.replace(/\\/+$/, '');
var CFG = null;
var LAST = [];
var toastTimer = null;
function $(id){ return document.getElementById(id); }
function api(p, opts, backend){
  opts = Object.assign({}, opts || {});
  opts.headers = new Headers(opts.headers || {});
  if (backend || window.CFN_CONFIG_BACKEND) opts.headers.set('X-CFNext-Config-Backend', backend || window.CFN_CONFIG_BACKEND);
  return fetch(APIPATH + '/api/' + p, opts).then(function(r){ return r.json(); });
}
function toast(t, ty){
  var el = $('toast');
  el.textContent = t;
  el.className = 'toast show ' + (ty || '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function(){ el.className = 'toast'; }, 2600);
}
function showMsg(id, t, ty){
  var el = $(id);
  el.textContent = t;
  el.className = 'msg show ' + (ty || 'info');
}
function copyText(t){
  var done = false;
  function fin(ok2){
    if (done) return; done = true;
    toast(ok2 ? '\u5DF2\u590D\u5236' : '\u590D\u5236\u5931\u8D25\uFF0C\u8BF7\u624B\u52A8\u590D\u5236', ok2 ? 'ok' : 'err');
  }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    var p = null;
    try { p = navigator.clipboard.writeText(t); } catch (e) { fin(fallbackCopy(t)); return; }
    if (p && typeof p.then === 'function') {
      p.then(function(){ fin(true); }, function(){ fin(fallbackCopy(t)); });
      setTimeout(function(){ fin(fallbackCopy(t)); }, 600); // \u526A\u8D34\u677F API \u60AC\u7A7A\uFF08\u65E0\u6743\u9650\u7B49\uFF09\u65F6\u56DE\u9000
    } else { fin(true); }
  } else {
    fin(fallbackCopy(t));
  }
}
function fallbackCopy(t){
  var ta = document.createElement('textarea');
  ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0';
  document.body.appendChild(ta); ta.select();
  var ok2 = false;
  try { ok2 = document.execCommand('copy'); } catch (e) { ok2 = false; }
  document.body.removeChild(ta);
  return ok2;
}
function copySub(){ copyText($('subUrl').value || makeSub()); }
function markDirty(){
  $('saveBtn').classList.add('dirty');
  $('savedAt').textContent = '\u6709\u672A\u4FDD\u5B58\u7684\u4FEE\u6539';
}

/* ===== \u5BFC\u822A ===== */
var NAV = [
  { id:'dashboard', name:'\u4EEA\u8868\u76D8', icon:'<path d="M4 4h7v7H4zM13 4h7v4h-7zM4 13h7v7H4zM13 11h7v9h-7z"/>' },
  { id:'warp', name:'WARP \u914D\u7F6E', icon:'<path d="M12 3v18M5 8l7-5 7 5M5 16l7 5 7-5"/>' },
  { id:'masque', name:'MASQUE \u914D\u7F6E', icon:'<path d="M4 7l8-4 8 4v10l-8 4-8-4zM12 3v18"/>' },
  { id:'home', name:'\u5BB6\u5BBD\u914D\u7F6E', icon:'<path d="M3 11l9-7 9 7M5 10v10h14V10M10 20v-6h4v6"/>' },
  { id:'nodes', name:'\u8282\u70B9\u914D\u7F6E', icon:'<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9zM12 12l8-4.5M12 12L4 7.5"/>' },
  { id:'optimizer', name:'\u4F18\u9009\u914D\u7F6E', icon:'<path d="M12 19a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM12 8v4l2.5 2.5M3 3l3 3"/>' },
  { id:'quota', name:'\u914D\u989D\u5B89\u5168', icon:'<path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6zM9 12l2 2 4-4"/>' },
  { id:'account', name:'\u9762\u677F\u8BBE\u7F6E', icon:'<path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21c0-3.5 3.6-6 8-6s8 2.5 8 6"/>' },
  { id:'about', name:'\u5173\u4E8E\u9879\u76EE', icon:'<path d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 11v5M12 8h.01"/>' }
];
var TITLES = { dashboard:'\u4EEA\u8868\u76D8', warp:'WARP \u914D\u7F6E', masque:'MASQUE \u914D\u7F6E', home:'\u5BB6\u5BBD\u914D\u7F6E', nodes:'\u8282\u70B9\u914D\u7F6E', optimizer:'\u4F18\u9009\u914D\u7F6E', quota:'\u914D\u989D\u5B89\u5168', account:'\u9762\u677F\u8BBE\u7F6E', about:'\u5173\u4E8E\u9879\u76EE' };

/* ===== \u8FD0\u884C\u6A21\u5F0F\uFF08\u56DB\u79CD\u6A21\u5F0F\u4E92\u4E0D\u5F71\u54CD\uFF0C\u53EF\u968F\u65F6\u5207\u6362\uFF09 ===== */
var MODE_NAV = {
  worker: ['dashboard', 'nodes', 'optimizer', 'quota', 'account', 'about'],
  warp: ['dashboard', 'warp', 'account', 'about'],
  masque: ['dashboard', 'masque', 'account', 'about'],
  home: ['dashboard', 'home', 'account', 'about']
};
var MODE_SHORT = { worker: 'Worker', warp: 'WARP', masque: 'MASQUE', home: '\u5BB6\u5BBD' };
var MODE_LABEL = { worker: 'Worker \u6A21\u5F0F', warp: 'WARP \u6A21\u5F0F', masque: 'MASQUE \u6A21\u5F0F', home: '\u5BB6\u5BBD\u6A21\u5F0F' };
var MODE_DESC = {
  worker: '\u4F7F\u7528\u5185\u7F6E\u8282\u70B9\uFF0C\u7531\u672C\u670D\u52A1\u627F\u8F7D\u8F6C\u53D1\uFF0C\u5F00\u7BB1\u5373\u7528\u3002',
  warp: '\u4E0B\u53D1 WARP \u8282\u70B9\uFF0C\u5BA2\u6237\u7AEF\u76F4\u8FDE\uFF0C\u6D41\u91CF\u4E0D\u7ECF\u8FC7\u672C\u670D\u52A1\u3002',
  masque: '\u4E0B\u53D1 MASQUE \u8282\u70B9\uFF0C\u5BA2\u6237\u7AEF\u76F4\u8FDE\uFF1B\u4EC5\u90E8\u5206\u5BA2\u6237\u7AEF\u652F\u6301\u3002',
  home: 'VPN Gate OpenVPN \u5BB6\u5BBD\u51FA\u53E3\uFF0C\u7ECF\u96A7\u9053\u524D\u7F6E\u62E8\u53F7\uFF08\u4EC5 Mihomo \u5185\u6838\uFF09\u3002'
};
function curMode(){ var m = CFG && CFG.mode; return MODE_NAV[m] ? m : 'worker'; }
function applyMode(){
  var m = curMode(), nav = MODE_NAV[m];
  buildNav();
  var active = document.querySelector('.nav-item.on');
  if (!active || nav.indexOf(active.getAttribute('data-v')) < 0) switchView(nav[0]);
  var h = $('modeHint');
  if (h) h.innerHTML = '\u5F53\u524D\uFF1A<b>' + MODE_LABEL[m] + '</b> \u2014 ' + MODE_DESC[m];
  var sel = $('a-mode');
  if (sel) sel.value = m;
  // \u5730\u533A\u4E0E\u7EBF\u8DEF\u7B5B\u9009\u53EA\u5BF9\u5185\u7F6E CF \u8282\u70B9\u6C60\u6709\u610F\u4E49\uFF1AWARP / MASQUE \u7684\u8282\u70B9\u7531\u5BA2\u6237\u7AEF\u76F4\u8FDE\uFF0C\u4E0D\u53C2\u4E0E\u5730\u533A/\u6765\u6E90\u7B5B\u9009
  var cf = $('cardFilter');
  if (cf) cf.style.display = (m === 'worker') ? '' : 'none';
  var sm = $('stMode');
  if (sm) sm.textContent = MODE_SHORT[m] || 'Worker';
}
function exitMode(){ showMode(); }
function showMode(){ $('mMode').classList.add('show'); }
function closeMode(){ $('mMode').classList.remove('show'); }
/* ===== WARP \u51ED\u636E\u72B6\u6001\u4E0E\u91CD\u7B7E\uFF08\u81EA\u52A8\u751F\u6210\uFF0C\u65E0\u9700\u624B\u586B\uFF09 ===== */
function setWStat(){
  var el = $('w-stat');
  if (!el) return;
  var c = null;
  try { c = JSON.parse(String(CFG.warpConf || '')); } catch (e) { c = null; }
  if (!c || !c.p || !c.a4) { el.textContent = '\u5C1A\u672A\u751F\u6210 \xB7 \u9996\u6B21\u62C9\u53D6\u8BA2\u9605\u65F6\u4F1A\u81EA\u52A8\u6CE8\u518C\uFF08\u65E0\u9700\u4EFB\u4F55\u586B\u5199\uFF09'; el.style.color = 'var(--warn)'; return; }
  var d = '';
  if (c.at) { try { d = ' \xB7 ' + new Date(c.at).toLocaleString('zh-CN'); } catch (e) { d = ''; } }
  el.textContent = '\u5DF2\u5C31\u7EEA \xB7 \u5185\u7F51\u5730\u5740 ' + String(c.a4).split('/')[0] + ' \xB7 \u5BF9\u7AEF ' + c.h + ':' + c.pt + d;
  el.style.color = 'var(--ok)';
}
function regenWarp(){
  if (!window.confirm('\u91CD\u65B0\u751F\u6210\u4F1A\u4F5C\u5E9F\u5F53\u524D\u51ED\u636E\u5E76\u91CD\u65B0\u6CE8\u518C\uFF0C\u5BA2\u6237\u7AEF\u9700\u91CD\u65B0\u62C9\u53D6\u8BA2\u9605\u3002\u7EE7\u7EED\uFF1F')) return;
  api('config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ warpConf: '' }) })
    .then(function(r){
      if (!r || !r.ok) { toast((r && r.msg) || '\u91CD\u7B7E\u5931\u8D25', 'err'); return; }
      CFG = r.data; setWStat(); toast('\u5DF2\u6E05\u7A7A\u51ED\u636E \xB7 \u4E0B\u6B21\u62C9\u53D6\u8BA2\u9605\u65F6\u81EA\u52A8\u91CD\u65B0\u6CE8\u518C', 'ok');
    })
    .catch(function(){ toast('\u91CD\u7B7E\u5931\u8D25', 'err'); });
}
function pickMode(m){
  if (!MODE_NAV[m]) return;
  var same = (m === curMode());
  api('config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ mode: m }) })
    .then(function(r){
      if (!r || !r.ok) { toast((r && r.msg) || '\u4FDD\u5B58\u5931\u8D25', 'err'); return; }
      CFG = r.data;
      closeMode();
      fillForm();
      renderAll();
      applyMode();
      switchView(m === 'worker' ? 'dashboard' : m);
      toast(same ? '\u5DF2\u5E94\u7528\u5F53\u524D\u6A21\u5F0F' : ('\u5DF2\u5207\u6362\u5230 ' + MODE_LABEL[m]), 'ok');
    })
    .catch(function(){ toast('\u4FDD\u5B58\u5931\u8D25\uFF1A\u65E0\u6CD5\u8FDE\u63A5\u670D\u52A1\u5668', 'err'); });
}
function switchModeFromPanel(){
  var m = $('a-mode').value;
  if (!MODE_NAV[m]) return;
  if (m === curMode()) { toast('\u5DF2\u662F\u5F53\u524D\u6A21\u5F0F'); return; }
  if (!confirm('\u5207\u6362\u5230\u300C' + MODE_LABEL[m] + '\u300D\uFF1F\\n\\n' + MODE_DESC[m] + '\\n\\n\u5404\u6A21\u5F0F\u7684\u9762\u677F\u5F62\u6001\u4E0E\u8BA2\u9605\u5185\u5BB9\u4F1A\u968F\u4E4B\u6539\u53D8\uFF0C\u53EF\u968F\u65F6\u5207\u56DE\u3002')) {
    $('a-mode').value = curMode();
    return;
  }
  pickMode(m);
}
function buildNav(){
  var nav = MODE_NAV[curMode()];
  var html = '';
  NAV.forEach(function(n){
    if (nav.indexOf(n.id) < 0) return;
    html += '<button class="nav-item" data-v="' + n.id + '" onclick="switchView(\\'' + n.id + '\\')"><svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + n.icon + '</svg>' + n.name + '</button>';
  });
  $('nav').innerHTML = html;
}
function switchView(id){
  document.querySelectorAll('.nav-item').forEach(function(b){
    b.classList.toggle('on', b.getAttribute('data-v') === id);
  });
  document.querySelectorAll('.view').forEach(function(x){
    x.classList.toggle('on', x.getAttribute('data-view') === id);
  });
  $('pageTitle').textContent = TITLES[id] || '';
  $('sidebar').classList.remove('open');
  if (id === 'account' && typeof mdPaint === 'function') mdPaint();
}
$('hamb').addEventListener('click', function(){ $('sidebar').classList.toggle('open'); });

/* ===== Material \u52A8\u6001\u53D6\u8272\uFF08\u79FB\u690D\u81EA\u53C2\u8003\u9762\u677F\uFF09 ===== */
/* ---------- sRGB \u2194 XYZ \u2194 CAM16 \u2194 HCT ---------- */
var MD_WP = [95.047, 100.0, 108.883];
var MD_XYZ2SRGB = [
  [3.2413774792388685, -1.5376652402851851, -0.49885366846268053],
  [-0.9691452513005321, 1.8758853451067872, 0.04156585616912061],
  [0.05562093689691305, -0.20395524564742123, 1.0571799111220335]
];
var MD_PI = Math.PI;
function mdClamp(a, b, x) { return x < a ? a : (x > b ? b : x); }
function mdSign(x) { return x < 0 ? -1 : (x > 0 ? 1 : 0); }
function mdDeg(d) { d = d % 360; return d < 0 ? d + 360 : d; }
var MD_LE = 216 / 24389, MD_LK = 24389 / 27;
function mdLabF(t) { return t > MD_LE ? Math.cbrt(t) : (MD_LK * t + 16) / 116; }
function mdLabInv(ft) { var f3 = ft * ft * ft; return f3 > MD_LE ? f3 : (116 * ft - 16) / MD_LK; }
function mdYFromLstar(l) { return 100 * mdLabInv((l + 16) / 116); }
function mdLstarFromY(y) { return 116 * mdLabF(y / 100) - 16; }
function mdLinear(c) { var n = c / 255; return n <= 0.040449936 ? n / 12.92 * 100 : Math.pow((n + 0.055) / 1.055, 2.4) * 100; }
function mdDelinear(c) { var n = c / 100; var d = n <= 0.0031308 ? n * 12.92 : 1.055 * Math.pow(n, 1 / 2.4) - 0.055; return mdClamp(0, 255, Math.round(d * 255)); }

/* \u89C2\u770B\u6761\u4EF6\uFF1AD65 \u767D\u70B9\u3001\u9002\u5E94\u4EAE\u5EA6 11.73\u3001\u80CC\u666F L*50\u3001\u5E73\u5747\u73AF\u7ED5\uFF0C\u53EA\u7B97\u4E00\u6B21 */
var MD_VC = (function () {
  var la = (200 / MD_PI) * mdYFromLstar(50) / 100;
  var rW = MD_WP[0] * 0.401288 + MD_WP[1] * 0.650173 + MD_WP[2] * -0.051461;
  var gW = MD_WP[0] * -0.250268 + MD_WP[1] * 1.204414 + MD_WP[2] * 0.045854;
  var bW = MD_WP[0] * -0.002079 + MD_WP[1] * 0.048952 + MD_WP[2] * 0.953127;
  var f = 1.0, cc = 0.69;
  var d = mdClamp(0, 1, f * (1 - (1 / 3.6) * Math.exp((-la - 42) / 92)));
  var rgbD = [d * (100 / rW) + 1 - d, d * (100 / gW) + 1 - d, d * (100 / bW) + 1 - d];
  var k = 1 / (5 * la + 1), k4 = k * k * k * k, k4F = 1 - k4;
  var fl = k4 * la + 0.1 * k4F * k4F * Math.cbrt(5 * la);
  var n = mdYFromLstar(50) / MD_WP[1];
  var z = 1.48 + Math.sqrt(n);
  var nbb = 0.725 / Math.pow(n, 0.2);
  var af = [Math.pow(fl * rgbD[0] * rW / 100, 0.42), Math.pow(fl * rgbD[1] * gW / 100, 0.42), Math.pow(fl * rgbD[2] * bW / 100, 0.42)];
  var aa = [400 * af[0] / (af[0] + 27.13), 400 * af[1] / (af[1] + 27.13), 400 * af[2] / (af[2] + 27.13)];
  return { n: n, aw: (2 * aa[0] + aa[1] + 0.05 * aa[2]) * nbb, nbb: nbb, ncb: nbb, c: cc, nc: f, rgbD: rgbD, fl: fl, fLRoot: Math.pow(fl, 0.25), z: z };
})();

/* \u6B63\u5411\uFF1A8 \u4F4D sRGB \u2192 { h \u8272\u76F8, c \u8272\u5EA6, t \u8272\u8C03 } */
function mdHctFromRgb(r, g, b) {
  var rl = mdLinear(r), gl = mdLinear(g), bl = mdLinear(b);
  var x = 0.41233895 * rl + 0.35762064 * gl + 0.18051042 * bl;
  var y = 0.2126 * rl + 0.7152 * gl + 0.0722 * bl;
  var z = 0.01932141 * rl + 0.11916382 * gl + 0.95034478 * bl;
  var rC = 0.401288 * x + 0.650173 * y - 0.051461 * z;
  var gC = -0.250268 * x + 1.204414 * y + 0.045854 * z;
  var bC = -0.002079 * x + 0.048952 * y + 0.953127 * z;
  var rD = MD_VC.rgbD[0] * rC, gD = MD_VC.rgbD[1] * gC, bD = MD_VC.rgbD[2] * bC;
  var rAF = Math.pow(MD_VC.fl * Math.abs(rD) / 100, 0.42);
  var gAF = Math.pow(MD_VC.fl * Math.abs(gD) / 100, 0.42);
  var bAF = Math.pow(MD_VC.fl * Math.abs(bD) / 100, 0.42);
  var rA = mdSign(rD) * 400 * rAF / (rAF + 27.13);
  var gA = mdSign(gD) * 400 * gAF / (gAF + 27.13);
  var bA = mdSign(bD) * 400 * bAF / (bAF + 27.13);
  var a = (11 * rA - 12 * gA + bA) / 11;
  var bb = (rA + gA - 2 * bA) / 9;
  var u = (20 * rA + 20 * gA + 21 * bA) / 20;
  var p2 = (40 * rA + 20 * gA + bA) / 20;
  var hue = mdDeg(Math.atan2(bb, a) * 180 / MD_PI);
  var J = 100 * Math.pow(p2 * MD_VC.nbb / MD_VC.aw, MD_VC.c * MD_VC.z);
  var hp = hue < 20.14 ? hue + 360 : hue;
  var eHue = 0.25 * (Math.cos(hp * MD_PI / 180 + 2) + 3.8);
  var p1 = (50000 / 13) * eHue * MD_VC.nc * MD_VC.ncb;
  var t = (p1 * Math.sqrt(a * a + bb * bb)) / (u + 0.305);
  var alpha = Math.pow(t, 0.9) * Math.pow(1.64 - Math.pow(0.29, MD_VC.n), 0.73);
  return { h: hue, c: alpha * Math.sqrt(J / 100), t: mdLstarFromY(y) };
}

/* \u9006\u5411\uFF1ACAM16 (J, C, H) \u2192 \u7EBF\u6027 sRGB\uFF08\u672A\u88C1\u526A\uFF0C\u7528\u4E8E\u8272\u57DF\u5224\u5B9A\uFF09 */
function mdCamToLinear(j, c, h) {
  var alpha = (c === 0 || j === 0) ? 0 : c / Math.sqrt(j / 100);
  var t = Math.pow(alpha / Math.pow(1.64 - Math.pow(0.29, MD_VC.n), 0.73), 1 / 0.9);
  var hRad = h * MD_PI / 180;
  var eHue = 0.25 * (Math.cos(hRad + 2) + 3.8);
  var ac = MD_VC.aw * Math.pow(j / 100, 1 / MD_VC.c / MD_VC.z);
  var p1 = eHue * (50000 / 13) * MD_VC.nc * MD_VC.ncb;
  var p2 = ac / MD_VC.nbb;
  var hSin = Math.sin(hRad), hCos = Math.cos(hRad);
  var gamma = (23 * (p2 + 0.305) * t) / (23 * p1 + 11 * t * hCos + 108 * t * hSin);
  var a = gamma * hCos, b = gamma * hSin;
  var rA = (460 * p2 + 451 * a + 288 * b) / 1403;
  var gA = (460 * p2 - 891 * a - 261 * b) / 1403;
  var bA = (460 * p2 - 220 * a - 6300 * b) / 1403;
  var rB = Math.max(0, 27.13 * Math.abs(rA) / (400 - Math.abs(rA)));
  var gB = Math.max(0, 27.13 * Math.abs(gA) / (400 - Math.abs(gA)));
  var bB = Math.max(0, 27.13 * Math.abs(bA) / (400 - Math.abs(bA)));
  var rC = mdSign(rA) * (100 / MD_VC.fl) * Math.pow(rB, 1 / 0.42);
  var gC = mdSign(gA) * (100 / MD_VC.fl) * Math.pow(gB, 1 / 0.42);
  var bC = mdSign(bA) * (100 / MD_VC.fl) * Math.pow(bB, 1 / 0.42);
  var rF = rC / MD_VC.rgbD[0], gF = gC / MD_VC.rgbD[1], bF = bC / MD_VC.rgbD[2];
  var X = 1.86206786 * rF - 1.01125463 * gF + 0.14918677 * bF;
  var Y = 0.38752654 * rF + 0.62144744 * gF - 0.00897398 * bF;
  var Z = -0.01584150 * rF - 0.03412294 * gF + 1.04996444 * bF;
  return [
    MD_XYZ2SRGB[0][0] * X + MD_XYZ2SRGB[0][1] * Y + MD_XYZ2SRGB[0][2] * Z,
    MD_XYZ2SRGB[1][0] * X + MD_XYZ2SRGB[1][1] * Y + MD_XYZ2SRGB[1][2] * Z,
    MD_XYZ2SRGB[2][0] * X + MD_XYZ2SRGB[2][1] * Y + MD_XYZ2SRGB[2][2] * Z
  ];
}
function mdInGamut(v) {
  return v[0] >= -0.01 && v[0] <= 100.01 && v[1] >= -0.01 && v[1] <= 100.01 && v[2] >= -0.01 && v[2] <= 100.01;
}
function mdLinToRgb(v) { return [mdDelinear(v[0]), mdDelinear(v[1]), mdDelinear(v[2])]; }

/* \u6C42\u51FA\u8BA9\u91CF\u5316\u540E\u8272\u8C03\u7B49\u4E8E tone \u7684 CAM16 \u660E\u5EA6 J */
function mdJForTone(h, c, tone) {
  var lo = 0.01, hi = 99.9, i, mid, rgb, lt;
  for (i = 0; i < 24; i++) {
    mid = (lo + hi) / 2;
    rgb = mdLinToRgb(mdCamToLinear(mid, c, h));
    lt = mdLstarFromY(mdLinear(rgb[0]) * 0.2126 + mdLinear(rgb[1]) * 0.7152 + mdLinear(rgb[2]) * 0.0722);
    if (lt < tone) { lo = mid; } else { hi = mid; }
  }
  return (lo + hi) / 2;
}
/* HCT \u2192 sRGB\uFF1A\u5148\u628A\u8272\u5EA6\u6536\u655B\u5230\u8272\u57DF\u5185\uFF08\u4FDD\u4F4F\u8272\u8C03\u3001\u727A\u7272\u8272\u5EA6\uFF09\uFF0C\u518D\u89E3\u660E\u5EA6 */
function mdRgbFromHct(hue, chroma, tone) {
  var h = mdDeg(hue), t = mdClamp(0, 100, tone);
  if (!(chroma >= 1e-4) || t >= 99.9999 || t <= 0.0001) {
    var g = mdDelinear(mdYFromLstar(t));
    return [g, g, g];
  }
  var lo = 0, hi = chroma, i, mid;
  for (i = 0; i < 16; i++) {
    mid = (lo + hi) / 2;
    if (mdInGamut(mdCamToLinear(mdJForTone(h, mid, t), mid, h))) { lo = mid; } else { hi = mid; }
  }
  if (lo < 1e-4) { var g2 = mdDelinear(mdYFromLstar(t)); return [g2, g2, g2]; }
  return mdLinToRgb(mdCamToLinear(mdJForTone(h, lo, t), lo, h));
}

/* ---------- \u5341\u516D\u8FDB\u5236\u4E92\u8F6C ---------- */
function mdHexToRgb(hx) {
  var s = String(hx || '').replace(/[^0-9a-fA-F]/g, '');
  if (s.length === 3) s = s[0] + s[0] + s[1] + s[1] + s[2] + s[2];
  if (s.length !== 6) return null;
  return [parseInt(s.slice(0, 2), 16), parseInt(s.slice(2, 4), 16), parseInt(s.slice(4, 6), 16)];
}
function mdRgbToHex(v) {
  return '#' + v.map(function (x) { var s = mdClamp(0, 255, Math.round(x)).toString(16); return s.length < 2 ? '0' + s : s; }).join('');
}
function mdHctFromHex(hx) { var v = mdHexToRgb(hx); return v ? mdHctFromRgb(v[0], v[1], v[2]) : { h: 0, c: 0, t: 50 }; }
function mdHexFromHct(h, c, t) { return mdRgbToHex(mdRgbFromHct(h, c, t)); }

/* ---------- \u8272\u8C03\u4E0E\u4E3B\u9898\u65B9\u6848 ---------- */
/* \u6587\u6863\u7684 13 \u4E2A\u8272\u8C03\u6807\u53F7 0/10/50/100/200\u20261000 \u2194 HCT \u8272\u8C03 100/99/95/90/80\u20260 */
var MD_TONE_LABELS = [0, 10, 50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];
function mdLabelToTone(L) { return (1000 - L) / 10; }
var MD_TONES = MD_TONE_LABELS.map(mdLabelToTone);

/* \u4E3B\u9898\u65B9\u6848\uFF1Ahue \u4E3A\u5404\u8C03\u8272\u76D8\u76F8\u5BF9\u6765\u6E90\u8272\u7684\u8272\u76F8\u504F\u79FB\uFF0Cchroma \u4E3A\u8272\u5EA6\uFF0C
   n \u4E3A neutral1/neutral2 \u8272\u5EA6\uFF0Ccap \u4E3A\u9AD8\u8272\u8C03\uFF08\u226590\uFF09\u7684\u8272\u5EA6\u4E0A\u9650\u3002
   TONAL_SPOT \u5B8C\u5168\u6309\u6587\u6863\uFF1Aaccent1 \u8272\u5EA6 48\u3001\u9AD8\u8272\u8C03 40\uFF1Baccent2 16\uFF1Baccent3 \u8272\u76F8 +60\u3001\u8272\u5EA6 32\uFF1B
   neutral1 \u8272\u5EA6 4\uFF1Bneutral2 \u8272\u5EA6 8\u3002 */
var MD_VARIANTS = [
  { id: 'TONAL_SPOT', name: '\u8272\u8C03\u70B9', desc: 'Android \u9ED8\u8BA4\u65B9\u6848\uFF0C\u4F4E\u5230\u4E2D\u7B49\u5F69\u5EA6', hue: [0, 0, 60], chroma: [48, 16, 32], n: [4, 8], cap: 40 },
  { id: 'VIBRANT', name: '\u9C9C\u8273', desc: '\u6B21\u8272\u4E0E\u4E09\u8272\u4E0E\u4E3B\u8272\u540C\u7C7B\uFF0C\u6574\u4F53\u66F4\u9971\u548C', hue: [0, 0, 60], chroma: [64, 32, 48], n: [6, 10], cap: 40 },
  { id: 'EXPRESSIVE', name: '\u8868\u73B0\u529B', desc: '\u9AD8\u5F69\u5EA6\uFF0C\u8272\u76F8\u95F4\u62C9\u5F00\u8DDD\u79BB', hue: [0, 15, -45], chroma: [72, 36, 56], n: [8, 12], cap: 44 },
  { id: 'SPRITZ', name: '\u7070\u8C03', desc: '\u53BB\u9971\u548C\uFF0C\u63A5\u8FD1\u7070\u9636', hue: [0, 0, 60], chroma: [14, 8, 18], n: [3, 5], cap: 14 }
];
function mdVariant(id) {
  for (var i = 0; i < MD_VARIANTS.length; i++) { if (MD_VARIANTS[i].id === id) return MD_VARIANTS[i]; }
  return MD_VARIANTS[0];
}

/* ---------- \u7531\u6765\u6E90\u8272\u6D3E\u751F 5 \u4E2A\u8272\u8C03\u8C03\u8272\u76D8 ---------- */
function mdPalettes(seedHex, variantId) {
  var src = mdHctFromHex(seedHex);
  /* \u6587\u6863\u8981\u6C42\u6765\u6E90\u8272\u7684 CAM16 \u8272\u5EA6\u4E0D\u4F4E\u4E8E 5\uFF0C\u5426\u5219\u8272\u76F8\u4E0D\u7A33 */
  var hue = src.h, chroma = Math.max(5, src.c);
  var V = mdVariant(variantId);
  var cap = function (c, t) { return t >= 90 ? Math.min(c, V.cap) : c; };
  var P = {
    a1: { h: hue, c: V.chroma[0] },
    a2: { h: mdDeg(hue + V.hue[1]), c: V.chroma[1] },
    a3: { h: mdDeg(hue + V.hue[2]), c: V.chroma[2] },
    n1: { h: hue, c: V.n[0] },
    n2: { h: hue, c: V.n[1] },
    err: { h: 25, c: 84 }
  };
  for (var k in P) { P[k].at = function (t) { return mdHexFromHct(this.h, cap(this.c, t), t); }; }
  P.err.at = function (t) { return mdHexFromHct(this.h, this.c, t); };
  P.seed = seedHex;
  P.sourceChroma = chroma;
  return P;
}
/* 65 \u8272\uFF1A5 \u4E2A\u8C03\u8272\u76D8 \xD7 13 \u4E2A\u8272\u8C03\uFF0C\u952E\u4E3A\u6587\u6863\u6807\u53F7 */
function mdTonal(seedHex, variantId) {
  var P = mdPalettes(seedHex, variantId);
  var out = {};
  ['a1', 'a2', 'a3', 'n1', 'n2'].forEach(function (k) {
    var row = {};
    MD_TONE_LABELS.forEach(function (L) { row[L] = P[k].at(mdLabelToTone(L)); });
    out[k] = row;
  });
  return out;
}

/* ---------- \u989C\u8272\u89D2\u8272\u6620\u5C04\uFF08\u6587\u6863\u300CMaterial \u5E93\u989C\u8272\u5C5E\u6027\u66F4\u65B0\u300D\u8868\uFF09 ---------- */
/* [\u89D2\u8272, \u8C03\u8272\u76D8, \u6D45\u8272\u4E3B\u9898\u8272\u8C03, \u6DF1\u8272\u4E3B\u9898\u8272\u8C03] \u2014\u2014 \u6807\u53F7 N \u2194 \u8272\u8C03 (1000-N)/10 */
var MD_ROLE_MAP = [
  ['primary', 'a1', 600, 200], ['onPrimary', 'a1', 0, 800],
  ['primaryContainer', 'a1', 100, 700], ['onPrimaryContainer', 'a1', 900, 900],
  ['secondary', 'a2', 600, 200], ['onSecondary', 'a2', 0, 800],
  ['secondaryContainer', 'a2', 100, 700], ['onSecondaryContainer', 'a2', 900, 900],
  ['tertiary', 'a3', 600, 200], ['onTertiary', 'a3', 0, 800],
  ['tertiaryContainer', 'a3', 100, 700], ['onTertiaryContainer', 'a3', 900, 900],
  ['error', 'err', 600, 200], ['onError', 'err', 0, 800],
  ['errorContainer', 'err', 100, 700], ['onErrorContainer', 'err', 900, 900],
  ['background', 'n1', 10, 900],
  ['onBackground', 'n1', 900, 100],
  ['surface', 'n1', 10, 900], ['onSurface', 'n1', 900, 100],
  ['surfaceContainerLowest', 'n1', 0, 1000], ['surfaceContainerLow', 'n1', 100, 900],
  ['surfaceContainer', 'n1', 200, 800], ['surfaceContainerHigh', 'n1', 300, 700],
  ['surfaceContainerHighest', 'n1', 400, 600],
  ['surfaceVariant', 'n2', 100, 700], ['onSurfaceVariant', 'n2', 700, 200],
  ['outline', 'n2', 500, 400], ['outlineVariant', 'n2', 200, 700],
  ['inverseSurface', 'n1', 800, 100], ['inverseOnSurface', 'n1', 100, 800],
  ['inversePrimary', 'a1', 200, 600],
  /* \u906E\u7F69\u4E0E\u6295\u5F71\u4E0D\u968F\u6DF1\u6D45\u7FFB\u8F6C\uFF1AM3 \u89C4\u5B9A\u4E24\u8005\u5728\u4EFB\u4F55\u4E3B\u9898\u4E0B\u90FD\u662F\u7EAF\u9ED1 */
  ['scrim', 'n1', 1000, 1000], ['shadow', 'n1', 1000, 1000],
  /* \u72B6\u6001\u5C42\u4E0E\u72B6\u6001\u5185\u5BB9\uFF08\u6587\u6863\u7B2C\u4E8C\u5F20\u8868\uFF09 */
  ['primaryStateContent', 'a1', 700, 200], ['primaryStateLayer', 'a1', 600, 300],
  ['secondaryStateContent', 'a2', 700, 200], ['secondaryStateLayer', 'a2', 600, 300],
  ['onPrimaryStateContent', 'a1', 0, 800], ['onPrimaryStateLayer', 'a1', 900, 800],
  ['onSecondaryStateContent', 'a2', 0, 800], ['onSecondaryStateLayer', 'a2', 900, 800],
  ['onSurfaceStateContent', 'n1', 900, 100], ['onSurfaceStateLayer', 'n1', 900, 100],
  ['onSurfaceVariantStateContent', 'n2', 700, 200], ['onSurfaceVariantStateLayer', 'n2', 700, 200],
  ['errorStateContent', 'err', 800, 200]
];
function mdRoleKey(role) {
  return role.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase();
}
/* \u751F\u6210\u6574\u5957\u989C\u8272\u89D2\u8272\uFF1Bdark \u4E3A\u771F\u65F6\u53D6\u6DF1\u8272\u4E3B\u9898\u5217 */
function mdRoles(seedHex, variantId, dark) {
  var P = mdPalettes(seedHex, variantId);
  var out = {};
  MD_ROLE_MAP.forEach(function (row) {
    var pal = P[row[1]], L = dark ? row[3] : row[2];
    out[row[0]] = pal.at(mdLabelToTone(L));
  });
  return out;
}
/* \u628A\u89D2\u8272\u5199\u6210 CSS \u53D8\u91CF */
function mdApply(seedHex, variantId, dark) {
  var r = mdRoles(seedHex, variantId, dark);
  var st = document.documentElement.style;
  for (var k in r) { st.setProperty('--m-' + mdRoleKey(k), r[k]); }
  return r;
}

/* ---------- Material \u5916\u89C2 ---------- */
var MD_SEED_DEF = '#6750A4';
var MD_PNAME = { a1: 'accent1', a2: 'accent2', a3: 'accent3', n1: 'neutral1', n2: 'neutral2' };
function storedStyle(){ try { return localStorage.getItem('nb_style') || 'glass'; } catch (e) { return 'glass'; } }
function storedSeed(){
  try { var v = localStorage.getItem('nb_seed'); return (v && mdHexToRgb(v)) ? v : MD_SEED_DEF; } catch (e) { return MD_SEED_DEF; }
}
function storedVariant(){ try { return localStorage.getItem('nb_variant') || 'TONAL_SPOT'; } catch (e) { return 'TONAL_SPOT'; } }
function savePref(k, v){ try { localStorage.setItem(k, v); } catch (e) {} }
function normHex(hx){ var v = mdHexToRgb(hx); return v ? mdRgbToHex(v) : null; }

/* \u6D3E\u751F 65 \u8272\u89D2\u8272\u5199\u5165 CSS \u53D8\u91CF\uFF1B\u53D8\u91CF\u5C31\u7EEA\u540E\u624D\u6302 data-style\uFF0C\u907F\u514D\u9996\u5E27\u95EA\u70C1 */
function mdSync(){
  var roles = mdApply(storedSeed(), storedVariant(), resolveTheme(storedTheme()) !== 'light');
  document.documentElement.setAttribute('data-style', storedStyle());
  return roles;
}
function setStyle(s){ savePref('nb_style', s); mdSync(); mdPaint(); }
function setSeed(hx){
  var v = normHex(hx); if (!v) return false;
  savePref('nb_seed', v); mdSync(); mdPaint(); return true;
}
function setVariant(id){ savePref('nb_variant', id); mdSync(); mdPaint(); }
function resetSeed(){ var i = $('mdSeed'); var s = setSeed(MD_SEED_DEF); if (i) i.value = storedSeed(); return s; }

/* ---------- \u5916\u89C2\u98CE\u683C\uFF1A\u8272\u5F69\u8BBE\u7F6E\u6298\u53E0\uFF08\u4ECE\u300C\u79CD\u5B50\u8272\u300D\u8D77\u6536\u8D77\uFF09 ---------- */
function mdFoldSet(open){
  var b = $('mdFoldBtn'), d = $('mdBox');
  if (!b || !d) return;
  d.classList[open ? 'add' : 'remove']('open');
  b.setAttribute('data-open', open ? '1' : '0');
  b.title = open ? '\u6536\u8D77\u8272\u5F69\u8BBE\u7F6E' : '\u5C55\u5F00\u8272\u5F69\u8BBE\u7F6E';
}
function mdFoldInit(){
  var open = false;
  try { open = localStorage.getItem('nb_mdfold') === '1'; } catch (e) {}
  mdFoldSet(open);
}
function toggleMdFold(){
  var b = $('mdFoldBtn');
  var open = !(b && b.getAttribute('data-open') === '1');
  try { localStorage.setItem('nb_mdfold', open ? '1' : '0'); } catch (e) {}
  mdFoldSet(open);
  if (open && typeof mdPaint === 'function') mdPaint();
}

function buildOnce(el, html){
  if (!el || el.getAttribute('data-built')) return;
  el.innerHTML = html; el.setAttribute('data-built', '1');
}
/* \u6E32\u67D3\u5916\u89C2\u5361\u7247\uFF1A\u98CE\u683C\u6BB5\u9009\u3001\u79CD\u5B50\u8272\u677F\u3001\u65B9\u6848\u6BB5\u9009\u300165 \u8272\u9884\u89C8 */
function mdPaint(){
  var seed = storedSeed(), variant = storedVariant(), style = storedStyle();
  var seg = document.querySelectorAll('#styleSeg button');
  for (var i = 0; i < seg.length; i++) seg[i].classList.toggle('on', seg[i].getAttribute('data-s') === style);

  var sr = $('mdSeedRow');
  if (sr) {
    buildOnce(sr, ["#6750A4","#0B57D0","#006A6A","#006E1C","#7A5900","#8B5000","#BA1A1A","#B90063","#7C6CFF","#5F6368"].map(function (c) {
      return '<i data-c="' + c + '" style="background:' + c + '" title="' + c + '"></i>';
    }).join(''));
    var its = sr.querySelectorAll('i');
    for (var j = 0; j < its.length; j++) {
      its[j].classList.toggle('on', normHex(its[j].getAttribute('data-c')) === normHex(seed));
    }
    if (!sr.getAttribute('data-bound')) {
      sr.setAttribute('data-bound', '1');
      sr.addEventListener('click', function (e) {
        var t = e.target;
        if (t && t.tagName === 'I') { var c = t.getAttribute('data-c'); var inp = $('mdSeed'); if (inp) inp.value = c; setSeed(c); }
      });
    }
  }
  var vs = $('mdVarSeg');
  if (vs) {
    buildOnce(vs, MD_VARIANTS.map(function (v) {
      return '<button class="btn sm" data-v="' + v.id + '" onclick="setVariant(\\'' + v.id + '\\')">' + v.name + '</button>';
    }).join(''));
    var vb = vs.querySelectorAll('button');
    for (var m = 0; m < vb.length; m++) vb[m].classList.toggle('on', vb[m].getAttribute('data-v') === variant);
  }
  var dsc = $('mdVarDesc');
  if (dsc) dsc.textContent = mdVariant(variant).desc;

  var pal = $('mdPal');
  if (pal) {
    buildOnce(pal, ['a1', 'a2', 'a3', 'n1', 'n2'].map(function (row) {
      return '<div class="r"><b>' + MD_PNAME[row] + '</b>' + MD_TONE_LABELS.map(function (L) {
        return '<i data-p="' + row + '" data-l="' + L + '"></i>';
      }).join('') + '</div>';
    }).join(''));
    var T = mdTonal(seed, variant);
    var cells = pal.querySelectorAll('i');
    var srgb = mdHexToRgb(seed), best = null, bestD = 1e9;
    for (var n = 0; n < cells.length; n++) {
      var cp = cells[n].getAttribute('data-p'), cl = cells[n].getAttribute('data-l');
      var hx = T[cp][cl], c = mdHexToRgb(hx);
      cells[n].style.background = hx;
      cells[n].setAttribute('data-hex', hx);
      cells[n].title = MD_PNAME[cp] + ' \xB7 ' + cl + ' \xB7 ' + hx + '\\n\u5355\u51FB\u8BBE\u4E3A\u79CD\u5B50\u8272';
      cells[n].classList.remove('on');
      var d = Math.abs(c[0] - srgb[0]) + Math.abs(c[1] - srgb[1]) + Math.abs(c[2] - srgb[2]);
      if (d < bestD) { bestD = d; best = cells[n]; }   /* \u79CD\u5B50\u8272\u5728\u8272\u677F\u4E2D\u7684\u843D\u70B9 */
    }
    if (best) best.classList.add('on');
    /* \u5355\u51FB\u4EFB\u4E00\u8272\u5757 \u2192 \u8BE5\u8272\u6210\u4E3A\u65B0\u7684\u79CD\u5B50\u8272\uFF08\u4E0E\u4E0A\u65B9\u9884\u8BBE\u8272\u677F\u540C\u4E00\u5957\u4EA4\u4E92\uFF09 */
    if (!pal.getAttribute('data-bound')) {
      pal.setAttribute('data-bound', '1');
      pal.addEventListener('click', function (e) {
        var t = e.target;
        if (!t || t.tagName !== 'I') return;
        var hx = t.getAttribute('data-hex');
        if (!hx || !mdHexToRgb(hx)) return;
        if (normHex(hx) === normHex(storedSeed())) { toast('\u5DF2\u662F\u5F53\u524D\u79CD\u5B50\u8272 ' + hx); return; }
        var i = $('mdSeed'); if (i) i.value = hx;
        setSeed(hx);
        toast('\u79CD\u5B50\u8272\u5DF2\u66F4\u65B0 \xB7 ' + hx);
      });
    }
  }
  var po = $('mdPalOut');
  if (po) {
    var found = null;
    if (pal) {
      var cs = pal.querySelectorAll('i');
      for (var k = 0; k < cs.length; k++) if (cs[k].classList.contains('on')) { found = cs[k]; break; }
    }
    po.innerHTML = '<i class="chip" style="background:' + seed + '"></i>' +
      '<span class="hx" title="\u70B9\u51FB\u590D\u5236" onclick="copySeed()">' + seed + '</span>' +
      '<span class="tag">\u5F53\u524D\u79CD\u5B50\u8272' + (found
        ? ' \xB7 \u843D\u70B9 ' + MD_PNAME[found.getAttribute('data-p')] + ' \xB7 ' + found.getAttribute('data-l')
        : '') + '\u3000\u5355\u51FB\u8272\u5757\u5373\u53EF\u6539\u7528\u8BE5\u8272</span>';
  }
  var inp = $('mdSeed');
  if (inp && document.activeElement !== inp) inp.value = seed;
}

/* \u590D\u5236\u5F53\u524D\u79CD\u5B50\u8272 */
function copySeed(){ copyText(storedSeed()); }

/* ---------- \u6D9F\u6F2A\uFF08Material \u89E6\u63A7\u53CD\u9988\uFF09 ---------- */
function mdRipple(e){
  if (storedStyle() !== 'material') return;
  if (!e.target || !e.target.closest) return;
  var host = e.target.closest('.btn,.ibtn,.nav-item,.sp span,.pill,.fgrp');
  if (!host) return;
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var r = host.getBoundingClientRect();
  if (!r.width || !r.height) return;
  var d = Math.max(r.width, r.height) * 2;
  var sp = document.createElement('span');
  sp.className = 'md-rip';
  sp.style.width = sp.style.height = d + 'px';
  sp.style.left = (e.clientX - r.left - d / 2) + 'px';
  sp.style.top = (e.clientY - r.top - d / 2) + 'px';
  host.appendChild(sp);
  setTimeout(function () { if (sp.parentNode) sp.parentNode.removeChild(sp); }, 640);
}

/* ===== \u4E3B\u9898 ===== */
function systemIsLight(){ return window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches; }
function storedTheme(){ var t = 'dark'; try { t = localStorage.getItem('tp_theme') || 'dark'; } catch(e) {} return t; }
function resolveTheme(t){ if (t === 'auto') return systemIsLight() ? 'light' : 'dark'; return t; }
function setThemeIcon(t){
  var p = document.getElementById('themeIcon');
  if (!p) return;
  if (t === 'light') p.setAttribute('d', 'M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10zM12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4');
  else p.setAttribute('d', 'M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z');
}
function applyTheme(){
  var t = resolveTheme(storedTheme());
  document.documentElement.setAttribute('data-theme', t);
  setThemeIcon(t);
  if (typeof mdSync === 'function') mdSync();
}
function setTheme(t){
  try { localStorage.setItem('tp_theme', t); } catch(e) {}
  applyTheme();
  toast(t === 'auto' ? '\u5DF2\u5207\u6362\u4E3A\u8DDF\u968F\u7CFB\u7EDF' : (t === 'light' ? '\u5DF2\u5207\u6362\u4E3A\u65E5\u95F4\u6A21\u5F0F' : '\u5DF2\u5207\u6362\u4E3A\u591C\u95F4\u6A21\u5F0F'), 'ok');
}
$('themeBtn').addEventListener('click', function(){
  var cur = storedTheme();
  var next = (cur === 'light') ? 'dark' : 'light';
  setTheme(next);
});
applyTheme();
if (typeof mdFoldInit === 'function') mdFoldInit();

/* ===== \u66F4\u65B0\u68C0\u6D4B ===== */
var topVerText = 'v\u2014';
function legacyCopy(t){
  try {
    var ta = document.createElement('textarea');
    ta.value = t;
    ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
    document.body.appendChild(ta);
    ta.select();
    var ok2 = false;
    try { ok2 = document.execCommand('copy'); } catch (e) { ok2 = false; }
    document.body.removeChild(ta);
    return ok2;
  } catch (e) { return false; }
}
function copyClipboard(t){
  return new Promise(function(ok){
    var done = false;
    function finish(v){ if (done) return; done = true; ok(v); }
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        var p = null;
        try { p = navigator.clipboard.writeText(t); } catch (e) { finish(legacyCopy(t)); return; }
        if (p && typeof p.then === 'function') {
          p.then(function(){ finish(true); }, function(){ finish(legacyCopy(t)); });
          setTimeout(function(){ finish(legacyCopy(t)); }, 600); // \u526A\u8D34\u677F API \u60AC\u7A7A\uFF08\u65E0\u6743\u9650\u7B49\uFF09\u65F6\u56DE\u9000
        } else { finish(true); }
      } else {
        finish(legacyCopy(t));
      }
    } catch (e) { finish(legacyCopy(t)); }
  });
}
function checkUpdate(){
  var sv = $('sideVer');
  if (sv.classList.contains('checking')) return;
  sv.classList.add('checking');
  sv.textContent = '\u68C0\u6D4B\u4E2D\u2026';
  api('update').then(function(r){
    sv.classList.remove('checking');
    if (!r || !r.ok || !r.data) { sv.textContent = topVerText; toast('\u68C0\u6D4B\u66F4\u65B0\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5', 'err'); return; }
    var d = r.data;
    var kindName = '\u524D\u540E\u7AEF\u5206\u79BB\u7248';   // \u5206\u79BB\u7248\u56FA\u5B9A\u5F62\u6001\uFF0C\u4E0D\u968F\u540E\u7AEF\u6784\u5EFA\u5F62\u6001\u53D8\u5316
    topVerText = 'v' + d.current + kindName;
    sv.textContent = topVerText;
    if (d.hasUpdate && d.code) {
      sv.classList.add('has-update');
      var kind = (d.kind === '\u5C0F\u8BF4\u6DF7\u6DC6') ? '\u5C0F\u8BF4\u6DF7\u6DC6' : (d.kind === '\u6DF7\u6DC6') ? '\u6DF7\u6DC6' : '\u660E\u6587';
      copyClipboard(d.code).then(function(copied){
        toast(copied ? '\u68C0\u6D4B\u5230\u66F4\u65B0\uFF0C\u5DF2\u590D\u5236\u6700\u65B0' + kind + '\u4EE3\u7801\u5230\u526A\u8D34\u677F' : '\u68C0\u6D4B\u5230\u66F4\u65B0\uFF08v' + d.latest + '\uFF09\uFF0C\u590D\u5236\u5931\u8D25\uFF0C\u8BF7\u524D\u5F80\u4ED3\u5E93\u83B7\u53D6', copied ? 'ok' : 'err');
      });
    } else if (d.hasUpdate) {
      toast('\u68C0\u6D4B\u5230\u66F4\u65B0\uFF08v' + d.latest + '\uFF09\uFF0C\u4F46\u672A\u80FD\u83B7\u53D6\u4EE3\u7801', 'err');
    } else if (d.latest) {
      sv.classList.remove('has-update');
      toast('\u5DF2\u662F\u6700\u65B0\u7248\u672C\uFF08v' + d.current + ' ' + kindName + '\uFF09', 'ok');
    } else {
      toast('\u68C0\u6D4B\u66F4\u65B0\u5931\u8D25\uFF1A' + (d.error || '\u4ED3\u5E93\u6682\u4E0D\u53EF\u8FBE'), 'err');
    }
  }).catch(function(){
    sv.classList.remove('checking');
    sv.textContent = topVerText;
    toast('\u68C0\u6D4B\u66F4\u65B0\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5', 'err');
  });
}

/* ===== \u914D\u7F6E\u52A0\u8F7D\u4E0E\u56DE\u586B ===== */
var preferredCards = [];
function hasPreferredDrafts(){return preferredCards.some(function(c){return c.dirty || c.saving;});}
window.addEventListener('beforeunload',function(e){if(hasPreferredDrafts()){e.preventDefault();e.returnValue='';}});
function preferredPayload(text){
  var domains=[],ips=[],seen={};
  String(text||'').split(/\\n+/).map(function(s){return s.trim();}).filter(Boolean).forEach(function(line){
    if(line.indexOf('://')>=0){domains.push(line);return;}
    line.split(/[;,]+/).map(function(s){return s.trim();}).filter(Boolean).forEach(function(s){
      var list=parseIps(s);
      if(!list.length){domains.push(s);return;}
      var ip=list[0],key=ip.ip+':'+ip.port;
      if(!seen[key]){seen[key]=true;ips.push(ip);}
    });
  });
  return {preferredDomains:domains.join('\\n'),preferredIPs:ips};
}
function preferredTarget(){
  var target=$('preferred-target');
  return preferredCards.find(function(c){return c.backend.url===target.value;});
}
function loadPreferredOverview(){
  var summary=$('preferred-summary'),wrap=$('preferred-overview'),target=$('preferred-target');
  if(!summary || !wrap)return;
  if(hasPreferredDrafts()&&!confirm('\u5237\u65B0\u4F1A\u653E\u5F03\u5361\u7247\u4E2D\u672A\u4FDD\u5B58\u7684\u4F18\u9009\u914D\u7F6E\uFF0C\u662F\u5426\u7EE7\u7EED\uFF1F'))return;
  if(preferredCards.some(function(c){return c.saving;})){toast('\u8BF7\u7B49\u5F85\u540E\u7AEF\u4FDD\u5B58\u5B8C\u6210','warn');return;}
  var previous=target.value;
  summary.textContent='\u6B63\u5728\u8BFB\u53D6\u5404\u540E\u7AEF\u914D\u7F6E\u2026';
  fetch('/preferred-backends').then(function(r){if(!r.ok)throw new Error('HTTP '+r.status);return r.json();}).then(function(r){
    if(!r.ok)throw new Error(r.msg||'\u8BFB\u53D6\u5931\u8D25');
    if(hasPreferredDrafts()){summary.textContent='\u5237\u65B0\u671F\u95F4\u5B58\u5728\u672A\u4FDD\u5B58\u6216\u6B63\u5728\u4FDD\u5B58\u7684\u4FEE\u6539\uFF0C\u5DF2\u4FDD\u7559\u5F53\u524D\u5361\u7247\uFF1B\u4FDD\u5B58\u5B8C\u6210\u540E\u53EF\u91CD\u65B0\u5237\u65B0\u3002';return;}
    wrap.textContent='';wrap.className='grid2';target.textContent='';preferredCards=[];
    var success=r.backends.filter(function(b){return !b.error;});
    var total=success.reduce(function(n,b){return n+b.lines.length;},0);
    summary.textContent='\u5DF2\u8BFB\u53D6 '+success.length+'/'+r.backends.length+' \u4E2A\u540E\u7AEF\uFF0C\u5171 '+total+' \u6761\u914D\u7F6E\u5730\u5740\uFF1B'+(r.multi?'\u8BA2\u9605\u805A\u5408\u5DF2\u5F00\u542F\u3002':'\u5F53\u524D\u672A\u5F00\u542F\u8BA2\u9605\u805A\u5408\u3002')+' \u57DF\u540D/API \u89E3\u6790\u3001\u534F\u8BAE\u548C\u914D\u989D\u7B56\u7565\u53EF\u80FD\u5F71\u54CD\u5B9E\u9645\u4E0B\u53D1\u6570\u91CF\uFF0C\u4EE5\u8BA2\u9605\u9884\u89C8\u4E3A\u51C6\u3002';
    r.backends.forEach(function(b){
      var card=document.createElement('div');card.className='field';card.style.margin='0 0 16px';card.dataset.backendIndex=b.index;
      var title=document.createElement('label');title.textContent='\u540E\u7AEF'+(b.index+1)+(b.error?' \xB7 \u8BFB\u53D6\u5931\u8D25':' \xB7 '+b.lines.length+' \u6761\u914D\u7F6E\u5730\u5740');card.appendChild(title);
      if(b.error){var error=document.createElement('p');error.className='hint';error.textContent=b.error;card.appendChild(error);wrap.appendChild(card);return;}
      var option=document.createElement('option');option.value=b.url;option.textContent='\u540E\u7AEF'+(b.index+1);target.appendChild(option);
      function select(label,entries,value){
        var field=document.createElement('div');field.className='field';field.style.margin='8px 0';
        var name=document.createElement('label');name.textContent=label;var input=document.createElement('select');input.setAttribute('aria-label','\u540E\u7AEF'+(b.index+1)+label);
        entries.forEach(function(v){var o=document.createElement('option');o.value=v[0];o.textContent=v[1];input.appendChild(o);});input.value=value;field.appendChild(name);field.appendChild(input);card.appendChild(field);return input;
      }
      var mode=select('\u8BA2\u9605\u6A21\u5F0F',[['custom','\u81EA\u5B9A\u4E49\u8BA2\u9605\uFF08\u652F\u6301\u6C47\u805A\uFF09'],['','\u9ED8\u8BA4\u8282\u70B9\u6C60'],['random','\u968F\u673A\u5019\u9009\u6A21\u5F0F\uFF08\u672A\u6D4B\u901F\uFF09']],b.subMode);
      var defaults=select('\u8FFD\u52A0\u9ED8\u8BA4\u8282\u70B9',[['0','\u5173\u95ED\uFF08\u4EC5\u81EA\u5B9A\u4E49\u8282\u70B9\uFF09'],['1','\u5F00\u542F']],b.includeDefault?'1':'0');
      var list=document.createElement('textarea');list.rows=7;list.value=b.lines.join('\\n');list.setAttribute('aria-label','\u540E\u7AEF'+(b.index+1)+'\u4F18\u9009\u8282\u70B9');card.appendChild(list);
      var random=document.createElement('input');random.type='number';random.min='1';random.max='99';random.value=b.randomCount||16;random.setAttribute('aria-label','\u540E\u7AEF'+(b.index+1)+'\u968F\u673A\u5019\u9009\u6570\u91CF');card.appendChild(random);
      var hint=document.createElement('p');hint.className='hint';hint.textContent='\u6BCF\u884C\u4E00\u4E2A\uFF1AIP:\u7AEF\u53E3#\u540D\u79F0\u3001\u57DF\u540D\u6216\u4F18\u9009 API\u3002\u53EA\u4FDD\u5B58\u5230\u6B64\u540E\u7AEF\u3002';card.appendChild(hint);
      var message=document.createElement('p');message.className='hint';card.appendChild(message);
      var save=document.createElement('button');save.className='btn sm primary';save.type='button';save.textContent='\u4FDD\u5B58\u540E\u7AEF'+(b.index+1);card.appendChild(save);
      var c={backend:b,list:list,mode:mode,defaults:defaults,random:random,dirty:false,saving:false};preferredCards.push(c);
      function visibility(){list.style.display=mode.value==='custom'?'':'none';random.style.display=mode.value==='random'?'':'none';defaults.disabled=!mode.value;}
      c.mark=function(){c.dirty=true;message.textContent='\u6709\u672A\u4FDD\u5B58\u7684\u4FEE\u6539';visibility();};
      card.addEventListener('input',c.mark);card.addEventListener('change',c.mark);visibility();
      save.onclick=function(){
        var count=Number(random.value);
        if(mode.value==='random'&&(!Number.isInteger(count)||count<1||count>99)){toast('\u968F\u673A\u5019\u9009\u6570\u91CF\u987B\u4E3A 1\u201399 \u7684\u6574\u6570','err');return;}
        var patch=preferredPayload(list.value);patch.optimizer={subMode:mode.value,subIncludeDefault:!!mode.value&&defaults.value==='1',subRandomCount:count||16};
        if(b.lines.length&&!patch.preferredIPs.length&&!patch.preferredDomains&&!confirm('\u6B64\u64CD\u4F5C\u4F1A\u6E05\u7A7A\u540E\u7AEF'+(b.index+1)+'\u7684\u4F18\u9009\u5217\u8868\uFF0C\u662F\u5426\u7EE7\u7EED\uFF1F'))return;
        c.saving=true;save.disabled=true;mode.disabled=true;defaults.disabled=true;list.disabled=true;random.disabled=true;message.textContent='\u6B63\u5728\u4FDD\u5B58\u2026';
        api('config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(patch)},b.url).then(function(r){
          if(!r||!r.ok)throw new Error(r&&r.msg||'\u4FDD\u5B58\u5931\u8D25');
          c.dirty=false;b.lines=list.value.split(/\\n+/).filter(function(s){return s.trim();});b.subMode=mode.value;b.includeDefault=patch.optimizer.subIncludeDefault;
          title.textContent='\u540E\u7AEF'+(b.index+1)+' \xB7 '+b.lines.length+' \u6761\u914D\u7F6E\u5730\u5740';
          if(CFG&&b.url===window.CFN_CONFIG_BACKEND){CFG.preferredDomains=patch.preferredDomains;CFG.preferredIPs=patch.preferredIPs;Object.assign(CFG.optimizer||(CFG.optimizer={}),patch.optimizer);onSubMode();}
          message.textContent='\u5DF2\u4FDD\u5B58\uFF1A'+new Date().toLocaleTimeString();toast('\u540E\u7AEF'+(b.index+1)+'\u4F18\u9009\u914D\u7F6E\u5DF2\u4FDD\u5B58','ok');makeSub(false);
          var total=preferredCards.reduce(function(n,x){return n+x.backend.lines.length;},0);summary.textContent='\u5DF2\u8BFB\u53D6 '+success.length+'/'+rBackendCount+' \u4E2A\u540E\u7AEF\uFF0C\u5171 '+total+' \u6761\u914D\u7F6E\u5730\u5740\uFF1B\u5404\u540E\u7AEF\u72EC\u7ACB\u4FDD\u5B58\uFF0C\u4EE5\u8BA2\u9605\u9884\u89C8\u4E3A\u51C6\u3002';
        }).catch(function(e){message.textContent='\u4FDD\u5B58\u5931\u8D25\uFF1A'+e.message+'\uFF1B\u4FEE\u6539\u5DF2\u4FDD\u7559\uFF0C\u53EF\u91CD\u8BD5\u3002';toast(message.textContent,'err');}).then(function(){c.saving=false;save.disabled=false;mode.disabled=false;list.disabled=false;random.disabled=false;visibility();});
      };
      wrap.appendChild(card);
    });
    var rBackendCount=r.backends.length;
    target.value=preferredCards.some(function(c){return c.backend.url===previous;})?previous:(preferredCards.some(function(c){return c.backend.url===window.CFN_CONFIG_BACKEND;})?window.CFN_CONFIG_BACKEND:(preferredCards[0]?preferredCards[0].backend.url:''));
  }).catch(function(e){summary.textContent='\u5404\u540E\u7AEF\u914D\u7F6E\u8BFB\u53D6\u5931\u8D25\uFF1A'+e.message+'\u3002\u73B0\u6709\u4FEE\u6539\u5DF2\u4FDD\u7559\u3002';});
}
function loadAll(){
  updateFreeDomainWarn();
  loadPreferredOverview();
  api('status').then(function(r){
    if (r && r.ok) renderStatus(r.data);
  }).catch(function(){});
  api('config').then(function(r){
    if (r && r.ok){
      CFG = r.data;
      fillForm();
      renderAll();
      applyMode();
      if (curMode()==='worker' && (location.hash==='#optimizer' || new URLSearchParams(location.search).get('v')==='optimizer')) switchView('optimizer');
      if (!CFG.mode) showMode();
      makeSub(false);
      setConn(true);
      refreshQuota();
      toast('\u914D\u7F6E\u5DF2\u52A0\u8F7D', 'ok');
    } else if (r && r.status === 403) {
      location.reload();
    } else {
      setConn(false);
      toast('\u65E0\u6CD5\u8FDE\u63A5\u670D\u52A1\u5668', 'err');
    }
  }).catch(function(){
    setConn(false);
    toast('\u65E0\u6CD5\u8FDE\u63A5\u670D\u52A1\u5668', 'err');
  });
}
function setConn(ok){
  var p = $('connPill');
  p.className = 'pill ' + (ok ? '' : 'off');
  $('connText').textContent = ok ? '\u8FD0\u884C\u4E2D' : '\u65E0\u6CD5\u8FDE\u63A5';
}
// \u514D\u8D39\u57DF\u540D\uFF08*.workers.dev / *.pages.dev\uFF09\u5927\u9646\u76F4\u8FDE\u88AB\u963B\u65AD\uFF1A\u547D\u4E2D\u5373\u63D0\u793A\u7ED1\u5B9A\u81EA\u5B9A\u4E49\u57DF\u540D
function isFreeSubDomain(h){
  return /\\.(workers\\.dev|pages\\.dev)$/i.test(String(h || ''));
}
function updateFreeDomainWarn(){
  var effHost = (CFG && CFG.host) ? String(CFG.host) : location.hostname;
  var wd = isFreeSubDomain(location.hostname) || isFreeSubDomain(effHost);
  // Pages \u90E8\u7F72\uFF08*.pages.dev\uFF09\u4E0D\u5C55\u793A\u90A3\u6761 *.workers.dev \u6A2A\u5E45\uFF1A\u57DF\u540D\u4E0E\u6587\u6848\u4E0D\u7B26
  var isPages = /\\.pages\\.dev$/i.test(String(location.hostname || ''));
  $('wdwarn').style.display = wd && !isPages ? 'block' : 'none';
  $('subHint').textContent = wd
    ? '\u8282\u70B9 SNI / \u8BA2\u9605\u57DF\u540D\u4F7F\u7528 *.pages.dev \u6216 *.workers.dev \u514D\u8D39\u57DF\u540D\uFF1A\u5927\u9646\u76F4\u8FDE\u4F1A\u88AB\u963B\u65AD\u2014\u2014\u8BA2\u9605\u5BFC\u5165\u4E0E\u66F4\u65B0\u9700\u6302\u68AF\u5B50\uFF0C\u8282\u70B9\u6D4B\u5EF6\u8FDF\u4E0E\u8FDE\u63A5\u53EF\u80FD\u5168\u90E8\u5931\u8D25\u3002\u89E3\u51B3\uFF1A\u5728 Cloudflare \u63A7\u5236\u53F0\u4E3A\u672C\u9879\u76EE\u7ED1\u5B9A\u81EA\u5B9A\u4E49\u57DF\u540D\uFF0C\u518D\u7528\u81EA\u5B9A\u4E49\u57DF\u540D\u6253\u5F00\u9762\u677F\u91CD\u65B0\u590D\u5236\u8BA2\u9605\u94FE\u63A5\u3002'
    : '';
}
function renderStatus(d){
  $('stEntry').textContent = location.origin + '/' + (d.path || d.uuid || '');
  updateFreeDomainWarn();
  var kv = d.kv;
  var kvTxt = kv ? '\u5DF2\u7ED1\u5B9A\uFF08\u914D\u7F6E\u6301\u4E45\u5316\uFF09' : '\u672A\u7ED1\u5B9A\uFF08\u914D\u7F6E\u4EC5\u5185\u5B58\uFF09';
  $('stKv').textContent = kvTxt;
  $('stKv').className = 'v ' + (kv ? 'ok' : 'bad');
  $('aKv').textContent = kvTxt;
  $('aKv').className = 'v ' + (kv ? 'ok' : 'bad');
  var v = d.version || '\u2014';
  var kindName = '\u524D\u540E\u7AEF\u5206\u79BB\u7248';   // \u5206\u79BB\u7248\u56FA\u5B9A\u5F62\u6001\uFF0C\u4E0D\u968F\u540E\u7AEF\u6784\u5EFA\u5F62\u6001\u53D8\u5316
  $('sideVer').textContent = 'v' + v + kindName;
  topVerText = 'v' + v + kindName;
  $('aVer').textContent = v + kindName;
}
function protoText(){
  if (!CFG) return '\u2014';
  var a = [];
  if (CFG.enableVless !== false) a.push('VLESS');
  if (CFG.enableTrojan) a.push('Trojan');
  if (CFG.enableXhttp) a.push('XHTTP');
  return a.length ? a.join(' / ') : '\u672A\u542F\u7528';
}
function renderAll(){
  $('stProto').textContent = protoText();
  renderQuota();
}
function renderQuota(){
  var nl = !!(CFG && CFG.nodeLimit);
  $('qNl').textContent = nl ? '\u5DF2\u5F00\u542F' : '\u5173\u95ED\uFF08\u9ED8\u8BA4\u5206\u6863\u4E0A\u9650\uFF09';
  $('qNl').className = 'v ' + (nl ? 'ok' : '');
  $('qNlCount').textContent = nl ? (CFG.nodeLimitCount || 300) + ' \u8282\u70B9' : '\u2014';
  var pc = !!(CFG && CFG.cpuLimit);
  $('qCpuLimit').textContent = pc ? '\u5DF2\u5F00\u542F\uFF08\u964D\u8F7D\u4E0B\u53D1\uFF0C\u6309\u4E0A\u9650 60% \u4E0B\u53D1\uFF09' : '\u5173\u95ED\uFF08\u6309\u8BBE\u5B9A\u6570\u91CF\u5B8C\u6574\u4E0B\u53D1\uFF09';
  $('qCpuLimit').className = 'v ' + (pc ? 'ok' : '');
  var lb = !(CFG && CFG.loadBalance === false);
  $('qLb').textContent = lb ? '\u5DF2\u5F00\u542F\uFF08\u968F\u673A\u8F6E\u6362\uFF09' : '\u5173\u95ED\uFF08\u56FA\u5B9A\u987A\u5E8F\uFF09';
  $('qLb').className = 'v ' + (lb ? 'ok' : 'ok');
  // IPv6 \u4E0B\u53D1\u7B56\u7565\uFF1A'full'\uFF08\u65E7\u884C\u4E3A\uFF09\u6807\u9EC4\u63D0\u9192\u2014\u2014v6 \u5907\u80CE\u4F1A\u62D6\u6162\u5BA2\u6237\u7AEF\u9010\u8282\u70B9\u6D4B\u5EF6\u8FDF
  var i6 = (CFG && CFG.ipv6Mode) || 'off';
  $('qIp6').textContent = i6 === 'full' ? '\u7B49\u6743\u6DF7\u5408\uFF08\u65E7\u884C\u4E3A\uFF09' : (i6 === 'tail' ? '\u4EC5\u5907\u80CE\uFF08\u226410%\uFF0C\u6392\u5C3E\u90E8\uFF09' : '\u4E0D\u4E0B\u53D1');
  $('qIp6').className = 'v ' + (i6 === 'full' ? 'warn' : 'ok');
}
function fmtNum(n){
  if (n == null || isNaN(n)) return '\u2014';
  n = Number(n);
  if (n >= 1e6) return (n / 1e6).toFixed(2) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
  return String(n);
}
function showQuotaState(kind, text){
  $('qQuotaWrap').style.display = (kind === 'data') ? '' : 'none';
  $('qQuotaEmpty').style.display = (kind === 'empty') ? '' : 'none';
  $('qQuotaErr').style.display = (kind === 'err') ? '' : 'none';
  if (kind === 'err') $('qQuotaErrText').textContent = quotaErrText(text);
  if (kind === 'data'){ $('qQuotaEmpty').style.display = 'none'; }
}
function quotaErrText(e){
  var m = String(e || '');
  if (m.indexOf('401') >= 0) return '\u8BA4\u8BC1\u5931\u8D25\uFF08CF API 401\uFF09\uFF1A\u8BF7\u68C0\u67E5\u8D26\u6237 ID \u662F\u5426\u4E3A 32 \u4F4D\u5341\u516D\u8FDB\u5236\u3001API \u4EE4\u724C\u662F\u5426\u6709\u6548\u4E14\u52FE\u9009 Account Analytics \u8BFB\u53D6\u6743\u9650';
  if (m.indexOf('403') >= 0) return '\u65E0\u6743\u9650\uFF08CF API 403\uFF09\uFF1AAPI \u4EE4\u724C\u7F3A\u5C11\u8D26\u6237 Analytics \u8BFB\u53D6\u6743\u9650';
  if (m.indexOf('429') >= 0) return 'CF API \u9650\u6D41\uFF08429\uFF09\uFF1A\u5DF2\u81EA\u52A8\u9000\u907F 15 \u5206\u949F\uFF0C\u671F\u95F4\u6CBF\u7528\u7F13\u5B58\u6570\u636E';
  if (m.indexOf('\u672A\u627E\u5230\u8D26\u6237') >= 0) return m + '\uFF1A\u8BF7\u6838\u5BF9 dash.cloudflare.com \u53F3\u4FA7\u680F\u7684 32 \u4F4D\u8D26\u6237 ID';
  return m || '\u7528\u91CF\u67E5\u8BE2\u5931\u8D25';
}
function renderQuotaData(d){
  updDbQuota(d);
  if (!d || !d.configured){
    $('qQuotaSub').textContent = '\u672A\u914D\u7F6E';
    showQuotaState('empty');
    return;
  }
  if (d.error && !d.stale){
    $('qQuotaSub').textContent = '\u67E5\u8BE2\u5931\u8D25';
    showQuotaState('err', d.error);
    return;
  }
  $('qQuotaSub').textContent = d.stale ? '\u7F13\u5B58\u6570\u636E' : '\u5DF2\u8FDE\u63A5';
  showQuotaState('data');
  $('qReq').textContent = fmtNum(d.today.requests) + ' / ' + fmtNum(d.limit);
  var p = d.percent || 0;
  $('qBar').style.width = Math.min(100, p) + '%';
  $('qBar').style.background = p >= 90 ? 'linear-gradient(90deg,var(--err),var(--warn))' : (p >= 60 ? 'linear-gradient(90deg,var(--warn),var(--accent))' : 'linear-gradient(90deg,var(--ok),var(--accent))');
  $('qPct').textContent = p + '%';
  $('qPct').className = 'v ' + (p >= 90 ? 'bad' : (p >= 60 ? '' : 'ok'));
  $('qRemain').textContent = fmtNum(d.remaining != null ? d.remaining : (d.limit - d.today.requests));
  $('qCpu').textContent = (d.today.cpuTime != null) ? (d.today.cpuTime / 1000).toFixed(2) + ' s' : '\u2014';
  $('qSub').textContent = fmtNum(d.today.subrequests);
  $('qAt').textContent = (d.updatedAt ? String(d.updatedAt).replace('T', ' ').replace('Z', '') + ' UTC' : '\u2014') + (d.stale ? '\uFF08\u9650\u6D41\u7F13\u5B58\uFF09' : '');
}
function updDbQuota(d){
  if (!d || !d.configured){ $('dbSub').textContent = '\u672A\u914D\u7F6E\u76D1\u63A7'; $('dbWrap').style.display = 'none'; return; }
  if (d.error && !d.stale){ $('dbSub').textContent = '\u67E5\u8BE2\u5931\u8D25'; $('dbWrap').style.display = 'none'; return; }
  $('dbSub').textContent = d.stale ? '\u7F13\u5B58\u6570\u636E' : '\u5DF2\u8FDE\u63A5';
  $('dbWrap').style.display = '';
  $('dbReq').textContent = fmtNum(d.today.requests) + ' / ' + fmtNum(d.limit);
  var p = d.percent || 0;
  $('dbBar').style.width = Math.min(100, p) + '%';
  $('dbBar').style.background = p >= 90 ? 'linear-gradient(90deg,var(--err),var(--warn))' : (p >= 60 ? 'linear-gradient(90deg,var(--warn),var(--accent))' : 'linear-gradient(90deg,var(--ok),var(--accent))');
  $('dbPct').textContent = p + '%';
  $('dbPct').className = 'v ' + (p >= 90 ? 'bad' : (p >= 60 ? '' : 'ok'));
}
function refreshQuota(){
  $('qQuotaSub').textContent = '\u67E5\u8BE2\u4E2D\u2026';
  api('quota').then(function(r){
    if (r && r.ok) renderQuotaData(r.data);
    else { $('qQuotaSub').textContent = '\u67E5\u8BE2\u5931\u8D25'; showQuotaState('err', (r && r.msg) || '\u67E5\u8BE2\u5931\u8D25'); }
  }).catch(function(){ $('qQuotaSub').textContent = '\u67E5\u8BE2\u5931\u8D25'; showQuotaState('err', '\u65E0\u6CD5\u8FDE\u63A5\u670D\u52A1\u5668'); });
}
function parseIps(t){
  var out = [];
  String(t || '').split(/[\\n,;]+/).map(function(s){ return s.trim(); }).filter(Boolean).forEach(function(s){
    var name = '';
    if (s.indexOf('#') >= 0){ var a = s.split('#'); s = a[0]; name = a[1]; }
    var m;
    if ((m = s.match(/^\\[([0-9a-fA-F:]+)\\](?::(\\d+))?$/))){ out.push({ ip: m[1], port: parseInt(m[2]) || 443, name: name }); return; }
    if ((m = s.match(/^(\\d+\\.\\d+\\.\\d+\\.\\d+)(?::(\\d+))?$/))){ out.push({ ip: m[1], port: parseInt(m[2]) || 443, name: name }); }
  });
  return out;
}
function fillPort(pv){
  pv = String(pv == null ? 443 : pv);
  var sel = $('o-port');
  var found = false;
  for (var i = 0; i < sel.options.length; i++){ if (sel.options[i].value === pv){ found = true; break; } }
  if (found){ sel.value = pv; $('o-portC').style.display = 'none'; }
  else { sel.value = 'custom'; $('o-portC').value = pv; $('o-portC').style.display = ''; }
}
function fillForm(){
  if (!CFG) return;
  if ($('a-front')) $('a-front').value = CFG.warpFront || '';
  $('en-vless').checked = CFG.enableVless !== false;
  $('en-trojan').checked = !!CFG.enableTrojan;
  $('tp-pass').value = CFG.trojanPassword || '';
  $('en-xhttp').checked = !!CFG.enableXhttp;
  $('tls-only').checked = !!CFG.tlsOnly;
  $('alpn').value = CFG.alpn || '';
  $('ech-on').checked = !!CFG.ech;
  $('ech-host').value = CFG.echHost || '';
  $('ech-dns').value = CFG.echDns || '';
  var fl = CFG.filter || {};
  var region = fl.region || 'all';
  var regionArr = Array.isArray(region) ? region : (region === 'all' ? ['all'] : [region]);
  $('fl-region-all').checked = regionArr.indexOf('all') >= 0;
  ['HK', 'TW', 'US', 'SG', 'JP', 'KR', 'DE'].forEach(function(r){ $('fl-region-' + r).checked = regionArr.indexOf(r) >= 0; });
  var ipType = fl.ipType || ['IPv4'];
  $('fl-ip4').checked = ipType.indexOf('IPv4') >= 0;
  $('fl-ip6').checked = ipType.indexOf('IPv6') >= 0;
  var ip6 = CFG.ipv6Mode || 'off';
  $('ip6-off').checked = ip6 !== 'tail' && ip6 !== 'full';
  $('ip6-tail').checked = ip6 === 'tail';
  $('ip6-full').checked = ip6 === 'full';
  var isp = fl.isp || ['\u79FB\u52A8', '\u8054\u901A', '\u7535\u4FE1'];
  $('fl-isp-m').checked = isp.indexOf('\u79FB\u52A8') >= 0;
  $('fl-isp-c').checked = isp.indexOf('\u8054\u901A') >= 0;
  $('fl-isp-t').checked = isp.indexOf('\u7535\u4FE1') >= 0;
  var src = CFG.src || {};
  $('fl-native').checked = src.native === true;
  $('fl-pref-domain').checked = src.prefDomain !== false;
  $('fl-pref-ip').checked = src.prefIp !== false;
  $('fl-custom-pref').checked = src.customPref === true;
  var o = CFG.optimizer || {};
  $('o-source').value = o.source || 'wetest_v4';
  $('o-sourceURL').value = o.sourceURL || '';
  $('o-fbpool').value = o.fallbackPool || '';
  fillPort(o.port);
  $('o-threads').value = o.threads || 5;
  $('o-count').value = o.count || 20;
  $('o-fill').value = (o.fillCount == null ? 0 : o.fillCount);
  $('o-useCidr').checked = o.useCidr !== false;
  $('q-nl-on').checked = !!CFG.nodeLimit;
  $('q-nl-count').value = CFG.nodeLimitCount || 300;
  $('q-cpu-on').checked = !!CFG.cpuLimit;
  $('q-clabel').value = CFG.countryLabel || '';
  $('q-lb-on').checked = CFG.loadBalance !== false;  $('q-auto-on').checked = !!CFG.quotaAuto;
  $('q-strict-on').checked = !!CFG.quotaStrict;
  $('a-uuid').value = CFG.uuid || '';
  $('a-suburl').value = CFG.subUrl || '';
  $('a-admin').value = CFG.admin || '';
  $('q-tgtoken').value = CFG.tgBotToken || '';
  $('q-tgchat').value = CFG.tgChatID || '';
  $('hw-on').checked = !!CFG.homeWan;
  $('hw-cfg').value = CFG.hwCfg || '';
  $('s-proxyIP').value = CFG.proxyIP || '';
  $('s-outbound').value = CFG.outboundProxy || '';
  $('s-outmode').value = CFG.outboundMode || '';
  $('a-mode').value = curMode();
  $('w-on').checked = !!CFG.warpEnable;
  setWStat();
  $('w-eps').value = CFG.warpEps || '';
  $('w-name').value = CFG.warpName || 'WARP';
  $('x-on').checked = !!CFG.masqueEnable;
  $('x-conf').value = CFG.masqueConf || '';
  $('x-name').value = CFG.masqueName || 'MASQUE';
  $('x-eps').value = CFG.masqueEps || '';
  bindRegionPills();
  onSubMode();
  $('o-customWrap').style.display = ($('o-source').value === 'custom') ? '' : 'none';
}
// \u8282\u70B9\u5730\u533A\u591A\u9009\u4E92\u65A5\uFF1A\u52FE\u9009\u5177\u4F53\u5730\u533A\u65F6\u53D6\u6D88\u300C\u5168\u90E8\u5730\u533A\u300D\uFF1B\u5168\u90E8\u53D6\u6D88\u65F6\u81EA\u52A8\u6062\u590D\u300C\u5168\u90E8\u5730\u533A\u300D\uFF08\u4FDD\u8BC1\u7B5B\u9009\u975E\u7A7A\uFF09
function bindRegionPills(){
  if (window.__regionPillsBound) return;
  window.__regionPillsBound = true;
  var codes = ['HK', 'TW', 'US', 'SG', 'JP', 'KR', 'DE'];
  var all = $('fl-region-all');
  all.addEventListener('change', function(){
    if (all.checked) codes.forEach(function(r){ $('fl-region-' + r).checked = false; });
  });
  codes.forEach(function(c){
    $('fl-region-' + c).addEventListener('change', function(){
      if ($('fl-region-' + c).checked) all.checked = false;
      var any = codes.some(function(r){ return $('fl-region-' + r).checked; });
      if (!any) all.checked = true;
    });
  });
}
function collectForm(){
  if (!CFG) return null;
  return {
    mode: $('a-mode').value || '',
    warpFront: (($('a-front') || {}).value || '').trim(),
    warpEnable: $('w-on').checked,
    warpConf: CFG.warpConf || '',
    warpEps: $('w-eps').value,
    warpName: $('w-name').value.trim() || 'WARP',
    masqueEnable: $('x-on').checked,
    masqueConf: $('x-conf').value,
    masqueName: $('x-name').value.trim() || 'MASQUE',
    masqueEps: $('x-eps').value,
    uuid: $('a-uuid').value.trim(),
    subUrl: $('a-suburl').value.trim(),
    admin: $('a-admin').value,
    alpn: $('alpn').value,
    ech: $('ech-on').checked,
    echHost: $('ech-host').value.trim() || 'cloudflare-ech.com',
    echDns: $('ech-dns').value.trim(),
    tlsOnly: $('tls-only').checked,
    nodeLimit: $('q-nl-on').checked,
    nodeLimitCount: parseInt($('q-nl-count').value) || 300,
    cpuLimit: $('q-cpu-on').checked,
    countryLabel: $('q-clabel').value,
    loadBalance: $('q-lb-on').checked,
    ipv6Mode: $('ip6-tail').checked ? 'tail' : ($('ip6-full').checked ? 'full' : 'off'),
    tgBotToken: $('q-tgtoken').value.trim(),
    tgChatID: $('q-tgchat').value.trim(),
    quotaAuto: $('q-auto-on').checked,
    quotaStrict: $('q-strict-on').checked,
    enableVless: $('en-vless').checked,
    enableTrojan: $('en-trojan').checked,
    trojanPassword: $('tp-pass').value,
    enableXhttp: $('en-xhttp').checked,
    homeWan: $('hw-on').checked,
    hwCfg: $('hw-cfg').value,
    proxyIP: $('s-proxyIP').value.trim(),
    outboundProxy: $('s-outbound').value.trim(),
    outboundMode: $('s-outmode').value,
    optimizer: {
      source: $('o-source').value,
      sourceURL: $('o-sourceURL').value.trim(),
      fallbackPool: $('o-fbpool').value.trim(),
      port: parseInt($('o-port').value === 'custom' ? $('o-portC').value : $('o-port').value) || 443,
      threads: parseInt($('o-threads').value) || 5,
      count: parseInt($('o-count').value) || 20,
      fillCount: parseInt($('o-fill').value) || 0,
      useCidr: $('o-useCidr').checked,
      subMode: $('fl-custom-pref').checked ? 'custom' : ($('fl-random-pref').checked ? 'random' : ''),
      subRandomCount: (CFG.optimizer||{}).subRandomCount || 16,
      subIncludeDefault: !!(CFG.optimizer||{}).subIncludeDefault
    },
    filter: {
      region: (function(){
        if ($('fl-region-all').checked) return ['all'];
        var a = [];
        ['HK', 'TW', 'US', 'SG', 'JP', 'KR', 'DE'].forEach(function(r){ if ($('fl-region-' + r).checked) a.push(r); });
        return a.length ? a : ['all'];
      })(),
      ipType: (function(){ var a = []; if ($('fl-ip4').checked) a.push('IPv4'); if ($('fl-ip6').checked) a.push('IPv6'); return a; })(),
      isp: (function(){ var a = []; if ($('fl-isp-m').checked) a.push('\u79FB\u52A8'); if ($('fl-isp-c').checked) a.push('\u8054\u901A'); if ($('fl-isp-t').checked) a.push('\u7535\u4FE1'); return a; })()
    },
    src: {
      native: $('fl-native').checked,
      prefDomain: $('fl-pref-domain').checked,
      prefIp: $('fl-pref-ip').checked,
      customPref: $('fl-custom-pref').checked
    }
  };
}
function saveAll(){
  if(hasPreferredDrafts()){toast('\u8BF7\u5148\u7528\u5404\u540E\u7AEF\u5361\u7247\u5185\u7684\u6309\u94AE\u4FDD\u5B58\u4F18\u9009\u4FEE\u6539','warn');return;}
  if (!CFG){ toast('\u914D\u7F6E\u5C1A\u672A\u52A0\u8F7D', 'err'); return; }
  var body = collectForm();
  var btn = $('saveBtn');
  btn.disabled = true;
  api('config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    .then(function(r){
      if (r && r.ok){
        CFG = r.data;
        // v4 \u524D\u540E\u7AEF\u5206\u79BB\uFF1A\u524D\u7AEF\u5165\u53E3\u7531\u73AF\u5883\u53D8\u91CF L \u51B3\u5B9A\uFF0C\u4E0E\u540E\u7AEF uuid / path \u65E0\u5173\u3002
        // \u65E7\u5355\u6587\u4EF6\u7248\u6B64\u5904\u4F1A\u8DF3\u5230 /<uuid>\uFF08\u56E0\u4E3A\u90A3\u65F6"UUID \u5373\u5165\u53E3"\uFF09\uFF0C\u5728 v4 \u4E0B\u4F1A\u843D\u5230\u540E\u7AEF\u6B22\u8FCE\u9875\uFF0C\u6545\u53D6\u6D88\u8DF3\u8F6C\u3002
        fillForm();
        renderAll();
        makeSub(false);
        refreshQuota();
        btn.classList.remove('dirty');
        $('savedAt').textContent = '\u5DF2\u4FDD\u5B58\uFF1A' + new Date().toLocaleTimeString();
        toast('\u5DF2\u4FDD\u5B58\u5E76\u751F\u6548\uFF0C\u6B63\u5728\u5237\u65B0\u2026', 'ok');
        setTimeout(function(){ location.reload(); }, 800);
      } else toast((r && r.msg) || '\u4FDD\u5B58\u5931\u8D25', 'err');
    })
    .catch(function(){ toast('\u4FDD\u5B58\u5931\u8D25\uFF1A\u65E0\u6CD5\u8FDE\u63A5\u670D\u52A1\u5668', 'err'); })
    .then(function(){ btn.disabled = false; });
}
function hwCustomApply(){
  var el = $('hw-cfg'), st = $('hw-cfg-stat');
  if (!el || !st) return;
  var hosts = [], hasCrypto = false;
  String(el.value || '').split(/\\n+/).forEach(function(line){
    var s = String(line || '').trim();
    if (!s || s.charAt(0) === '#') return;
    if (/^(ca|cert|key|tls-auth|tls-crypt)\\s*[:=]/i.test(s)) { hasCrypto = true; return; }
    if (/^-{3,}/.test(s) || /^[A-Za-z0-9+/=\\s]{16,}$/.test(s)) return;
    var m = /^([A-Za-z]{2})\\s*[:|]\\s*([\\s\\S]+)$/.exec(s);
    var body = s, code = '';
    if (m) { code = m[1].toUpperCase(); body = m[2].trim(); }
    var b64 = body.replace(/\\s+/g, '');
    if (b64.length >= 200 && /^[A-Za-z0-9+/=]+$/.test(b64)) { hosts.push('\u914D\u7F6E(' + (code || 'XX') + ')'); return; }
    var p = body.split(/[\\s:]+/).filter(Boolean);
    if (p.length) hosts.push(p[0] + ':' + (parseInt(p[1], 10) || 1194) + '/' + (/udp/i.test(p[2] || '') ? 'udp' : 'tcp'));
  });
  st.textContent = hosts.length
    ? ('\u89E3\u6790\u5230 ' + hosts.length + ' \u6761\uFF1A' + hosts.slice(0, 4).join('\u3001') + (hosts.length > 4 ? ' \u2026' : '') + (hasCrypto ? '\uFF08\u542B\u8BC1\u4E66\u5757\uFF09' : '\uFF08\u65E0\u8BC1\u4E66\u5757\u7684\u884C\u4F1A\u88AB\u5FFD\u7565\uFF09'))
    : '\u672A\u89E3\u6790\u5230\u6709\u6548\u6761\u76EE';
  toast(hosts.length ? ('\u89E3\u6790\u5230 ' + hosts.length + ' \u6761') : '\u6CA1\u6709\u89E3\u6790\u5230\u6761\u76EE', hosts.length ? 'ok' : 'err');
}
function resetAll(){
  if (!confirm('\u786E\u5B9A\u91CD\u7F6E\uFF1F\u5C06\u6E05\u7A7A\u540E\u7AEF\u9762\u677F\u914D\u7F6E\u4E0E\u8282\u70B9\u8BB0\u5F55\uFF0C\u5E76\u6E05\u9664\u524D\u7AEF\u767B\u5F55\u5BC6\u7801\u3001\u9000\u51FA\u767B\u5F55\uFF08\u56DE\u5230\u300C\u8BBE\u7F6E\u7BA1\u7406\u5BC6\u7801\u300D\u9875\uFF09\u3002\u6B64\u64CD\u4F5C\u4E0D\u53EF\u6062\u590D\uFF01')) return;
  var btn = $('resetBtn');
  btn.disabled = true;
  api('reset', { method: 'POST' })
    .then(function(r){
      if (r && r.ok){ toast(r.msg || '\u5DF2\u91CD\u7F6E', 'ok'); setTimeout(function(){ location.href = APIPATH; }, 900); }
      else toast((r && r.msg) || '\u91CD\u7F6E\u5931\u8D25', 'err');
    })
    .catch(function(){ toast('\u91CD\u7F6E\u5931\u8D25\uFF1A\u65E0\u6CD5\u8FDE\u63A5\u670D\u52A1\u5668', 'err'); })
    .then(function(){ btn.disabled = false; });
}
function genUuid(){
  var u = '';
  if (window.crypto && crypto.randomUUID){ u = crypto.randomUUID(); }
  else {
    var tpl = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx';
    u = tpl.replace(/[xy]/g, function(c){
      var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 3 | 8);
      return v.toString(16);
    });
  }
  $('a-uuid').value = u;
  markDirty();
  toast('\u5DF2\u751F\u6210\u65B0 UUID', 'ok');
}
// \u5907\u4EFD\uFF1A\u628A\u5F53\u524D\u9762\u677F\u8868\u5355\u503C\u6536\u96C6\u6210 JSON \u4E0B\u8F7D\uFF08\u4E0E\u4FDD\u5B58\u914D\u7F6E\u540C\u4E00\u5957\u5B57\u6BB5\uFF0C\u6062\u590D\u540E\u53EF\u76F4\u63A5\u4FDD\u5B58\uFF09
function exportConfig(){
  try {
    var data = collectForm();
    var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    var ts = new Date();
    var pad = function(n){ return String(n).padStart(2, '0'); };
    a.download = 'cfnext-backup-' + ts.getFullYear() + pad(ts.getMonth()+1) + pad(ts.getDate()) + '-' + pad(ts.getHours()) + pad(ts.getMinutes()) + '.json';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function(){ URL.revokeObjectURL(a.href); }, 1000);
    toast('\u914D\u7F6E\u5DF2\u5BFC\u51FA\u4E3A JSON', 'ok');
  } catch (e) { toast('\u5BFC\u51FA\u5931\u8D25\uFF1A' + e.message, 'err'); }
}
// \u6062\u590D\uFF1A\u8BFB\u53D6 JSON \u586B\u5145\u8868\u5355\uFF0C\u6807\u8BB0\u672A\u4FDD\u5B58\uFF0C\u7531\u7528\u6237\u70B9\u300C\u4FDD\u5B58\u5168\u90E8\u300D\u5199\u76D8
function importConfig(input){
  var file = input.files && input.files[0];
  if (!file) return;
  var reader = new FileReader();
  reader.onload = function(){
    try {
      var data = JSON.parse(reader.result);
      CFG = Object.assign({}, CFG, data);
      fillForm();
      renderAll();
      markDirty();
      toast('\u914D\u7F6E\u5DF2\u5BFC\u5165\uFF0C\u8BF7\u70B9\u300C\u4FDD\u5B58\u5168\u90E8\u300D\u751F\u6548', 'ok');
    } catch (e) { toast('\u5BFC\u5165\u5931\u8D25\uFF1AJSON \u683C\u5F0F\u4E0D\u6B63\u786E', 'err'); }
    input.value = '';
  };
  reader.readAsText(file, 'utf-8');
}
document.querySelectorAll('input,select,textarea').forEach(function(el){
  var id = el.id || '';
  var prefixes = ['f-', 'o-', 'a-', 's-', 'q-', 'e-', 't-', 'fl-', 'en-'];
  for (var i = 0; i < prefixes.length; i++){ if (id.indexOf(prefixes[i]) === 0){ el.addEventListener('change', markDirty); break; } }
});

/* ===== \u8BA2\u9605 ===== */
function subUrlOf(fmt){
  // \u81EA\u5B9A\u4E49\u8BA2\u9605\u8DEF\u5F84\u4F18\u5148\uFF1A\u81EA\u52A8\u4FDD\u7559\u5F53\u524D\u57DF\u540D\uFF08location.origin\uFF09\uFF0C\u53EA\u66FF\u6362\u8DEF\u5F84\u6BB5\uFF1B
  // \u7528\u6237\u53EA\u586B UUID/\u522B\u540D\u6BB5\uFF08\u5982 AAZ\uFF09\uFF0C\u62FC\u6210 https://\u5F53\u524D\u57DF\u540D/AAZ/sub\uFF1B\u7559\u7A7A\u7528 UUID\u3002
  // \u586B\u4E86 /sub \u7ED3\u5C3E\u6216\u5E26\u524D\u540E\u659C\u6760\u65F6\u81EA\u52A8\u5F52\u4E00\uFF0C\u683C\u5F0F\u540E\u7F00\uFF08clash/singbox \u7B49\uFF09\u62FC\u4E3A /sub/<\u683C\u5F0F>
  var custom = (window.CFG && CFG.subUrl) ? String(CFG.subUrl).trim().replace(/^\\/+/, '').replace(/\\/sub$/, '').replace(/\\/+$/, '') : '';
  var base = custom ? (location.origin + '/' + custom) : (location.origin + APIPATH);
  var u = base + '/sub';
  return fmt ? (u + '/' + fmt) : u;
}
function makeSub(showQR){
  var fmt = $('subFmt').value;
  var url = subUrlOf(fmt === 'auto' ? '' : fmt);
  $('subUrl').value = url;
  if (showQR) showQRCode(url);
}
$('subFmt').addEventListener('change', function(){ makeSub(false); });
function toggleQR(){
  var w = $('qrWrap');
  if (w.style.display === 'block'){ w.style.display = 'none'; return; }
  showQRCode($('subUrl').value || subUrlOf(''));
}
function showQRCode(url){
  var w = $('qrWrap');
  w.style.display = 'block';
  if (typeof qrcode === 'undefined'){ w.innerHTML = '<div class="hint">\u4E8C\u7EF4\u7801\u5E93\u52A0\u8F7D\u5931\u8D25\uFF0C\u8BF7\u76F4\u63A5\u590D\u5236\u94FE\u63A5</div>'; return; }
  try {
    var fmt = ($('subFmt') && $('subFmt').value) || 'auto';
    var q = qrcode(0, 'M');
    q.addData(qrPayloadOf(fmt, url));
    q.make();
    w.innerHTML = '<div class="qrbox">' + q.createImgTag(4, 10) + '</div>';
  } catch(e) { w.innerHTML = '<div class="hint">\u4E8C\u7EF4\u7801\u751F\u6210\u5931\u8D25\uFF1A' + e.message + '</div>'; }
}
// \u4E8C\u7EF4\u7801\u5185\u5BB9\u968F\u8BA2\u9605\u683C\u5F0F\uFF08\u5BA2\u6237\u7AEF\uFF09\u8054\u52A8\uFF1A
// Clash/Mihomo\u3001Stash \u2192 clash://install-config\uFF08FlyClash / Clash Verge / Stash \u626B\u7801\u88C5\u8BA2\u9605\uFF0C\u914D\u7F6E\u540D\u53D6\u8BA2\u9605\u54CD\u5E94\u5934 filename=CFNext\uFF09
// Sing-box \u2192 sing-box://import-remote-profile?url=...#CFNext\uFF08\u5B98\u65B9 scheme\uFF0C# \u540E\u4E3A\u914D\u7F6E\u6587\u4EF6\u540D\u79F0\uFF09
// Surge \u2192 surge:///install-config\uFF08Surge \u5B98\u65B9 scheme\uFF09
// auto / v2rayN+Shadowrocket / Loon / Quantumult X / \u660E\u6587 \u2192 \u76F4\u63A5\u4F7F\u7528\u8BA2\u9605\u94FE\u63A5\uFF08Shadowrocket / Loon / QuanX \u626B\u7801\u8BC6\u522B\uFF09
function qrPayloadOf(fmt, url){
  var enc = encodeURIComponent(url);
  if (fmt === 'clash' || fmt === 'stash') return 'clash://install-config?url=' + enc;
  if (fmt === 'singbox') return 'sing-box://import-remote-profile?url=' + enc + '#' + __B;
  if (fmt === 'surge') return 'surge:///install-config?url=' + enc;
  return url;
}
function downloadSub(){
  var fmt = $('subFmt').value;
  var url = subUrlOf(fmt === 'auto' ? '' : fmt);
  var names = { auto:__B+'.yaml', clash:__B+'.yaml', stash:__B+'.yaml', singbox:__B+'.json', surge:__B+'.conf', surfboard:__B+'.conf', loon:__B+'.conf', quanx:__B+'.conf' };
  var link = document.createElement('a');
  link.href = url;
  link.download = names[fmt] || __B+'.txt';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  toast('\u5DF2\u8BF7\u6C42\u4E0B\u8F7D\uFF1B\u82E5\u672A\u5F00\u59CB\uFF0C\u53EF\u590D\u5236\u8BA2\u9605\u94FE\u63A5\u5728\u6D4F\u89C8\u5668\u6253\u5F00\u3002', '');
}
function previewSub(){
  var fmt = $('subFmt').value;
  var box = $('subPrev');
  box.style.display = 'block';
  $('prevType').textContent = '\u8BF7\u6C42\u4E2D\u2026';
  $('prevCount').textContent = '\u2014';
  $('prevBody').textContent = '';
  api('sub?fmt=' + encodeURIComponent(fmt === 'auto' ? '' : fmt))
    .then(function(r){
      if (!r || !r.ok){ $('prevType').textContent = '\u9884\u89C8\u5931\u8D25'; $('prevBody').textContent = (r && r.msg) || '\u672A\u77E5\u9519\u8BEF'; return; }
      var body = r.body || '';
      var type = r.type || '';
      $('prevType').textContent = type || '\u2014';
      var n = 0;
      if (typeof r.nodeCount === 'number') n = r.nodeCount;
      else if (/clash|yaml/i.test(type)) {
        var section = body.split(/(?:^|\\n)proxies:\\s*\\n/)[1] || '';
        section = section.split(/\\n[A-Za-z][\\w-]*:/)[0];
        n = (section.match(/^  - (?:name\\s*:|\\{)/gm) || []).length;
      }
      else if (/json/i.test(type)) {
        try { n = (JSON.parse(body).outbounds || []).filter(function(node){return node.type && ['selector','urltest','url-test','direct','block','dns'].indexOf(node.type)<0;}).length; } catch(e) { n=0; }
      }
      else {
        var t = body;
        if (!/^(vless|trojan|ss|xhttp):\\/\\//m.test(t)) {
          try { t = atob(t); } catch (e) { /* \u4FDD\u6301\u539F\u6837 */ }
        }
        n = t.split('\\n').filter(function(l){ return /^(vless|trojan|ss|xhttp):\\/\\//.test(l.trim()); }).length;
      }
      $('prevCount').textContent = n + ' \u4E2A\u8282\u70B9' + (typeof r.backendCount === 'number' ? '\uFF08\u805A\u5408 ' + r.backendCount + '/' + r.backendTotal + ' \u4E2A\u540E\u7AEF\uFF09' : '');
      $('prevBody').textContent = body.length > 2600 ? body.slice(0, 2600) + '\\n\u2026\uFF08\u5DF2\u622A\u65AD\uFF0C\u5B8C\u6574\u5185\u5BB9\u8BF7\u4E0B\u8F7D\uFF09' : body;
    })
    .catch(function(){ $('prevType').textContent = '\u9884\u89C8\u5931\u8D25\uFF1A\u65E0\u6CD5\u8FDE\u63A5\u670D\u52A1\u5668'; $('prevBody').textContent = ''; });
}

/* ===== \u4F18\u9009\u914D\u7F6E ===== */
function onPortSel(){
  var sel = $('o-port');
  var c = $('o-portC');
  c.style.display = sel.value === 'custom' ? '' : 'none';
}
function onSubMode(){
  var mode=(CFG&&CFG.optimizer||{}).subMode;
  $('fl-custom-pref').checked=mode==='custom';
  $('fl-random-pref').checked=mode==='random';
}
$('fl-custom-pref').addEventListener('change',function(){if(this.checked)$('fl-random-pref').checked=false;});
$('fl-random-pref').addEventListener('change',function(){if(this.checked)$('fl-custom-pref').checked=false;});
$('o-source').addEventListener('change', function(){
  $('o-customWrap').style.display = ($('o-source').value === 'custom') ? '' : 'none';
});
function pingIp(ip, port, timeout){
  var t0 = Date.now();
  var addr = ip.indexOf(':') >= 0 ? '[' + ip + ']' : ip;
  var proto = (port === 80 || port === 8080 || port === 8880 || port === 2052 || port === 2082 || port === 2086 || port === 2095) ? 'http' : 'https';
  var ctrl = new AbortController();
  var timer = setTimeout(function(){ ctrl.abort(); }, timeout);
  return fetch(proto + '://' + addr + ':' + port + '/', { mode: 'no-cors', cache: 'no-store', redirect: 'manual', signal: ctrl.signal })
    .then(function(){ clearTimeout(timer); return { ok: true, latency: Date.now() - t0 }; })
    .catch(function(){
      clearTimeout(timer);
      var ms = Date.now() - t0;
      if (proto === 'http' && ms < 100) return pingHttps(ip, port, timeout);
      return { ok: ms < timeout, latency: ms };
    });
}
function pingHttps(ip, port, timeout){
  var t0 = Date.now();
  var addr = ip.indexOf(':') >= 0 ? '[' + ip + ']' : ip;
  var ctrl = new AbortController();
  var timer = setTimeout(function(){ ctrl.abort(); }, timeout);
  return fetch('https://' + addr + ':' + port + '/', { mode: 'no-cors', cache: 'no-store', redirect: 'manual', signal: ctrl.signal })
    .then(function(){ clearTimeout(timer); return { ok: true, latency: Date.now() - t0 }; })
    .catch(function(){ clearTimeout(timer); var ms = Date.now() - t0; return { ok: ms < timeout, latency: ms }; });
}
function localTest(cands, threads, timeout){
  var results = [], idx = 0, pending = 0;
  return new Promise(function(resolve){
    function next(){
      while (pending < threads && idx < cands.length) {
        (function(c){
          pending++;
          pingIp(c.ip, c.port, timeout).then(function(r){
            pending--;
            results.push({ ip: c.ip, port: c.port, name: c.name || '', ok: r.ok, latency: r.latency });
            if (results.length === cands.length) resolve(results);
            else next();
          });
        })(cands[idx++]);
      }
    }
    next();
  });
}
function runPick(){
  if (!CFG){ toast('\u914D\u7F6E\u5C1A\u672A\u52A0\u8F7D', 'err'); return; }
  var o = collectForm().optimizer;
  showMsg('oMsg', '\u6B63\u5728\u62C9\u53D6\u5019\u9009 IP\u2026', 'info');
  api('candidates', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(o) })
    .then(function(r){
      if (!r || !r.ok){ showMsg('oMsg', (r && r.msg) || '\u62C9\u53D6\u5931\u8D25', 'err'); return; }
      var cands = r.data || [];
      if (!cands.length){ showMsg('oMsg', (r && r.msg) || '\u6CA1\u6709\u53EF\u6D4B\u7684 IP\uFF0C\u8BF7\u6362\u4E00\u4E2A\u6570\u636E\u6E90', 'err'); return; }
      var st = r.stats || {};
      var parts = [];
      if (st.preset) parts.push('\u9884\u8BBE\u6E90 ' + st.preset + ' \u6761');
      if (st.presetErr) parts.push('\u9884\u8BBE\u6E90\u5931\u8D25(' + st.presetErr + ')');
      if (st.custom) parts.push('\u81EA\u5B9A\u4E49\u6E90 ' + st.custom + ' \u6761');
      if (st.customErr) parts.push('\u81EA\u5B9A\u4E49\u6E90\u5931\u8D25(' + st.customErr + ')');
      if (st.cidr) parts.push('CF \u8865\u8DB3 ' + st.cidr + ' \u6761');
      // \u5019\u9009\u6570\u91CF\u622A\u65AD\uFF1A\u81EA\u5B9A\u4E49 URL \u6E90\u53EF\u80FD\u62C9\u53D6\u4E0A\u5343\u6761\u5019\u9009\uFF08\u7B2C\u4E09\u65B9\u4F18\u9009 IP \u6587\u6863\u52A8\u8F84\u4E0A\u5343\u6761\uFF09\uFF0C\u5168\u91CF\u6D4B\u901F\u8017\u65F6\u8FC7\u957F\uFF1B
      // \u6309\u300C\u5019\u9009\u6570\u91CF\u300D\u53EA\u6D4B\u524D N \u6761\uFF08\u53EF\u8C03\u9AD8\u6570\u503C\u6D4B\u66F4\u591A\uFF09\uFF0C\u6D4B\u901F\u5217\u8868\u4E0E\u300C\u5168\u90E8\u52A0\u5165\u6700\u4F18\u300D\u5747\u57FA\u4E8E\u8BE5\u5B50\u96C6
      var candSub = (o.count > 0 && cands.length > o.count) ? cands.slice(0, o.count) : cands;
      showMsg('oMsg', '\u62C9\u53D6 ' + cands.length + ' \u6761\uFF08' + (parts.join('\uFF0C') || '\u65E0') + '\uFF09\uFF0C\u672C\u5730\u6D4B\u901F\u524D ' + candSub.length + ' \u6761\u2026', 'info');
      localTest(candSub, o.threads || 5, 3000).then(function(results){
        results.sort(function(a, b){ return (a.latency < 0 ? 1e9 : a.latency) - (b.latency < 0 ? 1e9 : b.latency); });
        renderResults(results);
        var okc = results.filter(function(x){ return x.ok; }).length;
        showMsg('oMsg', '\u6D4B\u901F\u5B8C\u6210\uFF1A' + okc + '/' + results.length + ' \u53EF\u7528\uFF08\u672C\u5730 \u2192 \u76EE\u6807\uFF09', okc ? 'ok' : 'err');
      });
    })
    .catch(function(){ showMsg('oMsg', '\u62C9\u53D6\u5931\u8D25\uFF1A\u65E0\u6CD5\u8FDE\u63A5\u670D\u52A1\u5668', 'err'); });
}
function renderResults(list){
  var seen = {};
  var dedup = [];
  (list || []).forEach(function(r){
    if (seen[r.ip]) return;
    seen[r.ip] = 1;
    dedup.push(r);
  });
  LAST = dedup;
  var tb = $('oTableBody');
  tb.innerHTML = '';
  if (!LAST.length){ tb.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--faint)">\u6CA1\u6709\u53EF\u7528\u7ED3\u679C</td></tr>'; return; }
  LAST.forEach(function(r, i){
    var tr = document.createElement('tr');
    var ok = r.ok;
    var lag = ok ? (r.latency + 'ms') : '\u8D85\u65F6';
    var badge = '<span class="badge ' + (ok ? 'g' : 'r') + '">' + (ok ? '\u53EF\u7528' : '\u8D85\u65F6') + '</span>';
    var btn = ok ? '<button class="btn sm primary" onclick="useIp(' + i + ')">\u52A0\u5165\u4F18\u9009</button>' : '<span style="color:var(--faint)">\u2014</span>';
    tr.innerHTML = '<td class="ip">' + r.ip + ':' + r.port + '</td><td>' + lag + '</td><td>' + badge + '</td><td>' + btn + '</td>';
    tb.appendChild(tr);
  });
}
function useIp(i){
  var r = LAST[i];
  if (!r) return;
  var c=preferredTarget();if(!c){toast('\u8BF7\u5148\u9009\u62E9\u53EF\u7528\u7684\u76EE\u6807\u540E\u7AEF','warn');return;}if(c.saving){toast('\u8BF7\u7B49\u5F85\u540E\u7AEF\u4FDD\u5B58\u5B8C\u6210','warn');return;}
  var ta=c.list;
  var line = r.ip + ':' + r.port + (r.name ? ('#' + r.name) : '');
  var exists = false;
  String(ta.value || '').split(/[\\n,;]+/).forEach(function(s){
    var p = parseIps(s);
    if (p.length && p[0].ip === r.ip) exists = true;
  });
  if (exists){ toast('\u8BE5 IP \u5DF2\u5728\u4F18\u9009\u5217\u8868\u4E2D', 'warn'); return; }
  var s = ta.value.trim();
  ta.value = s ? (s + '\\n' + line) : line;
  c.mode.value='custom';c.mark();
  toast('\u5DF2\u52A0\u5165\u540E\u7AEF'+(c.backend.index+1)+'\uFF0C\u70B9\u51FB\u5361\u7247\u5185\u7684\u4FDD\u5B58\u6309\u94AE\u751F\u6548','ok');
}
function addAllBest(){
  var n = parseInt($('o-count').value) || 20;
  var seen = {};
  var list = [];
  LAST.filter(function(r){ return r.ok; }).forEach(function(r){
    if (seen[r.ip] || list.length >= n) return;
    seen[r.ip] = 1;
    list.push(r);
  });
  if (!list.length){ toast('\u6CA1\u6709\u53EF\u7528\u7ED3\u679C', 'err'); return; }
  var arr = [];
  // \u4FDD\u7559\u539F\u8282\u70B9\u540D\uFF1A\u9632\u5730\u533A\u4FE1\u606F\u4E22\u5931\u5BFC\u81F4\u8BA2\u9605\u65E0\u56FD\u5BB6\u663E\u793A\uFF1B\u65E0\u540D\u6761\u76EE\u624D\u7F16\u300C\u4F18\u9009N\u300D
  list.forEach(function(r, i){ arr.push(r.ip + ':' + r.port + (r.name ? ('#' + r.name) : ('#\u4F18\u9009' + (i + 1)))); });
  var c=preferredTarget();if(!c){toast('\u8BF7\u5148\u9009\u62E9\u53EF\u7528\u7684\u76EE\u6807\u540E\u7AEF','warn');return;}if(c.saving){toast('\u8BF7\u7B49\u5F85\u540E\u7AEF\u4FDD\u5B58\u5B8C\u6210','warn');return;}
  c.list.value=arr.join('\\n');c.mode.value='custom';c.mark();
  toast('\u5DF2\u52A0\u5165\u540E\u7AEF'+(c.backend.index+1)+'\uFF0C\u70B9\u51FB\u5361\u7247\u5185\u7684\u4FDD\u5B58\u6309\u94AE\u751F\u6548','ok');
}
/* ===== \u542F\u52A8 ===== */
buildNav();
var initView = 'dashboard';
try {
  var qv = new URLSearchParams(location.search).get('v');
  if (qv && TITLES[qv]) initView = qv;
} catch(e) {}
if(location.hash==='#optimizer') initView='optimizer';
switchView(initView);
loadAll();

/* \u6DB2\u6001\u73BB\u7483\uFF1A\u9AD8\u5149\u8DDF\u968F\u6307\u9488 */
var GLASS_EL=null,GLASS_EV=null,GLASS_RAF=0;
function glassTick(){GLASS_RAF=0;if(!GLASS_EL||!GLASS_EV)return;var r=GLASS_EL.getBoundingClientRect();if(!r.width||!r.height)return;GLASS_EL.style.setProperty('--mx',((GLASS_EV.clientX-r.left)/r.width*100).toFixed(1)+'%');GLASS_EL.style.setProperty('--my',((GLASS_EV.clientY-r.top)/r.height*100).toFixed(1)+'%');}
function bindGlass(){if(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;if (typeof mdPaint === 'function') mdPaint();
document.addEventListener('pointerdown', function(e){ if (typeof mdRipple === 'function') mdRipple(e); }, true);
/* \u9F20\u6807\u8DDF\u968F\u9AD8\u5149\u5DF2\u6309\u7528\u6237\u8981\u6C42\u79FB\u9664\uFF08\u539F pointermove \u2192 glassTick \u6CBF\u5149\u6807\u5237\u65B0\u5361\u7247\u9AD8\u5149\uFF09 */
document.addEventListener('pointerleave',function(){GLASS_EL=null;});}
bindGlass();
</script>
</body>
</html>

`;async function Te(t){let e=String(t.ADMIN||"").trim();if(e)return e;let a=await z(t,"admin");return a?String(a):""}function De(t,e){if(!e)return!1;let a=(t.headers.get("Cookie")||"").match(new RegExp("(?:^|;\\s*)"+Z+"=([^;]+)"));return!!(a&&a[1]===ce(e))}function L(t,e){return t.append("Set-Cookie",`${Z}=${ce(e)}; Path=/; Max-Age=86400; HttpOnly; Secure; SameSite=Lax`),t}function $e(t){return t.append("Set-Cookie",`${Z}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax`),t}function Ie({backends:t,sel:e,multi:a,balance:r,origin:n,adminFromEnv:o,sharedApi:i,configBackendIndex:l=e}){let s=Pe,p=JSON.stringify(t[l]?.url||"").replace(/</g,"\\u003c");s=s.replace("<head>","<head><script>window.CFN_CONFIG_BACKEND="+p+";window.CFN_CONFIG_BACKEND_INDEX="+(l||0)+";</script>"),s=s.replace(/<label>管理密码（留空则面板免登录）<\/label>/,"<label>\u524D\u7AEF\u767B\u5F55\u5BC6\u7801\uFF08\u7559\u7A7A\u4E0D\u53D8\u66F4\uFF09</label>"),s=s.replace(/placeholder="设置后访问面板需登录"/,'placeholder="\u4FEE\u6539\u524D\u7AEF\u767B\u5F55\u5BC6\u7801\uFF0C\u81F3\u5C11 4 \u4F4D\uFF08\u7559\u7A7A\u4E0D\u53D8\u66F4\uFF09"'),s=s.replace(/部署后首次访问强制要求设置管理密码；设置后此处留空并保存可恢复免登录。/,"\u6B64\u5BC6\u7801\u53EA\u5C5E\u4E8E\u524D\u7AEF\u9762\u677F\uFF08\u5B58\u524D\u7AEF KV\uFF09\uFF0C\u4E0E\u540E\u7AEF Pages / Worker \u65E0\u5173\u3002\u9996\u6B21\u8BBF\u95EE\u4F1A\u5F3A\u5236\u8981\u6C42\u8BBE\u7F6E\uFF1B\u4FEE\u6539\u540E\u8BF7\u91CD\u65B0\u767B\u5F55\u3002"),s=s.replace("admin: $('a-admin').value,","admin: '',"),s=s.replace("$('a-admin').value = CFG.admin || '';","$('a-admin').value = '';");let u=s.indexOf('<span class="tick"></span>\u5916\u89C2\u98CE\u683C'),c=u>=0?s.lastIndexOf('<div class="card">',u):-1;if(c>=0){let b=_e({backends:t,sel:e,multi:a,balance:r,origin:n,adminFromEnv:o,sharedApi:i});s=s.slice(0,c)+b+s.slice(c)}return qe(s)}function _e({backends:t,sel:e,multi:a,balance:r,origin:n,adminFromEnv:o,sharedApi:i}){let l=JSON.stringify({list:t.map(p=>({name:p.name,url:p.url,api:p.apiExplicit?p.api:"",uuid:p.uuid||""})),sel:e||0,multi:!!a,balance:!!r,origin:n,shared:!!i});return`<div class="card" id="beCard">
        <h3><span class="tick"></span>\u591A\u540E\u7AEF\u7BA1\u7406</h3>
        <p class="hint" style="margin-top:0;margin-bottom:8px">\u6BCF\u884C\u4E00\u4E2A\u540E\u7AEF\uFF0C\u683C\u5F0F <code>\u540D\u79F0:\u5730\u5740,API,UUID</code>\uFF08\u524D\u4E24\u6BB5\u5FC5\u586B\uFF0C\u540E\u4E24\u6BB5\u53EF\u7701\u7565\uFF09\uFF1B\u4E5F\u517C\u5BB9\u5192\u53F7\u8001\u5199\u6CD5 <code>\u540D\u79F0:\u5730\u5740:API[:UUID]</code>\uFF08\u4ECE\u53F3\u4FA7\u8BC6\u522B\uFF0C\u4E0D\u4F1A\u8BEF\u4F24\u5730\u5740\u91CC\u7684 <code>://</code> \u4E0E\u7AEF\u53E3\uFF09\u3002<br>
          \xB7 <b>\u540D\u79F0</b>\uFF1A\u7528\u4E8E\u7BA1\u7406\u5217\u8868\uFF1B\u8BA2\u9605\u4FDD\u7559\u5404\u8282\u70B9\u81EA\u5DF1\u7684\u540D\u79F0\uFF0C\u4EC5\u91CD\u540D\u65F6\u8865\u5145\u540E\u7AEF\u7F16\u53F7\u3002<br>
          \xB7 <b>\u5730\u5740</b>\uFF1A\u8BE5\u540E\u7AEF Worker \u7684\u5B8C\u6574\u5730\u5740\uFF0C\u5982 <code>https://v1.xxx.workers.dev</code>\u3002<br>
          \xB7 <b>API</b>\uFF1A\u8BE5\u540E\u7AEF\u81EA\u5DF1\u7684\u8BBF\u95EE\u5BC6\u94A5\uFF0C\u8981\u4E0E\u90A3\u4E2A\u540E\u7AEF Worker \u7684 <code>API</code> \u73AF\u5883\u53D8\u91CF\u4E00\u81F4\uFF1B\u7559\u7A7A\u5219\u56DE\u843D\u5230\u672C\u524D\u7AEF\u7684\u73AF\u5883\u53D8\u91CF <code>API</code>\uFF08\u4E24\u8005\u90FD\u6CA1\u914D\u3001\u800C\u540E\u7AEF\u53C8\u8BBE\u4E86\u5BC6\u94A5\u65F6\uFF0C\u8BE5\u540E\u7AEF\u4F1A\u8FDE\u4E0D\u4E0A\uFF09\u3002<br>
          \xB7 <b>UUID</b>\uFF1A\u8BE5\u540E\u7AEF\u5728\u8BA2\u9605/\u63A5\u53E3\u8DEF\u5F84\u91CC\u7684\u6620\u5C04\u6BB5\uFF0C<b>\u53EF\u7559\u7A7A</b> \u2014\u2014 \u7559\u7A7A\u4F9D\u6B21\u56DE\u843D\u5230\u672C\u524D\u7AEF\u7684\u73AF\u5883\u53D8\u91CF <code>U</code>\uFF0C\u518D\u6CA1\u6709\u5C31\u7528\u56FA\u5B9A\u6BB5 <code>cf</code>\u3002\u540E\u7AEF<b>\u53EA\u8BA4 API \u5BC6\u94A5\u3001\u4E0D\u6821\u9A8C\u8FD9\u91CC\u7684 UUID</b>\uFF0C\u6240\u4EE5\u586B\u4E0D\u586B\u3001\u586B\u4EC0\u4E48\u90FD\u53EF\u7528\uFF0C\u591A\u4E2A\u540E\u7AEF\u5404\u586B\u5404\u7684\u3001\u4E92\u4E0D\u5F71\u54CD\u3002<br>
          \u4F8B\uFF1A<code>hka:https://v1.paicn.workers.dev,\u8BE5\u540E\u7AEF\u7684API\u5BC6\u94A5,\u8BE5\u540E\u7AEF\u7684UUID</code>\u3002<br>
          \u6539\u5B8C\u70B9\u53F3\u4E0B\u89D2\u300C\u4FDD\u5B58\u5168\u90E8\u300D\u5199\u5165\u5B58\u50A8\u751F\u6548\u3002</p>
        <p class="hint" id="be-shared-tip" style="margin-top:0;margin-bottom:10px"></p>
        <div class="field"><label>\u540E\u7AEF\u5730\u5740\u5217\u8868</label>
          <textarea id="be-urls" rows="4" spellcheck="false" placeholder="hka:https://v1.paicn.workers.dev,\u8BE5\u540E\u7AEF\u7684API\u5BC6\u94A5&#10;us:https://v2.xxx.workers.dev,\u53E6\u4E00\u4E2AAPI\u5BC6\u94A5,\u8BE5\u540E\u7AEF\u7684UUID" style="width:100%;min-height:88px;background:var(--glass-field);color:var(--tx);border:1px solid var(--glass-field-brd);border-radius:10px;padding:10px;font:12.5px/1.7 ui-monospace,Consolas,monospace;resize:vertical"></textarea>
        </div>
        <div class="inrow" style="margin-top:10px">
          <button class="btn" id="be-check">\u68C0\u6D4B\u5728\u7EBF\u72B6\u6001</button>
        </div>
        <div style="display:flex;align-items:center;gap:12px;margin:16px 0 10px;flex-wrap:wrap">
          <label class="switch"><input type="checkbox" id="be-multi"><span class="sl"></span></label>
          <span style="font-size:13px">\u591A\u540E\u7AEF\u8BA2\u9605\u805A\u5408</span>
          <span style="flex:1"></span>
          <select id="be-sel" style="min-width:360px;flex:1;max-width:none"></select>
        </div>
        <div class="field"><label>\u4EE3\u7406\u8FDE\u63A5\u65B9\u5F0F</label>
          <select id="be-balance">
            <option value="stable">\u4F18\u5148\u7A33\u5B9A\uFF1A\u540C\u4E00\u8282\u70B9\u56FA\u5B9A\u540E\u7AEF\uFF0C\u6545\u969C\u65F6\u5207\u6362</option>
            <option value="round-robin">\u8F6E\u8BE2\u5747\u8861\uFF1A\u6BCF\u4E2A\u65B0\u8FDE\u63A5\u8F6E\u6362\u540E\u7AEF</option>
          </select>
        </div>
        <p class="hint" style="margin-top:0">\u805A\u5408\u8BA2\u9605\u4F1A\u4FDD\u7559\u5168\u90E8\u540E\u7AEF\u7684\u8282\u70B9\u3002\u9ED8\u8BA4\u4F18\u5148\u7A33\u5B9A\uFF0C\u6BCF\u4E2A\u8282\u70B9\u4F7F\u7528\u5176\u5BF9\u5E94\u540E\u7AEF\uFF1B\u8F6E\u8BE2\u5747\u8861\u4F1A\u5206\u644A\u65B0\u8FDE\u63A5\uFF0C\u4F46\u5EF6\u8FDF\u548C\u51FA\u53E3\u53EF\u80FD\u53D8\u5316\u3002\u540E\u7AEF\u63E1\u624B\u5931\u8D25\u3001\u8BF7\u6C42\u9650\u6D41\u6216\u8FBE\u5230\u8D26\u53F7\u914D\u989D\u9608\u503C\u65F6\uFF0C\u65B0\u8FDE\u63A5\u5207\u6362\u5230\u53EF\u7528\u540E\u7AEF\u3002\u5DF2\u5EFA\u7ACB\u7684\u8FDE\u63A5\u56FA\u5B9A\u4F7F\u7528\u539F\u540E\u7AEF\uFF0C\u65AD\u5F00\u540E\u9700\u5BA2\u6237\u7AEF\u91CD\u8FDE\uFF1B\u4E0D\u540C\u540E\u7AEF\u53EF\u80FD\u663E\u793A\u4E0D\u540C\u51FA\u53E3 IP\u3002\u914D\u7F6E\u8BFB\u5199\u4F5C\u7528\u4E8E\u9009\u4E2D\u7684\u540E\u7AEF\u3002</p>
        ${o?'<div id="be-admin-warn" style="margin-top:12px;padding:10px 12px;border:1px solid #f6ad55;border-radius:10px;background:rgba(246,173,85,.10);color:#f6ad55;font-size:12.5px;line-height:1.6">\u26A0\uFE0F \u524D\u7AEF\u5DF2\u901A\u8FC7 <code>ADMIN</code> \u73AF\u5883\u53D8\u91CF\u56FA\u5B9A\u767B\u5F55\u5BC6\u7801\uFF0C\u9762\u677F\u5185\u4FEE\u6539\u5BC6\u7801\u65E0\u6548\u3002</div>':""}
      </div>
      <script>
      (function(){
        var D = ${l};
        function $(id){ return document.getElementById(id); }
        var ta=$('be-urls'), sel=$('be-sel'), mul=$('be-multi'), routing=$('be-balance'), tip=$('be-shared-tip');
        if(tip){
          var base = D.shared
            ? '\u672C\u524D\u7AEF\u5DF2\u914D\u7F6E\u73AF\u5883\u53D8\u91CF <code>API</code>\uFF08\u5171\u4EAB\u5BC6\u94A5\uFF09\uFF1A\u67D0\u884C\u6CA1\u5355\u72EC\u5199\u5BC6\u94A5\u7684\u540E\u7AEF\uFF0C\u90FD\u4F1A\u7528\u5B83\u53BB\u8BBF\u95EE\u540E\u7AEF\u3002'
            : '\u672C\u524D\u7AEF\u672A\u914D\u7F6E\u73AF\u5883\u53D8\u91CF <code>API</code>\uFF1A\u540E\u7AEF\u82E5\u8BBE\u4E86\u5BC6\u94A5\uFF0C\u8BF7\u5728\u6BCF\u884C\u7684\u7B2C\u4E8C\u6BB5\u5355\u72EC\u586B\u5199\uFF08<code>\u540D\u79F0:\u5730\u5740,<b>API</b>,UUID</code>\uFF09\uFF0C\u5426\u5219\u8BE5\u540E\u7AEF\u4F1A\u62D2\u7EDD\u8BBF\u95EE\u3002';
          var noUuid = D.list.filter(function(b){return !b.uuid;}).length;
          if(noUuid) base += ' <span style="opacity:.75">\u5176\u4E2D '+noUuid+' \u4E2A\u540E\u7AEF\u672A\u586B UUID\uFF0C\u5C06\u56DE\u843D\u5230\u672C\u524D\u7AEF\u73AF\u5883\u53D8\u91CF <code>U</code>\uFF0C\u518D\u6CA1\u6709\u5C31\u7528\u515C\u5E95\u6BB5 <code>cf</code>\uFF08\u4E0D\u5F71\u54CD\u53EF\u7528\uFF09\u3002</span>';
          tip.innerHTML = base;
        }
        function label(b,i,mark){
          return (mark||'')+(b.name||('\u540E\u7AEF'+(i+1)))+' \u2014 '+b.url.replace(/^https?:\\/\\//,'')+((b.api||b.hasApi)?' \u{1F511}':'');
        }
        function fillSel(list, cur, marks){
          sel.innerHTML='';
          list.forEach(function(b,i){
            var o=document.createElement('option');
            o.value=i;
            o.textContent=label(b,i,marks&&marks[i]);
            sel.appendChild(o);
          });
          if(cur>=0&&cur<list.length) sel.value=cur;
        }
        function applyMulti(){
          sel.disabled = mul.checked;
          sel.style.opacity = mul.checked ? '.5' : '1';
          routing.disabled = !mul.checked;
        }
        function rowText(b){
          var s=b.name+':'+b.url;
          if(b.api||b.uuid) s+=','+(b.api||'');
          if(b.uuid) s+=','+b.uuid;
          return s;
        }
        fillSel(D.list, D.sel);
        ta.value=D.list.map(rowText).join('\\n');
        mul.checked=D.multi;
        routing.value=D.balance?'round-robin':'stable';
        applyMulti();
        mul.onchange=applyMulti;
        // \u89E3\u6790\u4E00\u884C\uFF1A\u540D\u79F0:\u5730\u5740,API,UUID\uFF08API / UUID \u53EF\u7701\u7565\uFF1B\u9017\u53F7\u5206\u6BB5\u4E0D\u5E72\u6270\u5730\u5740\u91CC\u7684 :// \u4E0E\u7AEF\u53E3\uFF09
        // \u517C\u5BB9\u65E7\u5199\u6CD5 \u540D\u79F0:\u5730\u5740:API[:UUID]\uFF08\u4ECE\u53F3\u4FA7\u5265 uuid/api\uFF09
        function parseLine(line){
          var api='', uuid='';
          var parts=line.split(',');
          if(parts.length>1){
            line=(parts[0]||'').trim();
            api=(parts[1]||'').trim();
            uuid=(parts[2]||'').trim();
          }else{
            var mu=line.match(/:([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/);
            if(mu){ uuid=mu[1]; line=line.slice(0,line.length-mu[0].length); }
            var ma=line.match(/:([A-Za-z0-9_.+=-]{8,})$/);
            if(ma){ api=ma[1]; line=line.slice(0,line.length-ma[0].length); }
          }
          line=line.replace(/:s*$/,'');
          var m=line.match(/^(?:([^:\\s]+)\\s*:\\s*)?(https?:\\/\\/\\S+)$/i);
          if(!m) return null;
          return {name:(m[1]||'').trim(),url:m[2].replace(/\\/+$/,''),api:api,uuid:uuid.replace(/^\\/+|\\/+$/g,'')};
        }
        function parseLines(){
          var lines=ta.value.split(/\\n+/).map(function(s){return s.trim();}).filter(Boolean);
          var list=[];
          for(var i=0;i<lines.length;i++){
            var one=parseLine(lines[i]);
            if(!one){ toast('\u7B2C'+(i+1)+'\u884C\u683C\u5F0F\u9519\u8BEF\uFF1A\u5E94\u4E3A \u540D\u79F0:\u5730\u5740,API,UUID\uFF08\u540E\u4E24\u6BB5\u53EF\u7701\u7565\uFF1B\u4E5F\u517C\u5BB9\u5192\u53F7\u5199\u6CD5 \u540D\u79F0:\u5730\u5740:API:UUID\uFF09','err'); return null; }
            list.push(one);
          }
          if(!list.length){ toast('\u8BF7\u81F3\u5C11\u586B\u5199\u4E00\u4E2A\u540E\u7AEF\u5730\u5740','err'); return null; }
          return list;
        }
        function hookSaveAll(){
          if(typeof saveAll !== 'function'){ setTimeout(hookSaveAll, 100); return; }
          if(saveAll.__beHooked) return;
          var orig = saveAll;
          function wrapped(){
            if(typeof hasPreferredDrafts==='function'&&hasPreferredDrafts()){toast('\u8BF7\u5148\u7528\u5404\u540E\u7AEF\u5361\u7247\u5185\u7684\u6309\u94AE\u4FDD\u5B58\u4F18\u9009\u4FEE\u6539','warn');return;}
            var list=parseLines();
            if(!list) return;
            // \u3010\u4E0D\u505A\u3011\u300C\u57FA\u7840\u914D\u7F6E UUID \u2192 \u540C\u6B65\u5230\u5F53\u524D\u884C\u300D\uFF1A\u6BCF\u884C\u624B\u586B\u7684 UUID \u624D\u662F\u6743\u5A01\u3002
            // \u540E\u7AEF\u5DF2\u4E0D\u518D\u6821\u9A8C\u8DEF\u5F84 UUID\uFF08\u5E26\u5BF9 API \u5BC6\u94A5\u5373\u653E\u884C\u4EFB\u610F UUID\uFF09\uFF0C\u524D\u7AEF\u53EA\u9700\u628A\u8BE5\u884C\u7684
            // UUID \u653E\u8FDB\u6620\u5C04\u8DEF\u5F84\uFF1B\u82E5\u5F3A\u884C\u540C\u6B65\uFF0C\u591A\u4E2A\u540E\u7AEF\u4F1A\u88AB\u903C\u6210\u540C\u4E00\u4E2A UUID\u3002
            var chain = fetch('/backends',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({backends:list})})
              .then(function(r){return r.json();})
              .then(function(r){
                if(!(r&&r.ok)){ toast((r&&r.msg)||'\u540E\u7AEF\u5217\u8868\u4FDD\u5B58\u5931\u8D25','err'); throw new Error('be'); }
                return fetch('/becfg',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sel:mul.checked?0:(parseInt(sel.value,10)||0),multi:mul.checked,balance:routing.value==='round-robin'})})
                  .then(function(r2){return r2.json();});
              })
              .then(function(r2){
                if(!(r2&&r2.ok)){ toast((r2&&r2.msg)||'\u5BF9\u63A5\u8BBE\u7F6E\u4FDD\u5B58\u5931\u8D25','err'); throw new Error('cfg'); }
                // \u4FDD\u5B58\u6210\u529F\u540E\u540C\u6B65\u5185\u5B58\u526F\u672C\u4E0E\u4E0B\u62C9\u5C55\u793A\uFF08\u5E76\u628A\u8F93\u5165\u6846\u89C4\u8303\u5316\uFF0C\u65B9\u4FBF\u4E0B\u6B21\u6838\u5BF9\uFF09
                D.list=list;
                fillSel(list, parseInt(sel.value,10)||0);
                ta.value=list.map(rowText).join('\\n');
              });
            // \u524D\u7AEF\u5BC6\u7801\uFF1Aa-admin \u6709\u503C\u5219 POST /setpass
            var pwdEl = document.getElementById('a-admin');
            if (pwdEl && pwdEl.value) {
              chain = chain.then(function(){
                return fetch('/setpass',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:pwdEl.value})})
                  .then(function(r){return r.json();})
                  .then(function(rp){
                    if(rp&&rp.ok){ pwdEl.value=''; toast('\u524D\u7AEF\u767B\u5F55\u5BC6\u7801\u5DF2\u66F4\u65B0','ok'); }
                    else toast((rp&&rp.msg)||'\u524D\u7AEF\u5BC6\u7801\u66F4\u65B0\u5931\u8D25','err');
                  });
              });
            }
            chain.then(function(){ orig.call(window); })
              .catch(function(e){ if(e&&e.message==='be'||e&&e.message==='cfg'){} else toast('\u591A\u540E\u7AEF\u4FDD\u5B58\u5931\u8D25\uFF1A\u65E0\u6CD5\u8FDE\u63A5\u524D\u7AEF','err'); });
          }
          wrapped.__beHooked = true;
          saveAll = wrapped;
        }
        hookSaveAll();
        function check(){
          fetch('/backends').then(function(r){return r.json();}).then(function(r){
            if(!r||!r.backends) return;
            var marks={}, list=D.list;
            if(r.backends.length===list.length){
              r.backends.forEach(function(b,i){ marks[i]=(b.online?'\u25CF ':'\u25CB '); });
              fillSel(list, parseInt(sel.value,10)||0, marks);
            }
            toast('\u5728\u7EBF '+r.backends.filter(function(b){return b.online;}).length+'/'+r.backends.length,'ok');
          }).catch(function(){ toast('\u68C0\u6D4B\u5931\u8D25','err'); });
        }
        $('be-check').onclick=check;
      })();
      </script>`}async function ie(t,e,a,r,n,o){let i=new URL(t.url),l=(t.headers.get("Upgrade")||"").toLowerCase(),s=te(t,e.api);s.set("x-cf-host",i.hostname);let p=a,u=I(e);if(n&&u){let m="/"+n+"/";a.startsWith(m)&&(p="/"+u+a.slice(m.length-1))}o&&(p="/"+I(e),s.set("x-cf-tunnel-uuid",o.uuid));let c=e.url+p+r;if(l==="websocket"){let m=await fetch(c,{method:"GET",headers:s});return m.webSocket?new Response(null,{status:101,webSocket:m.webSocket,headers:{"X-CFNext-Backend":e.name}}):m}let b={method:t.method,headers:s,redirect:"manual"};t.method!=="GET"&&t.method!=="HEAD"&&(b.body=t.body);let g=await fetch(c,b),w=new Headers({"X-CFNext-Backend":e.name});for(let[m,h]of g.headers){let y=m.toLowerCase();y==="content-encoding"||y==="content-length"||y==="transfer-encoding"||y==="connection"||y==="set-cookie"||w.set(m,h)}let x=[];try{typeof g.headers.getSetCookie=="function"&&(x=g.headers.getSetCookie())}catch{}if(!x.length){let m=g.headers.get("set-cookie");m&&(x=[m])}for(let m of x)w.append("set-cookie",m);return new Response(g.body,{status:g.status,statusText:g.statusText,headers:w})}var $=new Map,K,Ee=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;function Ne(t,e,a){let r=(t.headers.get("Upgrade")||"").toLowerCase()==="websocket";if(!r&&t.method!=="POST")return null;let n=a.match(/^\/([0-9a-f-]{36})\/?$/i);if(!n||!Ee.test(n[1]))return null;let o=e.findIndex(i=>I(i).toLowerCase()===n[1].toLowerCase());return o<0?null:{index:o,uuid:n[1],websocket:r}}async function Le(t){if([429,500,502,503,504].includes(t.status))return!0;if(t.status!==403)return!1;let e=t.clone().body?.getReader();if(!e)return!1;let a="";try{for(;a.length<16384;){let r=await e.read();if(r.done)break;a+=new TextDecoder().decode(r.value)}}finally{e.cancel().catch(()=>{})}return/\b1027\b|daily\s+(?:request\s+)?limit|requests?\s+limit\s+exceeded|每日.{0,12}(?:额度|上限)/i.test(a)}function se(t){$.size>128&&$.clear(),$.set(t.url,Date.now()+6e4)}async function le(t,e,a,r,n,o,i,l=!1){if(!e.length)return new Response("No backends configured",{status:503});if(o&&r.startsWith("/"+o+"/api/"))return ie(t,e[a],r,n,o);let s=Ne(t,e,r);if((t.headers.get("Upgrade")||"").toLowerCase()==="websocket"&&!s)return new Response("Unknown node UUID; update your subscription",{status:404});s&&l&&K===void 0&&(K=crypto.getRandomValues(new Uint32Array(1))[0]);let u=s?l?K++%e.length:s.index:a,c=await fe(i),b=Array.from({length:e.length},(m,h)=>(u+h)%e.length).filter(m=>!c.has(e[m].url)&&!($.get(e[m].url)>Date.now())),g=s?.websocket||t.method==="GET"||t.method==="HEAD",w=g?b:b.slice(0,1),x;for(let m of w){let h=e[m];if(!(s&&m!==s.index&&!h.api))try{let y=await ie(t,h,r,n,o,s);if(!await Le(y))return $.delete(h.url),y;if(se(h),!g)return y;x="HTTP "+y.status,y.body?.cancel().catch(()=>{})}catch(y){se(h),x=y.message||"Backend connection failed"}}return new Response("No available backend: "+(x||"quota threshold or temporary cooldown"),{status:503,headers:{"Retry-After":"60","Cache-Control":"no-store"}})}var X=900*1e3,U=new Map,F=new Map,M=null,Y=null;function S(t,e=200){return new Response(JSON.stringify(t),{status:e,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}})}async function ae(t){let e=ee(t);if(M&&M.env===t.QUOTA_ACCOUNTS&&M.replacements===e&&M.store===t.K&&Date.now()-M.at<3e5)return M.accounts;let a;try{a=await z(t,"quota_accounts")}catch{a=null}a||(a=t.QUOTA_ACCOUNTS||"[]");let r=JSON.parse(a);if(!Array.isArray(r))throw new Error("Invalid quota account configuration");return r=r.map(n=>({...n,backends:(n.backends||[]).map(o=>J(t,{url:o})?.url||o)})),M={env:t.QUOTA_ACCOUNTS,store:t.K,replacements:e,at:Date.now(),accounts:r},r}async function re(t,e){let a=U.get(e.id),r=a&&a.store===t.K&&a.token===e.token;if(r&&Date.now()-a.loadedAt<6e4)return a;let n=r?a.data:null;try{let i=await ue(t,"quota_usage:"+e.id),l=i.hit?i.value:null;if(l){let s=JSON.parse(l);s&&(!n||Number(s.checkedAt||0)>Number(n.checkedAt||0))&&(n=s)}}catch{}let o={store:t.K,token:e.token,data:n,loadedAt:Date.now()};return U.set(e.id,o),o}async function me(t,e,a=!1){let r=await re(t,e),n=Date.now(),o=new Date(n).toISOString().slice(0,10),i=r.data?.day===o?r.data:null;if(i&&(i.retryAt>n||!a&&n-i.checkedAt<X))return i;if(F.has(e.id))return F.get(e.id);let l=(async()=>{let s;try{if(!e.token)throw new Error("\u672A\u914D\u7F6E API \u4EE4\u724C");let p=o+"T00:00:00.000Z",u=await fetch("https://api.cloudflare.com/client/v4/graphql",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+e.token},body:JSON.stringify({query:"query AccountUsage($id: string!, $start: string!, $end: string!) { viewer { accounts(filter: {accountTag: $id}) { workersInvocationsAdaptive(limit: 1, filter: {datetime_geq: $start, datetime_leq: $end}) { sum { requests subrequests } quantiles { cpuTimeP50 } } pagesFunctionsInvocationsAdaptiveGroups(limit: 1, filter: {datetime_geq: $start, datetime_leq: $end}) { sum { requests } } } } }",variables:{id:e.id,start:p,end:new Date(n).toISOString()}}),signal:AbortSignal.timeout(1e4)});if(!u.ok)throw new Error("Cloudflare HTTP "+u.status);let c=await u.json();if(c.errors?.length)throw new Error(c.errors.map(m=>m.message||"GraphQL error").join("; ").slice(0,300));let b=c.data?.viewer?.accounts?.[0];if(!b)throw new Error("\u672A\u627E\u5230\u8D26\u6237\uFF0C\u68C0\u67E5\u8D26\u6237 ID \u548C Account Analytics \u8BFB\u53D6\u6743\u9650");let g=(b.workersInvocationsAdaptive||[]).reduce((m,h)=>m+(h.sum?.requests||0),0),w=(b.pagesFunctionsInvocationsAdaptiveGroups||[]).reduce((m,h)=>m+(h.sum?.requests||0),0),x=g+w;s={day:o,checkedAt:n,updatedAt:new Date(n).toISOString(),workers:g,pages:w,requests:x,limit:e.limit,percent:Math.round(x/e.limit*1e3)/10,remaining:Math.max(0,e.limit-x),cpuTime:b.workersInvocationsAdaptive?.[0]?.quantiles?.cpuTimeP50||0,subrequests:(b.workersInvocationsAdaptive||[]).reduce((m,h)=>m+(h.sum?.subrequests||0),0)}}catch(p){let u=String(p.message||p);s={...i&&i.requests!=null?i:{},day:o,checkedAt:n,error:u,stale:!!(i&&i.requests!=null),retryAt:n+(/429/.test(u)?X:6e4)}}return U.set(e.id,{store:t.K,token:e.token,data:s,loadedAt:n}),await xe(t,"quota_usage:"+e.id,JSON.stringify(s)),s})();F.set(e.id,l);try{return await l}finally{F.delete(e.id)}}async function Fe(t){let e=Y;if((!e||e.store!==t.K||e.config!==t.QUOTA_ACCOUNTS)&&(e=Y={store:t.K,config:t.QUOTA_ACCOUNTS,next:0,pending:null}),e.pending)return e.pending;if(!(Date.now()<e.next)){e.next=Date.now()+6e4,e.pending=(async()=>{let a=await ae(t);await Promise.all(a.map(r=>me(t,r).catch(()=>{})))})();try{await e.pending}finally{e.pending=null}}}async function fe(t){let e=new Set;if(!t)return e;let a=await ae(t),r=new Date().toISOString().slice(0,10);return await Promise.all(a.map(async n=>{let o=(await re(t,n)).data;if(o?.day===r&&!o.error&&o.requests!=null&&o.requests*100>=n.limit*n.threshold&&Date.now()-o.checkedAt<2*X)for(let i of n.backends||[])e.add(i)})),e}async function Re(t,e,a){let r=new URL(t.url),n=await ae(e);if(r.pathname==="/quota-accounts/check"&&t.method==="POST"){let i=await t.json(),l=i.id?n.filter(p=>p.id===i.id):n;if(!l.length)return S({ok:!1,msg:"\u8BF7\u5148\u4FDD\u5B58\u8D26\u53F7"},400);let s=await Promise.all(l.map(async p=>({id:p.id,name:p.name,...await me(e,p,!i.cached)})));return S({ok:!0,results:s})}if(r.pathname!=="/quota-accounts")return S({ok:!1},404);if(t.method==="POST"){if(!e.K)return S({ok:!1,msg:"\u524D\u7AEF\u672A\u7ED1\u5B9A KV"},500);let i=await t.json();if(!Array.isArray(i.accounts)||i.accounts.length>20)return S({ok:!1,msg:"\u6700\u591A\u914D\u7F6E 20 \u4E2A\u8D26\u53F7"},400);let l=new Set(a.map(u=>u.url)),s=[],p=new Set;for(let u of i.accounts){let c=String(u.id||"").trim().toLowerCase();if(!/^[0-9a-f]{32}$/.test(c)||p.has(c))return S({ok:!1,msg:"\u8D26\u6237 ID \u5FC5\u987B\u4E3A\u4E0D\u91CD\u590D\u7684 32 \u4F4D\u5341\u516D\u8FDB\u5236\u5B57\u7B26\u4E32"},400);p.add(c);let b=n.find(h=>h.id===c),g=String(u.token||"").trim()||b?.token||"";if(!g)return S({ok:!1,msg:"\u65B0\u8D26\u53F7\u9700\u8981\u586B\u5199 API \u4EE4\u724C"},400);let w=Number(u.limit||1e5),x=Number(u.threshold??80);if(!Number.isInteger(w)||w<1||!Number.isFinite(x)||x<1||x>100)return S({ok:!1,msg:"\u989D\u5EA6\u548C\u5207\u6362\u9608\u503C\u65E0\u6548"},400);let m=[...new Set((u.backends||[]).map(h=>String(h).trim().replace(/\/+$/,"")).filter(Boolean))];if(m.some(h=>!l.has(h)))return S({ok:!1,msg:"\u5173\u8054\u57DF\u540D\u5FC5\u987B\u6765\u81EA\u5DF2\u914D\u7F6E\u7684\u540E\u7AEF\u5217\u8868"},400);if(s.some(h=>h.backends.some(y=>m.includes(y))))return S({ok:!1,msg:"\u4E00\u4E2A\u540E\u7AEF\u53EA\u80FD\u5173\u8054\u4E00\u4E2A\u8D26\u53F7"},400);s.push({id:c,name:String(u.name||c).slice(0,100),token:g,limit:w,threshold:x,backends:m})}return await D(e,"quota_accounts",JSON.stringify(s)),M={env:e.QUOTA_ACCOUNTS,replacements:ee(e),store:e.K,at:Date.now(),accounts:s},Y=null,U.clear(),S({ok:!0,msg:"\u5DF2\u4FDD\u5B58 "+s.length+" \u4E2A\u72EC\u7ACB\u8D26\u53F7",accounts:s.map(({token:u,...c})=>({...c,hasToken:!!u}))})}if(t.method!=="GET")return S({ok:!1},405);let o=await Promise.all(n.map(async i=>{let{token:l,...s}=i,p=(await re(e,i)).data;return{...s,hasToken:!!l,usage:p?.day===new Date().toISOString().slice(0,10)?p:null}}));return S({ok:!0,accounts:o})}var ze={async fetch(t,e,a){let r=new URL(t.url),n=String(e.ENTRY||e.LOGIN||e.L||"").trim().replace(/^\/+|\/+$/g,""),o=n?"/"+n:"",i=!!o&&r.pathname===o,l=String(e.ADMIN||"").trim(),s=i||["/backends","/becfg","/setpass","/quota-accounts","/quota-accounts/check","/preferred-backends"].includes(r.pathname)||o&&r.pathname.startsWith(o+"/api/"),p="";try{s&&(p=await Te(e))}catch{return new Response(JSON.stringify({ok:!1,msg:"\u524D\u7AEF\u914D\u7F6E\u6682\u65F6\u65E0\u6CD5\u8BFB\u53D6\uFF0C\u53EF\u80FD\u5DF2\u8FBE\u5230 KV \u914D\u989D\u3002\u8BF7\u7A0D\u540E\u91CD\u8BD5\uFF0C\u539F\u5BC6\u7801\u65E0\u9700\u91CD\u65B0\u8BBE\u7F6E\u3002"}),{status:503,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store","Retry-After":"30"}})}let u=De(t,p),c=(d,f,v)=>new Response(JSON.stringify(d),{status:f||200,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store",...v||{}}}),b=d=>new Response(d,{status:200,headers:{"content-type":"text/html; charset=utf-8","cache-control":"no-store, no-cache, must-revalidate",Pragma:"no-cache"}}),g=t.method==="GET"||t.method==="HEAD",w=d=>new Response(null,{status:302,headers:{Location:d,"cache-control":"no-store"}}),x=(()=>{let d=t.headers.get("User-Agent")||"",f=t.headers.get("Accept")||"";return/mozilla|applewebkit|chrome|safari|firefox|edg/i.test(d)&&(/text\/html/i.test(f)||t.headers.get("Sec-Fetch-Dest")==="document"||t.headers.get("Upgrade-Insecure-Requests")==="1")})();if(o&&g){if(r.pathname===o+"/"||r.pathname==="/")return w(o+(r.search||""));if(x&&r.pathname.startsWith(o+"/")){let d=r.pathname.slice(o.length);if(!/^\/(api|sub|crules)(\/|$)/.test(d))return w(o)}}if(i&&t.method==="POST"){let d;try{d=await t.json()}catch{d=null}let f=d&&typeof d.password=="string"?d.password:"";if(l){if(f!==l)return c({ok:!1,msg:"\u5BC6\u7801\u9519\u8BEF"},403);let k=L(new Headers({"content-type":"application/json; charset=utf-8"}),l);return new Response(JSON.stringify({ok:!0,next:o}),{status:200,headers:k})}if(!p){if(f.length<4)return c({ok:!1,msg:"\u5BC6\u7801\u81F3\u5C11 4 \u4F4D"},400);if(!e.K||typeof e.K.put!="function")return c({ok:!1,msg:"\u524D\u7AEF\u672A\u7ED1\u5B9A KV\uFF0C\u65E0\u6CD5\u4FDD\u5B58\u5BC6\u7801"},500);await D(e,"admin",f);let k=L(new Headers({"content-type":"application/json; charset=utf-8"}),f);return new Response(JSON.stringify({ok:!0,next:o}),{status:200,headers:k})}if(f!==p)return c({ok:!1,msg:"\u5BC6\u7801\u9519\u8BEF"},403);let v=L(new Headers({"content-type":"application/json; charset=utf-8"}),p);return new Response(JSON.stringify({ok:!0,next:o}),{status:200,headers:v})}if(i&&(t.method==="GET"||t.method==="HEAD")){if(!p)return b(he);if(!u)return b(ve);let d=await oe(e),f=await R(e,d.length||1),v=r.searchParams.get("backend"),k=v==null?f.sel:d.findIndex(C=>C.url===v);return v!=null&&k<0?c({ok:!1,msg:"\u6B64\u540E\u7AEF\u5DF2\u4E0D\u5B58\u5728\uFF0C\u8BF7\u4ECE\u9762\u677F\u5165\u53E3\u91CD\u65B0\u9009\u62E9"},400):b(Ie({backends:d,sel:f.sel,multi:f.multi,balance:f.balance,origin:r.origin,adminFromEnv:!!l,sharedApi:String(e.API||e.GATE||"").trim(),configBackendIndex:k}))}let m=()=>p&&u?null:c({ok:!1,msg:p?"\u672A\u6388\u6743":"\u8BF7\u5148\u8BBE\u7F6E\u767B\u5F55\u5BC6\u7801"},403),h=await oe(e),y=await R(e,h.length||1),E=()=>{let d=t.headers.get("x-cfnext-config-backend");return d?h.find(f=>f.url===d):h[y.sel]};if(r.pathname==="/quota-accounts"||r.pathname==="/quota-accounts/check"){let d=m();if(d)return d;try{return await Re(t,e,h)}catch(f){return S({ok:!1,msg:String(f.message||f)},500)}}if(a&&typeof a.waitUntil=="function"&&((t.headers.get("Upgrade")||"").toLowerCase()==="websocket"||/\/sub\//.test(r.pathname))&&a.waitUntil(Fe(e).catch(()=>{})),r.pathname==="/preferred-backends"){let d=m();if(d)return d;if(t.method!=="GET")return c({ok:!1,msg:"\u4EC5\u652F\u6301\u8BFB\u53D6"},405);let f=await Promise.all(h.map(async(v,k)=>{let C={index:k,url:v.url,lines:[],subMode:"",includeDefault:!1,randomCount:16};try{let P=te(new Request("https://local/",{headers:{"User-Agent":"Mozilla/5.0"}}),v.api);P.set("x-cf-host",r.hostname);let B=await fetch(v.url+"/"+I(v)+"/api/config",{headers:P,signal:AbortSignal.timeout(1e4)});if(!B.ok)return{...C,error:"HTTP "+B.status};let G=await B.json();if(!G.ok||!G.data)return{...C,error:"\u914D\u7F6E\u8BFB\u53D6\u5931\u8D25"};let T=G.data;C.lines=String(T.preferredDomains||"").split(/[\n;]+/).map(A=>A.trim()).filter(Boolean);for(let A of Array.isArray(T.preferredIPs)?T.preferredIPs:[])!A||typeof A.ip!="string"||C.lines.push((A.ip.includes(":")?"["+A.ip+"]":A.ip)+":"+(A.port||443)+(A.name?"#"+A.name:""));return C.subMode=T.optimizer?.subMode||"",C.includeDefault=!!T.optimizer?.subIncludeDefault,C.randomCount=T.optimizer?.subRandomCount||16,C}catch{return{...C,error:"\u6682\u65F6\u65E0\u6CD5\u8BFB\u53D6\u6B64\u540E\u7AEF\uFF0C\u8BF7\u7A0D\u540E\u5237\u65B0"}}}));return c({ok:!0,multi:y.multi,backends:f})}if(r.pathname==="/backends"){let d=m();if(d)return d;if(t.method==="POST")return await Ae(t,e);let f=await Promise.all(h.map(async(v,k)=>{let C={"User-Agent":"Mozilla/5.0"};v.api&&(C["x-cf-api"]=v.api);try{let P=await fetch(v.url+"/",{headers:C,signal:AbortSignal.timeout(5e3)});return{index:k,name:v.name,url:v.url,online:P.status<500,status:P.status,hasApi:!!v.api,hasUuid:!!(v.uuid||v.envUuid)}}catch{return{index:k,name:v.name,url:v.url,online:!1,status:0,hasApi:!!v.api,hasUuid:!!(v.uuid||v.envUuid)}}}));return new Response(JSON.stringify({backends:f,sel:y.sel,multi:y.multi,balance:y.balance,aggregate:r.origin+"/aggregate/sub/clash"}),{status:200,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}})}if(r.pathname==="/becfg"&&t.method==="POST"){let d=m();return d||await Me(t,e,h.length)}if(r.pathname==="/setpass"&&t.method==="POST"){let d=m();if(d)return d;if(l)return c({ok:!1,msg:"\u524D\u7AEF\u5DF2\u7531 ADMIN env \u56FA\u5B9A\u5BC6\u7801\uFF0C\u4E0D\u53EF\u4FEE\u6539"},400);let f;try{f=await t.json()}catch{f=null}let v=f&&typeof f.password=="string"?f.password:"";if(v.length<4)return c({ok:!1,msg:"\u5BC6\u7801\u81F3\u5C11 4 \u4F4D"},400);if(!e.K||typeof e.K.put!="function")return c({ok:!1,msg:"\u524D\u7AEF\u672A\u7ED1\u5B9A KV\uFF0C\u65E0\u6CD5\u4FDD\u5B58\u5BC6\u7801"},500);await D(e,"admin",v);let k=L(new Headers({"content-type":"application/json; charset=utf-8"}),v);return new Response(JSON.stringify({ok:!0,msg:"\u524D\u7AEF\u767B\u5F55\u5BC6\u7801\u5DF2\u66F4\u65B0"}),{status:200,headers:k})}if(o&&r.pathname===o+"/api/reset"&&t.method==="POST"){let d=m();if(d)return d;let f=E();if(!f)return c({ok:!1,msg:"\u7F16\u8F91\u540E\u7AEF\u5DF2\u4E0D\u5B58\u5728\uFF0C\u8BF7\u91CD\u65B0\u8F7D\u5165\u9762\u677F"},400);try{await le(t,[f],0,r.pathname,r.search,n,e,!1)}catch{}try{e.K&&typeof e.K.delete=="function"&&await ye(e,"admin")}catch{}let v=new Headers({"content-type":"application/json; charset=utf-8","cache-control":"no-store"});return $e(v),new Response(JSON.stringify({ok:!0,msg:"\u5DF2\u91CD\u7F6E\uFF1A\u540E\u7AEF\u914D\u7F6E\u4E0E\u524D\u7AEF\u767B\u5F55\u5BC6\u7801\u5747\u5DF2\u6E05\u9664\uFF0C\u8BF7\u91CD\u65B0\u8BBE\u7F6E\u5BC6\u7801"}),{status:200,headers:v})}if(!h.length)return b(ge);if(y.multi&&o&&r.pathname===o+"/api/sub"){let d=m();if(d)return d;let f=H(r.searchParams.get("fmt"),t.headers.get("User-Agent"));if(f&&(t.method==="GET"||t.method==="HEAD")){let v=await V(h,f,r.search,r.hostname,n,e),k=await v.text();return v.ok?c({ok:!0,type:f==="singbox"?"application/json":"text/yaml",body:k,nodeCount:ke(k,f),backendCount:Number(v.headers.get("X-CFNext-Backend-Count")),backendTotal:Number(v.headers.get("X-CFNext-Backend-Total"))}):c({ok:!1,msg:k},v.status)}}if(r.pathname.startsWith("/aggregate/sub/")){let d=r.pathname.match(/^\/aggregate\/sub(?:\/([^/]+))?\/?$/);if(d){let f=H(d[1]||r.searchParams.get("fmt"),t.headers.get("User-Agent"));return await V(h,f||d[1]||"clash",r.search,r.hostname,n,e)}}if(y.multi){let d=r.pathname.match(/^\/[^/]+\/sub(?:\/([^/]+))?\/?$/),f=d&&H(d[1]||r.searchParams.get("fmt"),t.headers.get("User-Agent"));if(f)return await V(h,f,r.search,r.hostname,n,e)}if(o&&r.pathname.startsWith(o+"/api/")){let d=m();if(d)return d}try{let d=o&&r.pathname.startsWith(o+"/api/"),f=d?E():null;return d&&!f?c({ok:!1,msg:"\u7F16\u8F91\u540E\u7AEF\u5DF2\u4E0D\u5B58\u5728\uFF0C\u8BF7\u91CD\u65B0\u8F7D\u5165\u9762\u677F"},400):await le(t,f?[f]:h,f?0:y.sel,r.pathname,r.search,n,e,!d&&y.multi&&y.balance)}catch(d){return new Response("backend unreachable: "+(d&&d.message||d),{status:502,headers:{"content-type":"text/plain; charset=utf-8","cache-control":"no-store"}})}}},Ue=`<div class="card" id="mq-card">
  <h3><span class="tick"></span>\u591A\u8D26\u53F7\u914D\u989D\u76D1\u63A7 <span class="sub" id="mq-summary">\u52A0\u8F7D\u4E2D\u2026</span></h3>
  <p class="hint">\u6BCF\u4E2A Cloudflare \u8D26\u53F7\u5355\u72EC\u68C0\u67E5 Workers + Pages \u8BF7\u6C42\u91CF\uFF0C\u540C\u8D26\u53F7\u7684\u9879\u76EE\u5171\u7528\u989D\u5EA6\u3002\u524D\u7AEF\u8D26\u53F7\u4E5F\u5355\u72EC\u5217\u51FA\uFF0C\u4E0D\u628A\u5404\u8D26\u53F7\u989D\u5EA6\u5408\u5E76\u3002\u6BCF\u5929\u5317\u4EAC\u65F6\u95F4 08:00 \u91CD\u7F6E\uFF0C\u7EDF\u8BA1\u5B58\u5728\u5EF6\u8FDF\u3002</p>
  <div class="inrow" style="margin-bottom:16px;flex-wrap:wrap">
    <button class="btn sm" id="mq-add">\u6DFB\u52A0\u8D26\u53F7</button>
    <button class="btn primary sm" id="mq-save">\u4FDD\u5B58\u8D26\u53F7\u8BBE\u7F6E</button>
    <button class="btn sm" id="mq-check-all">\u68C0\u67E5\u5168\u90E8\u8D26\u53F7</button>
  </div>
  <div id="mq-message" class="hint" role="status" aria-live="polite"></div>
  <div id="mq-accounts"></div>
  <p class="hint">\u4EE4\u724C\u9700\u8981 Account Analytics \u8BFB\u53D6\u6743\u9650\uFF0C\u4EC5\u4FDD\u5B58\u5728\u524D\u7AEF\u670D\u52A1\u7AEF\uFF0C\u9875\u9762\u4E0D\u56DE\u663E\u3002\u7559\u7A7A\u4FDD\u7559\u539F\u4EE4\u724C\u3002\u5173\u8054\u540E\u7AEF\u8FBE\u5230\u5207\u6362\u9608\u503C\u65F6\uFF0C\u65B0\u8FDE\u63A5\u4F1A\u9009\u62E9\u5176\u5B83\u53EF\u7528\u540E\u7AEF\uFF1B\u524D\u7AEF\u989D\u5EA6\u8017\u5C3D\u4ECD\u4F1A\u5F71\u54CD\u7EDF\u4E00\u5165\u53E3\u3002\u81EA\u52A8\u68C0\u67E5\u95F4\u9694 15 \u5206\u949F\uFF0C429 \u5355\u72EC\u9000\u907F\uFF0C\u4E0D\u5F71\u54CD\u5176\u5B83\u8D26\u53F7\u3002</p>
</div>
`,Oe=`<script>
(function () {
  'use strict';
  var accounts = [], dirty = false, legacyRefresh = window.refreshQuota, legacyDb = window.updDbQuota;
  var list = document.getElementById('mq-accounts'), message = document.getElementById('mq-message');
  function el(tag, text, cls) { var e=document.createElement(tag); if(text!=null)e.textContent=text; if(cls)e.className=cls; return e; }
  function input(label, key, value, type, parent) {
    var field=el('div',null,'field'), caption=el('label',label), box=el('input');
    box.type=type||'text'; box.value=value==null?'':String(value); box.dataset.key=key;
    box.setAttribute('aria-label', label); box.autocomplete=key==='token'?'new-password':'off';
    if(key==='token')box.placeholder='\u5DF2\u4FDD\u5B58\uFF0C\u7559\u7A7A\u4FDD\u7559\uFF1B\u65B0\u8D26\u53F7\u8BF7\u586B\u5165';
    field.append(caption,box); parent.appendChild(field); return box;
  }
  function collect() {
    return Array.from(list.children).map(function(card){
      var o={}; card.querySelectorAll('[data-key]').forEach(function(box){o[box.dataset.key]=box.value.trim();});
      o.backends=o.backends.split(/[\\n,]+/).map(function(x){return x.trim();}).filter(Boolean);
      o.limit=Number(o.limit); o.threshold=Number(o.threshold); return o;
    });
  }
  function result(card, data) {
    var output=card.querySelector('[data-result]'); output.replaceChildren();
    if(!data){output.textContent='\u5C1A\u672A\u68C0\u67E5';return;}
    if(data.error){var error=el('div',(data.stale?'\u7F13\u5B58\u6570\u636E \xB7 ':'\u68C0\u67E5\u5931\u8D25 \xB7 ')+data.error);error.style.color='var(--err)';output.appendChild(error);}
    if(data.persistenceWarning)output.appendChild(el('div',data.persistenceWarning));
    if(data.requests!=null){
      output.appendChild(el('div','\u5DF2\u7528 '+Number(data.requests).toLocaleString()+' / '+Number(data.limit).toLocaleString()+' \u6B21\uFF08'+data.percent+'%\uFF09 \xB7 \u5269\u4F59 '+Number(data.remaining).toLocaleString()+' \u6B21'));
      output.appendChild(el('div','Workers '+Number(data.workers||0).toLocaleString()+' \xB7 Pages '+Number(data.pages||0).toLocaleString()+' \xB7 \u66F4\u65B0 '+new Date(data.updatedAt).toLocaleString()));
      var bar=el('progress');bar.max=100;bar.value=Math.min(100,data.percent||0);bar.style.cssText='width:100%;height:10px;margin-top:8px';bar.setAttribute('aria-label','\u5DF2\u7528\u989D\u5EA6');output.appendChild(bar);
    }
    if(data.requests==null&&!data.error)output.textContent='\u5C1A\u65E0\u53EF\u7528\u7EDF\u8BA1';
  }
  function summary() {
    var failed=accounts.filter(function(a){return a.usage&&a.usage.error;}).length;
    var checked=accounts.filter(function(a){return a.usage&&a.usage.requests!=null;}).length;
    document.getElementById('mq-summary').textContent=accounts.length+' \u4E2A\u8D26\u53F7 \xB7 '+checked+' \u5DF2\u68C0\u67E5'+(failed?' \xB7 '+failed+' \u67E5\u8BE2\u5F02\u5E38':'');
    if(accounts.length){
      var old=document.getElementById('qQuotaSub');if(old)old.closest('.card').style.display='none';
      var db=document.getElementById('dbSub');if(db)db.textContent='\u591A\u8D26\u53F7 '+accounts.length+' \u4E2A \xB7 '+failed+' \u5F02\u5E38';
      var wrap=document.getElementById('dbWrap');if(wrap)wrap.style.display='none';
    }
  }
  function render() {
    list.replaceChildren();
    accounts.forEach(function(a,index){
      var card=el('div',null,'mq-account');card.style.cssText='border:1px solid var(--border,var(--bd));border-radius:12px;padding:16px;margin-top:14px';card.dataset.id=a.id||'';
      var heading=el('h3',a.name||'\u65B0\u8D26\u53F7');card.appendChild(heading);
      var grid=el('div',null,'grid2');
      input('\u8D26\u53F7\u540D\u79F0','name',a.name,'text',grid);input('\u8D26\u6237 ID','id',a.id,'text',grid);
      input('API \u4EE4\u724C','token',a.token||'','password',grid);input('\u6BCF\u65E5\u8BF7\u6C42\u989D\u5EA6','limit',a.limit||100000,'number',grid);
      input('\u5207\u6362\u9608\u503C\uFF08%\uFF09','threshold',a.threshold??80,'number',grid);input('\u5173\u8054\u540E\u7AEF\u5B8C\u6574\u57DF\u540D\uFF08\u9017\u53F7\u5206\u9694\uFF0C\u524D\u7AEF\u8D26\u53F7\u7559\u7A7A\uFF09','backends',(a.backends||[]).join(','),'text',grid);card.appendChild(grid);
      var row=el('div',null,'inrow'), check=el('button','\u68C0\u67E5\u6B64\u8D26\u53F7','btn sm'), remove=el('button','\u79FB\u9664\u8D26\u53F7','btn sm');
      check.onclick=function(){checkAccounts(a.id,check);};
      remove.onclick=function(){accounts=collect();accounts.splice(index,1);dirty=true;render();message.textContent='\u8D26\u53F7\u5DF2\u79FB\u9664\uFF0C\u70B9\u51FB\u201C\u4FDD\u5B58\u8D26\u53F7\u8BBE\u7F6E\u201D\u540E\u751F\u6548';};
      row.append(check,remove);card.appendChild(row);
      var output=el('div',null,'hint');output.dataset.result='';output.style.marginTop='12px';card.appendChild(output);result(card,a.usage);list.appendChild(card);
      card.addEventListener('input',function(){dirty=true;message.textContent='\u8BBE\u7F6E\u5DF2\u4FEE\u6539\uFF0C\u70B9\u51FB\u201C\u4FDD\u5B58\u8D26\u53F7\u8BBE\u7F6E\u201D\u6216\u5E95\u90E8\u201C\u4FDD\u5B58\u5168\u90E8\u201D\u751F\u6548';});
    });summary();
  }
  async function call(path,body) {
    if(!body)path+=(path.indexOf('?')>=0?'&':'?')+'_v='+Date.now();
    var r=await fetch(path,body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{cache:'no-store'});
    var j=await r.json();if(!r.ok||j.ok===false)throw new Error(j.msg||('HTTP '+r.status));return j;
  }
  async function load() { var j=await call('/quota-accounts');accounts=j.accounts||[];dirty=false;render(); }
  async function saveQuotaSettings() {
    var submitted = collect();
    var j = await call('/quota-accounts', { accounts: submitted });
    // Use the committed response rather than immediately rereading eventually consistent KV.
    accounts = j.accounts.map(function(account){
      var old = accounts.find(function(previous){return previous.id===account.id;});
      return Object.assign({}, account, {usage:old&&old.usage});
    });
    dirty=false;render();message.textContent=j.msg;return j;
  }
  async function checkAccounts(id,button,automatic) {
    if(dirty){
      if(automatic)return;
      try{await saveQuotaSettings();}catch(error){message.textContent='\u4FDD\u5B58\u5931\u8D25\uFF1A'+error.message;return;}
    }
    if(!accounts.length){message.textContent='\u8BF7\u5148\u6DFB\u52A0\u5E76\u4FDD\u5B58\u8D26\u53F7';return;}
    if(button)button.disabled=true;
    message.textContent='\u6B63\u5728\u5206\u522B\u68C0\u67E5\u8D26\u53F7\u2026';
    try{
      var j=await call('/quota-accounts/check', {id:id||'',cached:!!automatic});
      j.results.forEach(function(data){var a=accounts.find(function(x){return x.id===data.id;});if(a)a.usage=data;var card=Array.from(list.children).find(function(x){return x.dataset.id===data.id;});if(card)result(card,data);});
      summary();message.textContent='\u68C0\u67E5\u5B8C\u6210\uFF1A'+j.results.length+' \u4E2A\u8D26\u53F7\uFF0C'+j.results.filter(function(x){return x.error;}).length+' \u4E2A\u67E5\u8BE2\u5F02\u5E38';
    }catch(error){message.textContent='\u68C0\u67E5\u5931\u8D25\uFF1A'+error.message;}
    finally{if(button)button.disabled=false;}
  }
  document.getElementById('mq-add').onclick=function(){accounts=collect();accounts.push({name:'',id:'',token:'',limit:100000,threshold:80,backends:[]});dirty=true;render();};
  document.getElementById('mq-save').onclick=async function(){
    var button=this;button.disabled=true;
    try{await saveQuotaSettings();}catch(error){message.textContent='\u4FDD\u5B58\u5931\u8D25\uFF1A'+error.message;}finally{button.disabled=false;}
  };
  document.getElementById('mq-check-all').onclick=function(){checkAccounts('',this);};
  var originalSaveAll=window.saveAll;
  if(typeof originalSaveAll==='function'){
    window.saveAll=function(){
      if(typeof hasPreferredDrafts==='function'&&hasPreferredDrafts()){if(window.toast)window.toast('\u8BF7\u5148\u7528\u5404\u540E\u7AEF\u5361\u7247\u5185\u7684\u6309\u94AE\u4FDD\u5B58\u4F18\u9009\u4FEE\u6539','warn');return;}
      var self=this,args=arguments;
      if(!dirty)return originalSaveAll.apply(self,args);
      return saveQuotaSettings().then(function(){return originalSaveAll.apply(self,args);})
        .catch(function(error){message.textContent='\u8D26\u53F7\u8BBE\u7F6E\u4FDD\u5B58\u5931\u8D25\uFF1A'+error.message;if(window.toast)window.toast(message.textContent,'err');});
    };
  }

  window.refreshQuota=function(){if(accounts.length)return checkAccounts('',document.getElementById('mq-check-all'),true);return legacyRefresh&&legacyRefresh();};
  window.updDbQuota=function(data){if(accounts.length)return summary();return legacyDb&&legacyDb(data);};
  load().then(function(){return checkAccounts('',null,true);}).catch(function(error){message.textContent='\u52A0\u8F7D\u5931\u8D25\uFF1A'+error.message;});
  setInterval(function(){if(!document.hidden&&!dirty)checkAccounts('',null,true);},15*60*1000);
})();
</script>
`;function qe(t){let e=t.indexOf('data-view="quota"'),a=t.indexOf("</div>",e)+6;return e>=0&&a>5&&(t=t.slice(0,a)+Ue+t.slice(a)),t.replace("</body>",Oe+"</body>")}export{ze as default};
